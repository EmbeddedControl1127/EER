/*
*         Copyright (c), NXP Semiconductors Gratkorn / Austria
*
*                     (C)NXP Semiconductors
*       All rights are reserved. Reproduction in whole or in part is
*      prohibited without the written consent of the copyright owner.
*  NXP reserves the right to make changes without notice at any time.
* NXP makes no warranty, expressed, implied or statutory, including but
* not limited to any implied warranty of merchantability or fitness for any
*particular purpose, or that the use will not infringe any third party patent,
* copyright or trademark. NXP must not be liable for any loss or damage
*                          arising from its use.
*/

/** \file
* Internal functions of Software implementation of MIFARE (R) application layer.
* $Author: NXP99556 $
* $Revision: 1952 $ (v05.07.00)
* $Date: 2016-07-05 12:32:08 +0530 (Tue, 05 Jul 2016) $
*
* History:
*  Kumar GVS: Generated 15. Apr 2013
*
*/


#ifndef PHALMFPEV1_INT_H
#define PHALMFPEV1_INT_H

#include <ph_Status.h>

/** \addtogroup ph_Private
* @{
*/

/**
* \name MIFARE Plus EV1 Commands in MIFARE Plus Mode
*/
/*@{*/
#define PHAL_MFPEV1_CMD_AUTH1_FIRST    0x70U    /**< MFP EV1 Authenticate command (part 1, first authentication). */
#define PHAL_MFPEV1_CMD_AUTH1          0x76U    /**< MFP EV1 Authenticate command (part 1, non-first authentication). */
#define PHAL_MFPEV1_CMD_AUTH2          0x72U    /**< MFP EV1 Authenticate command (part 2). */
#define PHAL_MFPEV1_CMD_AUTH3          0x74U    /**< MFP EV1 Authenticate command (part 3). */
#define PHAL_MFPEV1_CMD_RAUTH          0x78U    /**< MFP EV1 ResetAuth command. */

#define PHAL_MFPEV1_CMD_READ_ENM       0x30U    /**< MFP EV1 Read Encrypted, No mac on response, Mac on command. */
#define PHAL_MFPEV1_CMD_READ_EMM       0x31U    /**< MFP EV1 Read Encrypted, Mac on response, Mac on command. */
#define PHAL_MFPEV1_CMD_READ_PNM       0x32U    /**< MFP EV1 Read Plain, No mac on response, Mac on command. */
#define PHAL_MFPEV1_CMD_READ_PMM       0x33U    /**< MFP EV1 Read Plain, Mac on response, Mac on command. */
#define PHAL_MFPEV1_CMD_READ_ENU       0x34U    /**< MFP EV1 Read Encrypted, No mac on response, Unmac'ed command. */
#define PHAL_MFPEV1_CMD_READ_EMU       0x35U    /**< MFP EV1 Read Encrypted, Mac on response, Unmac'ed command. */
#define PHAL_MFPEV1_CMD_READ_PNU       0x36U    /**< MFP EV1 Read Plain, No mac on response, Unmac'ed command. */
#define PHAL_MFPEV1_CMD_READ_PMU       0x37U    /**< MFP EV1 Read Plain, Mac on response, Unmac'ed command. */

#define PHAL_MFPEV1_CMD_WRITE_EN       0xA0U    /**< MFP EV1 Write Encrypted, No mac on response, (Mac on command). */
#define PHAL_MFPEV1_CMD_WRITE_EM       0xA1U    /**< MFP EV1 Write Encrypted, Mac on response, (Mac on command). */
#define PHAL_MFPEV1_CMD_WRITE_PN       0xA2U    /**< MFP EV1 Write Plain, No mac on response, (Mac on command). */
#define PHAL_MFPEV1_CMD_WRITE_PM       0xA3U    /**< MFP EV1 Write Plain, Mac on response, (Mac on command). */

#define PHAL_MFPEV1_CMD_WRITEPERSO     0xA8U    /**< MFP EV1 Write Perso. */
#define PHAL_MFPEV1_CMD_COMMITPERSO    0xAAU    /**< MFP EV1 Commit Perso. */
#define PHAL_MFPEV1_CMD_INCR           0xB0U    /**< MFP EV1 Increment command. */
#define PHAL_MFPEV1_CMD_INCR_M         0xB1U    /**< MFP EV1 Increment command MACed. */
#define PHAL_MFPEV1_CMD_DECR           0xB2U    /**< MFP EV1 Decrement command. */
#define PHAL_MFPEV1_CMD_DECR_M         0xB3U    /**< MFP EV1 Decrement command MACed. */
#define PHAL_MFPEV1_CMD_TRANS          0xB4U    /**< MFP EV1 Transfer command. */
#define PHAL_MFPEV1_CMD_TRANS_M        0xB5U    /**< MFP EV1 Transfer command MACed. */
#define PHAL_MFPEV1_CMD_INCRTR         0xB6U    /**< MFP EV1 Increment Transfer command. */
#define PHAL_MFPEV1_CMD_INCRTR_M       0xB7U    /**< MFP EV1 Increment Transfer command MACed. */
#define PHAL_MFPEV1_CMD_DECRTR         0xB8U    /**< MFP EV1 Decrement Transfer command. */
#define PHAL_MFPEV1_CMD_DECRTR_M       0xB9U    /**< MFP EV1 Decrement Transfer command MACed. */
#define PHAL_MFPEV1_CMD_REST           0xC2U    /**< MFP EV1 Restore command. */
#define PHAL_MFPEV1_CMD_REST_M         0xC3U    /**< MFP EV1 Restore command MACed. */
#define PHAL_MFPEV1_CMD_PPC            0xF0U    /**< MFP EV1 Prepare Proximity Check. */
#define PHAL_MFPEV1_CMD_PC             0xF2U    /**< MFP EV1 Proximity Check command. */
#define PHAL_MFPEV1_CMD_VPC            0xFDU    /**< MFP EV1 Verify Proximity Check command. */
#define PHAL_MFPEV1_CMD_PERSOUID       0x40U    /**< MFP EV1 Personalize UID command */
#define PHAL_MFPEV1_CMD_VCLAST_ISOL3   0x4BU    /**< VCA Virtual Card Support Last command code. */
/*@}*/

/**
* \name MIFARE Plus EV1 Commands in MIFARE Mode
*/
/*@{*/
#define PHAL_MFPEV1_CMD_MBREAD          0x38U    /**< MFP Multi Block Read. */
#define PHAL_MFPEV1_CMD_MBWRITE         0xA8U    /**< MFP Multi Block Read. */

#define PHAL_MFPEV1_CMD_MFC_RESTORE    0xC2U    /**< MFP EV1 Restore command in MIFARE Classic mode. */
#define PHAL_MFPEV1_CMD_MFC_INCREMENT  0xC1U    /**< MFP EV1 Increment command in MIFARE Classic mode. */
#define PHAL_MFPEV1_CMD_MFC_DECREMENT  0xC0U    /**< MFP EV1 Decrement command in MIFARE Classic mode. */
#define PHAL_MFPEV1_CMD_MFC_TRANSFER   0xB0U    /**< MFP EV1 Transfer command in MIFARE Classic mode. */
#define PHAL_MFPEV1_CMD_MFC_READ       0x30U    /**< MFP EV1 Read command in MIFARE Classic mode. */
#define PHAL_MFPEV1_CMD_MFC_WRITE      0xA0U    /**< MFP EV1 Write command in MIFARE Classic mode. */
/*@}*/

/**
* \name MIFARE Plus EV1 Special Commands
*/
/*@{*/
#define PHAL_MFPEV1_CMD_GET_VERSION         0x60U    /**< MFP EV1 Get Version cmd. */
#define PHAL_MFPEV1_CMD_COMMIT_READER_ID    0xC8U    /**< MFP EV1 Commit Reader ID cmd. */
#define PHAL_MFPEV1_CMD_SSAUTH              0x7AU    /**< MFP EV1 Sector Switch Authentication cmd. */
#define PHAL_MFPEV1_CMD_SSAUTHC             0x72U    /**< MFP EV1 Sector Switch Authentication Continue cmd. */
#define PHAL_MFPEV1_CMD_AUTH_PDC            0x7CU    /**< MFP EV1 Post Delivery Command. */
#define PHAL_MFPEV1_CMD_READ_SIG            0x3CU    /**< MFP EV1 Verify read signature command. */
#define PHAL_MFPEV1_CMD_SET_CONFIG_SL1      0x44U    /**< MFP EV1 SetConfigSL1 command. */
/*@}*/

/**
* \name MIFARE Plus EV1 options Diversification.
*/
/*@{*/
#define PHAL_MFPEV1_NO_DIVERSIFICATION            0xFFFFU /**< No diversification. */
/*@}*/

/**
* \name MIFARE Plus EV1 Response Codes
*/
/*@{*/
#define PHAL_MFPEV1_RESP_NACK0             0x00U   /*< MFP EV1 NACK 0 (in ISO14443-3 mode). */
#define PHAL_MFPEV1_RESP_NACK1             0x01U   /*< MFP EV1 NACK 1 (in ISO14443-3 mode). */
#define PHAL_MFPEV1_RESP_NACK4             0x04U   /*< MFP EV1 NACK 4 (in ISO14443-3 mode). */
#define PHAL_MFPEV1_RESP_NACK5             0x05U   /*< MFP EV1 NACK 5 (in ISO14443-3 mode). */
#define PHAL_MFPEV1_RESP_ACK_ISO3          0x0AU   /*< MFP EV1 ACK (in ISO14443-3 mode). */
#define PHAL_MFPEV1_RESP_ACK_ISO4          0x90U   /*< MFP EV1 ACK (in ISO14443-4 mode). */
#define PHAL_MFPEV1_RESP_ERR_TM            0x05U   /*< MFP EV1 Tranaction MAC related Error. */
#define PHAL_MFPEV1_RESP_ERR_AUTH          0x06U   /*< MFP EV1 Authentication Error. */
#define PHAL_MFPEV1_RESP_ERR_CMD_OVERFLOW  0x07U   /*< MFP EV1 Command Overflow Error. */
#define PHAL_MFPEV1_RESP_ERR_MAC_PCD       0x08U   /*< MFP EV1 MAC Error. */
#define PHAL_MFPEV1_RESP_ERR_BNR           0x09U   /*< MFP EV1 Blocknumber Error. */
#define PHAL_MFPEV1_RESP_ERR_EXT           0x0AU   /*< MFP EV1 Extension Error. */
#define PHAL_MFPEV1_RESP_ERR_CMD_INVALID   0x0BU   /*< MFP EV1 Invalid Command Error. */
#define PHAL_MFPEV1_RESP_ERR_FORMAT        0x0CU   /*< MFP EV1 Format Error. */
#define PHAL_MFPEV1_RESP_ERR_NOT_SUP       0x0DU   /*< MFP EV1 Not Supported Error. */
#define PHAL_MFPEV1_RESP_ERR_GEN_FAILURE   0x0FU   /*< MFP EV1 Generic Error. */
#define PHAL_MFPEV1_RESP_ADDITIONAL_FRAME  0xAFU   /*< MFP EV1 Additional data frame is expected to be sent. */
/*@}*/

#define PHAL_MFPEV1_TRUNCATED_MAC_SIZE          8U   /**< Size of the truncated MAC. */
#define PHAL_MFPEV1_PC_RND_LEN                  7U   /**< Size of the Proximity Check Random numbers. */
#define PHAL_MFPEV1_SIG_LENGTH              0x38U    /**< NXP Originality Signature length */
#define PHAL_MFPEV1_SIG_LENGTH_ENC          0x40U    /**< NXP Originality Signature length */

/**
* \name MIFARE Plus EV1 ISO 7816-4 header values
*/
/*@{*/
#define PHAL_MFPEV1_WRAP_HDR_LEN      0x04U   /* Wrapped APDU header length */
#define PHAL_MFPEV1_WRAPPEDAPDU_CLA   0x90U   /* Wrapped APDU default class. */
#define PHAL_MFPEV1_WRAPPEDAPDU_P1    0x00U   /* Wrapped APDU default P1. */
#define PHAL_MFPEV1_WRAPPEDAPDU_P2    0x00U   /* Wrapped APDU default P2. */
/*@}*/

/**
* \name MIFARE Plus EV1 ISO 7816-4 error codes.
*/
/*@{*/
#define PHAL_MFPEV1_ISO7816_RESP_SUCCESS                        0x9000U /**< Correct execution. */
#define PHAL_MFPEV1_ISO7816_RESP_ERR_WRONG_LENGTH               0x6700U /**< Wrong length. */
#define PHAL_MFPEV1_ISO7816_RESP_ERR_WRONG_PARAMS               0x6A86U /**< Wrong parameters P1 and/or P2. */
#define PHAL_MFPEV1_ISO7816_RESP_ERR_WRONG_LC                   0x6A87U /**< Lc inconsistent with P1/p2. */
#define PHAL_MFPEV1_ISO7816_RESP_ERR_WRONG_LE                   0x6C00U /**< Wrong Le. */
#define PHAL_MFPEV1_ISO7816_RESP_ERR_WRONG_CLA                  0x6E00U /**< Wrong Class byte. */
/*@}*/

/**
* \name Block definitions
*/
/*@{*/
#define PHAL_MFPEV1_DATA_BLOCK_SIZE      16U     /**< Length of MFP EV1 data block. */
#define PHAL_MFPEV1_VALUE_BLOCK_SIZE     4U     /**< Length of MFP EV1 value block. */
#define PHAL_MFPEV1_MAX_WRITE_BLOCK      (PHAL_MFPEV1_DATA_BLOCK_SIZE * 15U) /**< Maximum blocks that can be written. */
/*@}*/

/**
* \name MIFARE Plus EV1 Secure messaging flags.
*/
/*@{*/
#define PHAL_MFPEV1_SECURE_MESSAGE_EV0  0x00U    /**< EV0 Secure messaging.*/
#define PHAL_MFPEV1_SECURE_MESSAGE_EV1  0x01U    /**< EV0 Secure messaging.*/
/*@}*/

/**
* \name MIFARE Plus EV1 supported UID size.
*/
/*@{*/
#define PHAL_MFPEV1_UID_LENGTH_4B       0x04U    /**< UID length of 4 bytes. */
#define PHAL_MFPEV1_UID_LENGTH_7B       0x07U    /**< UID length of 7 bytes. */
#define PHAL_MFPEV1_UID_LENGTH_10B      0x0AU    /**< UID length of 10 bytes. */
/*@}*/

/**
* \brief Evaluate if the received response is erroneus.
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
*/
phStatus_t phalMfpEv1_Int_ComputeErrorResponse(
    uint16_t wNumBytesReceived,                     /**< [In] Number of bytes received from the card. */
    uint16_t wStatus,                               /**< [In] Status byte received from the card. */
    uint8_t bLayer4Comm                             /**< [In] \c 0: use ISO14443-3 protocol; \c 1: use ISO14443-4 protocol. */
    );

/**
* \brief Evaluate if the received response is erroneus.
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
*/
phStatus_t phalMfpEv1_Int_ComputeErrorResponseMfc(
    uint16_t wNumBytesReceived,                     /**< [In] Number of bytes received from the card. */
    uint8_t bStatus                             /**< [In] Status byte received from the card. */
    );

#ifdef NXPBUILD__PHAL_MFPEV1_SW
/**
* \brief Perform a MIFARE Plus Ev1 Write Perso command.
*
* The Write Perso command can be executed using the ISO14443-3 communication protocol (after layer 3 activation)
* or using the ISO14443-4 protocol (after layer 4 activation).
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfpEv1_Int_WritePerso(
    phalMfpEv1_Sw_DataParams_t * pDataParams,  /**< [In] Pointer to a palMifare component context. */
    uint8_t bLayer4Comm,            /**< [In] \c 0: use ISO14443-3 protocol; \c 1: use ISO14443-4 protocol. */
    uint16_t wBlockNr,              /**< [In] MIFARE Block number. */
    uint8_t bNumBlocks,             /**< [In] Number of blocks to write. */
    uint8_t * pValue                /**< [In] Value (16 bytes). */
    );

/**
* \brief Perform a MIFARE Plus Ev1 Commit Perso command.
*
* The Commit Perso command can be executed using the ISO14443-3 communication protocol (after layer 3 activation)
* or using the ISO14443-4 protocol (after layer 4 activation).
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfpEv1_Int_CommitPerso(
    phalMfpEv1_Sw_DataParams_t * pDataParams,  /**< [In] Pointer to a palMifare component context. */
    uint8_t bOption,                /**< [In] 0x01..0x03  for L1 cards, 0x03 for L3 cards and 0 for backward compatibility */
    uint8_t bLayer4Comm             /**< [In] \c 0: use ISO14443-3 protocol; \c 1: use ISO14443-4 protocol. */
    );

/**
* \brief Perform a MIFARE Plus Ev1 Reset Authenticate command.
*
* The Reset Authenticate command is executed using the ISO14443-4 communication protocol (after layer 4 activation)
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfpEv1_Int_ResetAuth(
    phalMfpEv1_Sw_DataParams_t * pDataParams     /**< [In] Pointer to a phalMfpEv1 component context. */
    );

#endif /* NXPBUILD__PHAL_MFPEV1_SW */

/**
* \brief Perform a Multi Block Read command.
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfpEv1_Int_MultiBlockRead(
    void * pPalMifareDataParams,  /**< [In] Pointer to a palMifare component context. */
    uint8_t bBlockNr,             /**< [In] MIFARE Block number. */
    uint8_t bNumBlocks,           /**< [In] Number of blocks to read (should not be more than 3). */
    uint8_t * pBlocks             /**< [Out] Block(s); uint8_t[16U * \c bNumBlocks]. */
    );

/**
* \brief Perform a Multi Block Write command.
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfpEv1_Int_MultiBlockWrite(
    void * pPalMifareDataParams,     /**< [In] Pointer to a palMifare component context. */
    uint8_t bBlockNr,                /**< [In] MIFARE Block number. */
    uint8_t bNumBlocks,              /**< [In] Number of blocks to write (should not be more than 3). */
    uint8_t * pBlocks                /**< [In] Block(s); uint8_t[16U * \c bNumBlocks]. */
    );
/**
* \brief Create a Value block for a given value/addr pair.
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
*/
phStatus_t phalMfpEv1_Int_CreateValueBlock(
    uint8_t * pValue,   /**< [In] Value to be converted. */
    uint8_t bAddrData,  /**< [In] bAddrData containing destination address. */
    uint8_t * pBlock    /**< [Out] Formatted Value block. */
    );

/**
* \brief Check value block format of a given block.
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
*/
phStatus_t phalMfpEv1_Int_CheckValueBlockFormat(
    uint8_t * pBlock    /**< [In] Formatted Value block. */
    );

/**
* \brief To wrap the command in ISO 7816-4 format if wrap mode is set and send the command.
* \c Buffering options (wOptions) can be one of the following:\n
* \li PH_EXCHANGE_BUFFER_FIRST
* \li PH_EXCHANGE_BUFFER_CONT
* \li PH_EXCHANGE_BUFFER_LAST
* \li PH_EXCHANGE_BUFFER_DEFAULT
* \li PH_EXCHANGE_BUFFER_RXCHAINING

* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
*/
phStatus_t phalMfpEv1_Int_Send7816Apdu(
                                    void * pPalMifareDataParams,                /**< [In] Pointer to Pal mifare dataparams. */
                                    uint16_t wOptions,                          /**< [In] Buffering option. */
                                    uint16_t wLc,                               /**< [In] >= 1 if data is present else 0 if only command code is present.*/
                                    uint8_t bExtendedLenApdu,                   /**< [In] To wrapp data in extended or short length APDU.
                                                                                          \c 0: use Short Length APDU;
                                                                                          \c 1: use Extended Length APDU.
                                                                                 */
                                    uint8_t * pData,                            /**< [In]  The data to be wrapped. */
                                    uint16_t wDataLen,                          /**< [In]  The lenght of the command. */
                                    uint8_t ** ppRxBuffer,                      /**< [Out] The data received from the card. Consists of the non wrapped data. */
                                    uint16_t * pRxBufLen                        /**< [Out] The length of the non wrapped data.  */
                                    );

/** @}
* end of ph_Private
*/

#endif /* PHALMFPEV1_INT_H */
