/*
*         Copyright (c), NXP Semiconductors Bangalore / India
*
*                     (C)NXP Semiconductors
*       All rights are reserved. Reproduction in whole or in part is
*      prohibited without the written consent of the copyright owner.
*  NXP reserves the right to make changes without notice at any time.
* NXP makes no warranty, expressed, implied or statutory, including but
* not limited to any implied warranty of merchantability or fitness for any
* particular purpose, or that the use will not infringe any third party patent,
* copyright or trademark. NXP must not be liable for any loss or damage
*                          arising from its use.
*/

#ifndef PHALMFDFEV2_SW_INT_H
#define PHALMFDFEV2_SW_INT_H

phStatus_t phalMfdfEv2_Sw_Int_SendDataToPICC(
    phalMfdfEv2_Sw_DataParams_t * pDataParams,
    uint8_t bIns, /* ISO 14443-4 Chaining */
    uint8_t bCommOption,
    uint8_t * pCmd,
    uint16_t wCmdLen,
    uint8_t * pData,
    uint16_t wDataLen,
    uint8_t * bLastChunk,
    uint16_t wLastChunkLen,
    uint8_t * pResp,
    uint16_t * pRespLen
    );

phStatus_t phalMfdfEv2_Sw_Int_SendDataAndAddDataToPICC(
    phalMfdfEv2_Sw_DataParams_t * pDataParams,
    uint8_t bIns,
    uint8_t * pCmd,
    uint16_t wCmdLen,
    uint8_t * pData,
    uint16_t wDataLen,
    uint8_t * pAddData,
    uint16_t wAddDataLen,
    uint8_t * pResp,
    uint16_t * pRespLen
    );

phStatus_t phalMfdfEv2_Sw_Int_GetData(
                                      phalMfdfEv2_Sw_DataParams_t * pDataParams,
                                      uint8_t * pSendBuff,
                                      uint16_t wCmdLen,
                                      uint8_t ** pResponse,
                                      uint16_t * pRxlen
                                      );

phStatus_t phalMfdfEv2_Sw_Int_ReadData_Plain(
    phalMfdfEv2_Sw_DataParams_t * pDataParams,
    uint8_t bOption,
    uint8_t * bCmdBuff,
    uint16_t wCmdLen,
    uint8_t ** ppRxdata,
    uint16_t * pRxdataLen
    );

phStatus_t phalMfdfEv2_Sw_Int_ReadData_Enc(
    phalMfdfEv2_Sw_DataParams_t * pDataParams,
    uint8_t bOption,  /*  padding method 1 or 2 */
    uint8_t * bCmdBuff,
    uint16_t wCmdLen,
    uint8_t ** ppRxdata,
    uint16_t * pRxdataLen
    );

phStatus_t phalMfdfEv2_Sw_Int_Write_Plain(
    phalMfdfEv2_Sw_DataParams_t * pDataParams,
    uint8_t bIns, /* ISO 14443-4 Chaining */
    uint8_t * bCmdBuff,
    uint16_t wCmdLen,
    uint8_t bCommOption,
    uint8_t * pData,
    uint16_t  wDataLen
    );

phStatus_t phalMfdfEv2_Sw_Int_Write_Enc(
                                        phalMfdfEv2_Sw_DataParams_t * pDataParams,
                                        uint8_t bIns, /* ISO 14443-4 Chaining */
                                        uint8_t * bCmdBuff,
                                        uint16_t wCmdLen,
                                        uint8_t bPaddingOption,  /*  Either PH_CRYPTOSYM_PADDING_MODE_1 or PH_CRYPTOSYM_PADDING_MODE_2 */
                                        uint8_t bCommOption,
                                        uint8_t * pData,
                                        uint16_t wDataLen
                                        );

void phalMfdfEv2_Sw_Int_ResetAuthStatus(
                                        phalMfdfEv2_Sw_DataParams_t * pDataParams
                                        );

phStatus_t phalMfdfEv2_Sw_Int_IsoRead(
                                      phalMfdfEv2_Sw_DataParams_t * pDataParams,
                                      uint16_t wOption,
                                      uint8_t * bCmdBuff,
                                      uint16_t wCmdLen,
                                      uint8_t ** ppRxBuffer,
                                      uint32_t * pBytesRead
                                      );

void phalMfdfEv2_Sw_Int_TruncateMac(
                                    uint8_t * pMac
                                    );

phStatus_t phalMfdfEv2_Sw_Int_ComputeIv(
                                        uint8_t bIsResponse,
                                        uint8_t * pTi,
                                        uint16_t wCmdCtr,
                                        uint8_t * pIv
                                        );

phStatus_t phalMfdfEv2_Sw_Int_GetFrameLength(
                                        phalMfdfEv2_Sw_DataParams_t * pDataParams,
                                        uint16_t * pFSD,
                                        uint16_t * pFSC
                                        );

phStatus_t phalMfdfEv2_Sw_Int_ISOGetData(
                                        phalMfdfEv2_Sw_DataParams_t * pDataParams,
                                        uint8_t * pSendBuff,
                                        uint16_t wCmdLen,
                                        uint8_t ** pResponse,
                                        uint16_t * pRxlen
                                        );
#endif /* PHALMFDFEV2_SW_INT_H */
