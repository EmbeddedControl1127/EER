/*
 * phOsal_Freertos.h
 *
 *  Created on: May 12, 2016
 *      Author: nxp69678
 */

#ifndef PHOSAL_NULLOS_H
#define PHOSAL_NULLOS_H

#define PHOSAL_MAX_DELAY      (0xFFFFFFFFU)

#endif /* PHOSAL_NULLOS_H */
