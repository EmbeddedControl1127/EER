/*
*         Copyright (c), NXP Semiconductors Gratkorn / Austria
*
*                     (C)NXP Semiconductors
*       All rights are reserved. Reproduction in whole or in part is
*      prohibited without the written consent of the copyright owner.
*  NXP reserves the right to make changes without notice at any time.
* NXP makes no warranty, expressed, implied or statutory, including but
* not limited to any implied warranty of merchantability or fitness for any
*particular purpose, or that the use will not infringe any third party patent,
* copyright or trademark. NXP must not be liable for any loss or damage
*                          arising from its use.
*/

/** \file
* Software MIFARE Plus(R) EV1 Application Component of Reader Library Framework.
* $Author: NXP99556 $
* $Revision: 1947 $ (v05.07.00)
* $Date: 2016-07-04 16:26:07 +0530 (Mon, 04 Jul 2016) $
*
* History:
*  Kumar GVS: Generated 15. Apr 2013
*
*/

#ifndef PHALMFPEV1_SW_H
#define PHALMFPEV1_SW_H

#include <ph_Status.h>

#ifdef NXPBUILD__PHAL_MFPEV1_SW

phStatus_t phalMfpEv1_Sw_WritePerso(
    phalMfpEv1_Sw_DataParams_t * pDataParams,
    uint8_t bLayer4Comm,
    uint16_t wBlockNr,
    uint8_t bNumBlocks,
    uint8_t * pValue
    );

phStatus_t phalMfpEv1_Sw_CommitPerso(
    phalMfpEv1_Sw_DataParams_t * pDataParams,
    uint8_t bOption,
    uint8_t bLayer4Comm
    );

phStatus_t phalMfpEv1_Sw_CommitReaderID(
    phalMfpEv1_Sw_DataParams_t * pDataParams,
    uint16_t wBlockNr,
    uint8_t * pTMRI,
    uint8_t * pEncTMRI
    );

phStatus_t phalMfpEv1_Sw_DecryptReaderID(
    phalMfpEv1_Sw_DataParams_t *pDataParams,
    uint16_t wOption,
    uint16_t wKeyNoTMACKey,
    uint16_t wKeyVerTMACKey,
    uint8_t * pDivInput,
    uint8_t bDivInputLen,
    uint8_t * pTMC,
    uint8_t * pUid,
    uint8_t bUidLen,
    uint8_t * pEncTMRI,
    uint8_t * pTMRIPrev
    );

phStatus_t phalMfpEv1_Sw_AuthenticateSL0(
    phalMfpEv1_Sw_DataParams_t * pDataParams,
    uint8_t bLayer4Comm,
    uint8_t bFirstAuth,
    uint16_t wBlockNr,
    uint16_t wKeyNumber,
    uint16_t wKeyVersion,
    uint8_t bLenDivInput,
    uint8_t * pDivInput,
    uint8_t bLenPcdCap2,
    uint8_t * pPcdCap2In,
    uint8_t * pPcdCap2Out,
    uint8_t * pPdCap2
    );

phStatus_t phalMfpEv1_Sw_AuthenticateSL1(
    phalMfpEv1_Sw_DataParams_t * pDataParams,
    uint8_t bLayer4Comm,
    uint8_t bFirstAuth,
    uint16_t wBlockNr,
    uint16_t wKeyNumber,
    uint16_t wKeyVersion,
    uint8_t bLenDivInput,
    uint8_t * pDivInput,
    uint8_t bLenPcdCap2,
    uint8_t * pPcdCap2In,
    uint8_t * pPcdCap2Out,
    uint8_t * pPdCap2
    );

phStatus_t phalMfpEv1_Sw_AuthenticateSL2(
    phalMfpEv1_Sw_DataParams_t * pDataParams,
    uint8_t bLayer4Comm,
    uint8_t bFirstAuth,
    uint16_t wBlockNr,
    uint16_t wKeyNumber,
    uint16_t wKeyVersion,
    uint8_t bLenDivInput,
    uint8_t * pDivInput,
    uint8_t bLenPcdCap2,
    uint8_t * pPcdCap2In,
    uint8_t * pPcdCap2Out,
    uint8_t * pPdCap2,
    uint8_t * pKmf
    );

phStatus_t phalMfpEv1_Sw_MultiBlockRead(
    phalMfpEv1_Sw_DataParams_t * pDataParams,
    uint8_t bBlockNr,
    uint8_t bNumBlocks,
    uint8_t * pBlocks
    );

phStatus_t phalMfpEv1_Sw_MultiBlockWrite(
    phalMfpEv1_Sw_DataParams_t * pDataParams,
    uint8_t bBlockNr,
    uint8_t bNumBlocks,
    uint8_t * pBlocks
    );

phStatus_t phalMfpEv1_Sw_Write(
    phalMfpEv1_Sw_DataParams_t * pDataParams,
    uint8_t bEncrypted,
    uint8_t bWriteMaced,
    uint16_t wBlockNr,
    uint8_t bNumBlocks,
    uint8_t * pBlocks,
    uint8_t * pTMC,
    uint8_t * pTMV
    );

phStatus_t phalMfpEv1_Sw_WriteValue(
    phalMfpEv1_Sw_DataParams_t * pDataParams,
    uint8_t bEncrypted,
    uint8_t bWriteMaced,
    uint16_t wBlockNr,
    uint8_t * pValue,
    uint8_t bAddrData,
    uint8_t * pTMC,
    uint8_t * pTMV
    );

phStatus_t phalMfpEv1_Sw_GetTransactionMACBlockData(
    phalMfpEv1_Sw_DataParams_t * pDataParams,
    uint8_t* pTMC,
    uint8_t* pTMV
    );

phStatus_t phalMfpEv1_Sw_ChangeKey(
    phalMfpEv1_Sw_DataParams_t * pDataParams,
    uint8_t bChangeKeyMaced,
    uint16_t wBlockNr,
    uint16_t wKeyNumber,
    uint16_t wKeyVersion,
    uint8_t bLenDivInput,
    uint8_t * pDivInput
    );

phStatus_t phalMfpEv1_Sw_AuthenticateSL3(
    phalMfpEv1_Sw_DataParams_t * pDataParams,
    uint8_t bFirstAuth,
    uint16_t wBlockNr,
    uint16_t wKeyNumber,
    uint16_t wKeyVersion,
    uint8_t bLenDivInput,
    uint8_t * pDivInput,
    uint8_t bLenPcdCap2,
    uint8_t * pPcdCap2In,
    uint8_t * pPcdCap2Out,
    uint8_t * pPdCap2
    );

phStatus_t phalMfpEv1_Sw_AuthenticatePDC(
    phalMfpEv1_Sw_DataParams_t * pDataParams,
    uint16_t wBlockNr,
    uint16_t wKeyNumber,
    uint16_t wKeyVersion,
    uint8_t bLenDivInput,
    uint8_t * pDivInput,
    uint8_t bUpgradeInfo
    );

phStatus_t phalMfpEv1_Sw_Read(
    phalMfpEv1_Sw_DataParams_t * pDataParams,
    uint8_t bEncrypted,
    uint8_t bReadMaced,
    uint8_t bMacOnCmd,
    uint16_t wBlockNr,
    uint8_t bNumBlocks,
    uint8_t * pBlocks
    );

phStatus_t phalMfpEv1_Sw_ReadValue(
    phalMfpEv1_Sw_DataParams_t * pDataParams,
    uint8_t bEncrypted,
    uint8_t bReadMaced,
    uint8_t bMacOnCmd,
    uint16_t wBlockNr,
    uint8_t * pValue,
    uint8_t * pAddrData
    );

phStatus_t phalMfpEv1_Sw_ResetAuth(
    phalMfpEv1_Sw_DataParams_t * pDataParams
    );

phStatus_t phalMfpEv1_Sw_Increment(
    phalMfpEv1_Sw_DataParams_t * pDataParams,
    uint8_t bIncrementMaced,
    uint16_t wBlockNr,
    uint8_t * pValue
    );

phStatus_t phalMfpEv1_Sw_Decrement(
    phalMfpEv1_Sw_DataParams_t * pDataParams,
    uint8_t bDecrementMaced,
    uint16_t wBlockNr,
    uint8_t * pValue
    );

phStatus_t phalMfpEv1_Sw_IncrementTransfer(
    phalMfpEv1_Sw_DataParams_t * pDataParams,
    uint8_t bIncrementTransferMaced,
    uint16_t wSourceBlockNr,
    uint16_t wDestinationBlockNr,
    uint8_t * pValue,
    uint8_t * pTMC,
    uint8_t * pTMV
    );

phStatus_t phalMfpEv1_Sw_DecrementTransfer(
    phalMfpEv1_Sw_DataParams_t * pDataParams,
    uint8_t bDecrementTransferMaced,
    uint16_t wSourceBlockNr,
    uint16_t wDestinationBlockNr,
    uint8_t * pValue,
    uint8_t * pTMC,
    uint8_t * pTMV
    );

phStatus_t phalMfpEv1_Sw_Transfer(
    phalMfpEv1_Sw_DataParams_t * pDataParams,
    uint8_t bTransferMaced,
    uint16_t wBlockNr,
    uint8_t * pTMC,
    uint8_t * pTMV
    );

phStatus_t phalMfpEv1_Sw_Restore(
    phalMfpEv1_Sw_DataParams_t * pDataParams,
    uint8_t bRestoreMaced,
    uint16_t wBlockNr
    );

phStatus_t phalMfpEv1_Sw_ProximityCheck(
    phalMfpEv1_Sw_DataParams_t * pDataParams,
    uint8_t bGenerateRndC,
    uint8_t * pRndC,
    uint8_t bPps1,
    uint8_t bNumSteps,
    uint8_t * pUsedRndC
    );

phStatus_t phalMfpEv1_Sw_ResetSecMsgState(
    phalMfpEv1_Sw_DataParams_t * pDataParams
    );


phStatus_t phalMfpEv1_Sw_PersonalizeUid(
    phalMfpEv1_Sw_DataParams_t * pDataParams,
    uint8_t bUidType
    );
phStatus_t phalMfpEv1_Sw_GetVersion(
    phalMfpEv1_Sw_DataParams_t * pDataParams,
    uint8_t * pResponse
    );

phStatus_t phalMfpEv1_Sw_SSAuthenticate(
    phalMfpEv1_Sw_DataParams_t * pDataParams,
    uint16_t wSSKeyBNr,
    uint16_t wSSKeyNr,
    uint16_t wSSKeyVer,
    uint8_t bLenDivInputSSKey,
    uint8_t * pDivInputSSKey,
    uint8_t  bSecCount,
    uint16_t *pSectorNos,
    uint16_t *pKeyBKeyNos,
    uint16_t *pKeyBKeyVers,
    uint8_t bLenDivInputSectorKeyBs,
    uint8_t * pDivInputSectorKeyBs
    );

phStatus_t phalMfpEv1_Sw_SetConfig(
                                    phalMfpEv1_Sw_DataParams_t *pDataParams,
                                    uint16_t wOption,
                                    uint16_t wValue
                                    );

phStatus_t phalMfpEv1_Sw_GetConfig(
                                    phalMfpEv1_Sw_DataParams_t * pDataParams,
                                    uint16_t wOption,
                                    uint16_t * pValue
                                    );

/*
* Calculate TMV
*/
phStatus_t phalMfpEv1_Sw_CalculateTMV(
    phalMfpEv1_Sw_DataParams_t *pDataParams,
    uint16_t wOption,
    uint16_t wKeyNoTMACKey,
    uint16_t wKeyVerTMACKey,
    uint8_t * pDivInput,
    uint8_t bDivInputLen,
    uint8_t * pTMC,
    uint8_t * pUid,
    uint8_t bUidLen,
    uint8_t * pTMI,
    uint16_t wTMILen,
    uint8_t * pTMV
    );

/* Select VC in L3 activated state */
phStatus_t phalMfpEv1_Sw_VCSupportLastISOL3(
    phalMfpEv1_Sw_DataParams_t * pDataParams,
    uint8_t * pIid,
    uint8_t * pPcdCapL3,
    uint8_t * pInfo);

phStatus_t phalMfpEv1_Sw_ReadSign(
                                phalMfpEv1_Sw_DataParams_t * pDataParams,
                                uint8_t bLayer4Comm,
                                uint8_t bAddr,
                                uint8_t ** pSignature
                                );

phStatus_t phalMfpEv1_Sw_SetConfigSL1(
                                phalMfpEv1_Sw_DataParams_t * pDataParams,
                                uint8_t bOption
                                );

phStatus_t phalMfpEv1_Sw_AuthenticateMfc(
    phalMfpEv1_Sw_DataParams_t * pDataParams,
    uint8_t bBlockNo,
    uint8_t bKeyType,
    uint16_t wKeyNo,
    uint16_t wKeyVersion,
    uint8_t * pUid,
    uint8_t bUidLength
    );

phStatus_t phalMfpEv1_Sw_ReadSL1TMBlock(
                                phalMfpEv1_Sw_DataParams_t * pDataParams,
                                uint16_t wBlockNr,
                                uint8_t * pBlocks
                                );

phStatus_t phalMfpEv1_Sw_SetVCAParams(
                    phalMfpEv1_Sw_DataParams_t * pDataParams,
                    void * pAlVCADataParams
                    );
#endif /* NXPBUILD__PHAL_MFPEV1_SW */

#endif /* PHALMFPEV1_SW_H */
