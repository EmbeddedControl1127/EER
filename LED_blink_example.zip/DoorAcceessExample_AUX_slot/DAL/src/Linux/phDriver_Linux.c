/*
*         Copyright (c), NXP Semiconductors Bangalore / India
*
*                     (C)NXP Semiconductors
*       All rights are reserved. Reproduction in whole or in part is
*      prohibited without the written consent of the copyright owner.
*  NXP reserves the right to make changes without notice at any time.
* NXP makes no warranty, expressed, implied or statutory, including but
* not limited to any implied warranty of merchantability or fitness for any
*particular purpose, or that the use will not infringe any third party patent,
* copyright or trademark. NXP must not be liable for any loss or damage
*                          arising from its use.
*/

/** \file
* Generic phDriver Component of Reader Library Framework.
* $Author$
* $Revision$
* $Date$
*
* History:
*  RS: Generated 24. Jan 2017
*
*/

#include <phDriver.h>
#include <BoardSelection.h>

#include <signal.h>
#include <time.h>
#include <pthread.h>
#include <stdio.h>
#include <poll.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdint.h>
#include <stdbool.h>
#include <string.h>

static timer_t pPiTimer;
static pphDriver_TimerCallBck_t pxTimerCallBack;
static volatile bool bTimerExpired;

static void phDriver_Linux_TimerCallBack(union sigval uTimerSignal);

static void phDriver_Linux_TimerCallBack(union sigval uTimerSignal)
{
    if(pxTimerCallBack == NULL)
    {
        bTimerExpired = true;
    }else
    {
        pxTimerCallBack();
    }
}

phStatus_t phDriver_TimerStart(phDriver_Timer_Unit_t eTimerUnit, uint32_t dwTimePeriod, pphDriver_TimerCallBck_t pTimerCallBack)
{
    struct sigevent sSigEvent;
    struct itimerspec xTimerVal = {{0, 0}, {0, 0}};
    phStatus_t wStatus = PH_DRIVER_SUCCESS;

    pxTimerCallBack = pTimerCallBack;
    bTimerExpired = false;

    memset(&sSigEvent, 0, sizeof(sSigEvent));
    sSigEvent.sigev_notify  = SIGEV_THREAD;
    sSigEvent.sigev_value.sival_int = 1;
    sSigEvent.sigev_notify_function = phDriver_Linux_TimerCallBack;
    sSigEvent.sigev_notify_attributes = NULL;

    if(eTimerUnit == PH_DRIVER_TIMER_SECS)
    {
        xTimerVal.it_value.tv_sec = dwTimePeriod;
    }
    else if(eTimerUnit == PH_DRIVER_TIMER_MILLI_SECS)
    {
    	xTimerVal.it_value.tv_sec = (dwTimePeriod / 1000);
    	xTimerVal.it_value.tv_nsec = (dwTimePeriod % 1000) * 1000 * 1000;
    }
    else
    {
    	xTimerVal.it_value.tv_sec = (dwTimePeriod / 1000000);
    	xTimerVal.it_value.tv_nsec = (dwTimePeriod % 1000000) * 1000;
    }

    do{
        if(timer_create(CLOCK_REALTIME, &sSigEvent, &pPiTimer) !=0)
        {
            wStatus = PH_DRIVER_FAILURE | PH_COMP_DRIVER;
            break;
        }

        if(timer_settime(pPiTimer, 0, &xTimerVal, NULL) !=0)
        {
            wStatus = PH_DRIVER_FAILURE | PH_COMP_DRIVER;
            break;
        }

        if(pTimerCallBack == NULL)
        {
            /* Wait until timer expires. */
            while(bTimerExpired == false);
        }
    }while(0);

    return wStatus;
}


phStatus_t phDriver_TimerStop(void)
{
    phStatus_t wStatus = PH_DRIVER_SUCCESS;

    /* Disarm the Timer. */
    struct itimerspec xTimerVal = {{0, 0}, {0, 0}};

    do{
        if(timer_settime(pPiTimer, 0, &xTimerVal, NULL) !=0)
        {
            wStatus = PH_DRIVER_FAILURE | PH_COMP_DRIVER;
            break;
        }

        if(timer_delete(pPiTimer) != 0)
        {
            wStatus = PH_DRIVER_FAILURE | PH_COMP_DRIVER;
        }
    }while(0);

    return wStatus;
}



phStatus_t phDriver_PinConfig(uint32_t dwPinNumber, phDriver_Pin_Func_t ePinFunc, phDriver_Pin_Config_t *pPinConfig)
{
    phStatus_t wStatus = PH_DRIVER_ERROR | PH_COMP_DRIVER;
    bool output;

    do{
        if(ePinFunc == PH_DRIVER_PINFUNC_BIDIR)
        {
            break;
        }

        if(ePinFunc == PH_DRIVER_PINFUNC_INTERRUPT)
        {
            if((pPinConfig->eInterruptConfig == PH_DRIVER_INTERRUPT_LEVELZERO)
                    || (pPinConfig->eInterruptConfig == PH_DRIVER_INTERRUPT_LEVELONE))
            {
                break;
            }
        }

        wStatus = PiGpio_export(dwPinNumber);
        if(wStatus != PH_DRIVER_SUCCESS)
        {
            break;
        }

        /* For interrupt/input direction is In. */
        output = (ePinFunc == PH_DRIVER_PINFUNC_OUTPUT)?true:false;
        wStatus = PiGpio_set_direction(dwPinNumber, output);
        if (wStatus != PH_DRIVER_SUCCESS)
        {
            PiGpio_unexport(dwPinNumber);
            break;
        }

        if(ePinFunc == PH_DRIVER_PINFUNC_OUTPUT)
        {
            /* Set the default output value. */
            wStatus = PiGpio_Write(dwPinNumber, pPinConfig->bOutputLogic);
        }
        else if(ePinFunc == PH_DRIVER_PINFUNC_INTERRUPT)
        {
            switch(pPinConfig->eInterruptConfig)
            {
            case PH_DRIVER_INTERRUPT_RISINGEDGE:
                wStatus = PiGpio_set_edge(dwPinNumber, true, false);
                break;

            case PH_DRIVER_INTERRUPT_FALLINGEDGE:
                wStatus = PiGpio_set_edge(dwPinNumber, false, true);
                break;

            case PH_DRIVER_INTERRUPT_EITHEREDGE:
                wStatus = PiGpio_set_edge(dwPinNumber, true, true);
                break;
            default:
                /* Do Nothing. */
                break;
            }
        }

        if(wStatus != PH_DRIVER_SUCCESS)
        {
            PiGpio_unexport(dwPinNumber);
            break;
        }

    }while(0);

    return wStatus;
}

uint8_t phDriver_PinRead(uint32_t dwPinNumber, phDriver_Pin_Func_t ePinFunc)
{
    uint8_t bGpioVal = false;

    (void)PiGpio_read(dwPinNumber, &bGpioVal);

    return bGpioVal;
}

void phDriver_PinWrite(uint32_t dwPinNumber, uint8_t bValue)
{
    (void)PiGpio_Write(dwPinNumber, bValue);
}


void phDriver_PinClearIntStatus(uint32_t dwPinNumber)
{
    return;
}

