/*
* Copyright (c), NXP Semiconductors Bangalore / India
*
*               (C)NXP Semiconductors
* All rights are reserved. Reproduction in whole or in part is
* prohibited without the written consent of the copyright owner.
* NXP reserves the right to make changes without notice at any time.
* NXP makes no warranty, expressed, implied or statutory, including but
* not limited to any implied warranty of merchantability or fitness for any
* particular purpose, or that the use will not infringe any third party patent,
* copyright or trademark. NXP must not be liable for any loss or damage
* arising from its use.
*/

/** \file
* Generic MIFARE DESFire(R) EV2 Application Component of Reader Library Framework.
* $Author$
* $Revision$ (v05.07.00)
* $Date$
*
* History:
*  Santosh Araballi: Generated 31. August 2010
*
*/

#ifndef PHALMFDFEV2_H
#define PHALMFDFEV2_H

#include <ph_Status.h>
#include <phhalHw.h>
#include <phpalMifare.h>
#include <ph_TypeDefs.h>
#include <ph_RefDefs.h>

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#ifdef NXPBUILD__PHAL_MFDFEV2

/** \defgroup phalMfdfEv2 MIFARE DESFire (R) EV2
* \brief These Functions implement the MIFARE DESFire(R) EV2 commands.
* @{
*/


/**
* \name Authentication Modes
*/
/** @{ */
#define PHAL_MFDFEV2_AUTHENTICATE               0x0AU   /**< D40 Authentication; 0x0A. */
#define PHAL_MFDFEV2_AUTHENTICATEISO            0x1AU   /**< ISO Authentication; 0x1A. */
#define PHAL_MFDFEV2_AUTHENTICATEAES            0xAAU   /**< AES Authentication; 0xAA. */
#define PHAL_MFDFEV2_AUTHENTICATEEV2            0x71U   /**< Ev2 Authentication; 0x71. */
/** @} */

/**
* \name Diversification options to be used with ChangeKey and Authenticate
*/
/** @{ */
#define PHAL_MFDFEV2_NO_DIVERSIFICATION            0xFFFFU /**< No diversification. */
#define PHAL_MFDFEV2_CHGKEY_DIV_NEW_KEY            0x0002U /**< Bit 1. Indicating diversification of new key requred. */
#define PHAL_MFDFEV2_CHGKEY_DIV_OLD_KEY            0x0004U /**< Bit 2 indicating old key was diversified. */
#define PHAL_MFDFEV2_CHGKEY_DIV_NEW_KEY_ONERND     0x0008U /**< Bit 3 indicating new key diversification using one rnd. Default is two rounds. */
#define PHAL_MFDFEV2_CHGKEY_DIV_OLD_KEY_ONERND     0x0010U /**< Bit 4 indicating old key diversification using one rnd. Default is two rounds. */
#define PHAL_MFDFEV2_CHGKEY_DIV_METHOD_CMAC        0x0020U /**< Bit 5 indicating key diversification method based on CMAC. Default is Encryption method */
#define PHAL_MFDFEV2_DIV_METHOD_ENCR               PH_CRYPTOSYM_DIV_MODE_DESFIRE       /**< Encryption based method of diversification. */
#define PHAL_MFDFEV2_DIV_METHOD_CMAC               PH_CRYPTOSYM_DIV_MODE_MIFARE_PLUS   /**< CMAC based method of diversification. */
#define PHAL_MFDFEV2_DIV_OPTION_2K3DES_FULL        PH_CRYPTOSYM_DIV_OPTION_2K3DES_FULL /**< Encryption based method, full key diversification. */
#define PHAL_MFDFEV2_DIV_OPTION_2K3DES_HALF        PH_CRYPTOSYM_DIV_OPTION_2K3DES_HALF /**< Encryption based method, half key diversification. */
/** @} */

/**
* \name Other Options for various Functions
*/
/** @{ */
#define PHAL_MFDFEV2_NOT_AUTHENTICATED          0xFFU    /**< No authentication. */
#define PHAL_MFDFEV2_SET_CONFIG_OPTION0         0x00U    /**< Option 1 Data is the configuration byte. */
#define PHAL_MFDFEV2_SET_CONFIG_OPTION1         0x01U    /**< Option 1 Data is the configuration byte. */
#define PHAL_MFDFEV2_SET_CONFIG_OPTION2         0x02U    /**< Option 2 Data is default key version and key. */
#define PHAL_MFDFEV2_SET_CONFIG_OPTION3         0x03U    /**< Option 3 Data is user defined ATS. */
#define PHAL_MFDFEV2_SET_CONFIG_OPTION4         0x04U    /**< Option 4 Data is user defined SAK. */
#define PHAL_MFDFEV2_SET_CONFIG_OPTION5         0x05U    /**< Option 5 Data is Secure Messaging Configuration. */
#define PHAL_MFDFEV2_SET_CONFIG_OPTION6         0x06U    /**< Option 6 Data is VCIID: the Virtual Card Installation Identifier. */
#define PHAL_MFDFEV2_COMMUNICATION_PLAIN        0x00U    /**< Plain mode of communication. */
#define PHAL_MFDFEV2_COMMUNICATION_MACD         0x10U    /**< MAC mode of communication. */
#define PHAL_MFDFEV2_COMMUNICATION_ENC          0x30U    /**< Enciphered mode of communication. */
#define PHAL_MFDFEV2_ENABLE_LIMITEDCREDIT       0x01U    /**< Bit 0 set to 1 to enable Limited credit. */
#define PHAL_MFDFEV2_ENABLE_FREE_GETVALUE       0x02U    /**< Bit 1 set to 1 to enable free getvalue. */
#define PHAL_MFDFEV2_ADDITIONAL_INFO            0x00A1U   /**< Option for getconfig to get additional info of a generic error. */
#define PHAL_MFDFEV2_WRAPPED_MODE               0x00A2U   /**< Option for GetConfig/SetConfig to get/set current status of command wrapping in ISO 7816-4 APDUs. */
#define PHAL_MFDFEV2_ORIGINALITY_KEY_FIRST      0x01U    /**< Originality key for AES */
#define PHAL_MFDFEV2_ORIGINALITY_KEY_LAST       0x04U    /**< Originality key for AES  */
#define PHAL_MFDFEV2_MAC_DATA_INCOMPLETE        0x01U     /**< Option for indicating more data to come in next call for MAC calculation */
#define PHAL_MFDFEV2_COMMUNICATION_MAC_ON_RC    0x02U    /**< MAC is appended over response  */
#define PHAL_MFDFEV2_COMMUNICATION_MAC_ON_CMD   0x03U    /**< MAC is appended over command. */
#define PHAL_MFDFEV2_AUTHENTICATE_RESET         0x08U    /**< authentication state shall be reset */
#define PHAL_MFDFEV2_KEYSETVALUES_PRESENT       0x01U   /**< Bit 0 of bKeySettings3 decides the presence of the key set values array. */
#define PHAL_MFDFEV2_KEYSETT3_PRESENT           0x10U   /**< Bit 4 of bKeySettings2 decides the presence of the keysetting3. */
#define PHAL_MFDFEV2_SHORT_LENGTH_APDU          0xA3U    /**< Extended Length APDU presence */

/** @} */

/** \name phalMfdfEv2 Custom Error Codes
*/
/** @{ */
#define PHAL_MFDFEV2_NO_CHANGES                    ((phStatus_t)PH_ERR_CUSTOM_BEGIN + 0U)     /**< MF DF Response - No changes done to backup files. */
#define PHAL_MFDFEV2_ERR_OUT_OF_EEPROM_ERROR       ((phStatus_t)PH_ERR_CUSTOM_BEGIN + 1U)     /**< MF DF Response - Insufficient NV-Memory. */
#define PHAL_MFDFEV2_ERR_NO_SUCH_KEY               ((phStatus_t)PH_ERR_CUSTOM_BEGIN + 2U)     /**< MF DF Invalid key number specified. */
#define PHAL_MFDFEV2_ERR_PERMISSION_DENIED         ((phStatus_t)PH_ERR_CUSTOM_BEGIN + 3U)     /**< MF DF Current configuration/status does not allow the requested command. */
#define PHAL_MFDFEV2_ERR_APPLICATION_NOT_FOUND     ((phStatus_t)PH_ERR_CUSTOM_BEGIN + 4U)     /**< MF DF Requested AID not found on PICC. */
#define PHAL_MFDFEV2_ERR_BOUNDARY_ERROR            ((phStatus_t)PH_ERR_CUSTOM_BEGIN + 5U)     /**< MF DF Attempt to read/write data from/to beyond the files/record's limits. */
#define PHAL_MFDFEV2_ERR_COMMAND_ABORTED           ((phStatus_t)PH_ERR_CUSTOM_BEGIN + 6U)     /**< MF DF Previous cmd not fully completed. Not all frames were requested or provided by the PCD. */
#define PHAL_MFDFEV2_ERR_COUNT                     ((phStatus_t)PH_ERR_CUSTOM_BEGIN + 7U)     /**< MF DF Num. of applns limited to 28. No additional applications possible. */
#define PHAL_MFDFEV2_ERR_DUPLICATE                 ((phStatus_t)PH_ERR_CUSTOM_BEGIN + 8U)     /**< MF DF File/Application with same number already exists. */
#define PHAL_MFDFEV2_ERR_FILE_NOT_FOUND            ((phStatus_t)PH_ERR_CUSTOM_BEGIN + 9U)     /**< MF DF Specified file number does not exist. */
#define PHAL_MFDFEV2_ERR_PICC_CRYPTO               ((phStatus_t)PH_ERR_CUSTOM_BEGIN + 10U)    /**< MF DF Crypto error returned by PICC. */
#define PHAL_MFDFEV2_ERR_PARAMETER_ERROR           ((phStatus_t)PH_ERR_CUSTOM_BEGIN + 11U)    /**< MF DF Parameter value error returned by PICC. */
#define PHAL_MFDFEV2_ERR_DF_GEN_ERROR              ((phStatus_t)PH_ERR_CUSTOM_BEGIN + 12U)    /**< MF DF DesFire Generic error. Check additional Info. */
#define PHAL_MFDFEV2_ERR_DF_7816_GEN_ERROR         ((phStatus_t)PH_ERR_CUSTOM_BEGIN + 13U)    /**< MF DF ISO 7816 Generic error. Check Additional Info. */
#define PHAL_MFDFEV2_ERR_CMD_INVALID               ((phStatus_t)PH_ERR_CUSTOM_BEGIN + 14U)    /**< MF DF ISO 7816 Generic error. Check Additional Info. */
#define PHAL_MFDFEV2_ERR_ILLEGAL_COMMAND_CODE      ((phStatus_t)PH_ERR_CUSTOM_BEGIN + 15U)    /**< MF DF illegal command code. */
#define PHAL_MFDFEV2_ERR_INTEGRITY_ERROR           ((phStatus_t)PH_ERR_CUSTOM_BEGIN + 16U)    /**< MF DF integrity error. */
#define PHAL_MFDFEV2_ERR_MEMORY_ERROR              ((phStatus_t)PH_ERR_CUSTOM_BEGIN + 17U)    /**< MF DF memory error. */
/** @} */

/** \name phalMfdfEv2 Custom Error Codes Iso7816 commands.
*/
/** @{ */

#define PHAL_MFDFEV2_ISO7816_CUSTOM_ERR_MEMORY_FAILURE              ((phStatus_t)PH_ERR_CUSTOM_BEGIN + 18U)    /**< ISO7816 custom response code for memory failure. */
#define PHAL_MFDFEV2_ISO7816_CUSTOM_ERR_WRONG_LENGTH                ((phStatus_t)PH_ERR_CUSTOM_BEGIN + 19U)    /**< ISO7816 custom response code for wrong length, no further indication. */
#define PHAL_MFDFEV2_ISO7816_CUSTOM_ERR_SECURITY_STAT_NOT_SATISFIED ((phStatus_t)PH_ERR_CUSTOM_BEGIN + 20U)    /**< ISO7816 custom response code for security status not satisfied. */
#define PHAL_MFDFEV2_ISO7816_CUSTOM_ERR_CONDITIONS_NOT_SATISFIED    ((phStatus_t)PH_ERR_CUSTOM_BEGIN + 21U)    /**< ISO7816 custom response code for conditions of use not satisfied. */
#define PHAL_MFDFEV2_ISO7816_CUSTOM_ERR_FILE_APPLICATION_NOT_FOUND  ((phStatus_t)PH_ERR_CUSTOM_BEGIN + 22U)    /**< ISO7816 custom response code for file or application not found. */
#define PHAL_MFDFEV2_ISO7816_CUSTOM_ERR_INCORRECT_PARAM_P1_P2       ((phStatus_t)PH_ERR_CUSTOM_BEGIN + 23U)    /**< ISO7816 custom response code for incorrect parameters P1-P2. */
#define PHAL_MFDFEV2_ISO7816_CUSTOM_ERR_LC_INCONSISTENT             ((phStatus_t)PH_ERR_CUSTOM_BEGIN + 24U)    /**< ISO7816 custom response code for Lc inconsistent with parameter P1-P2. */
#define PHAL_MFDFEV2_ISO7816_CUSTOM_ERR_WRONG_LE                    ((phStatus_t)PH_ERR_CUSTOM_BEGIN + 25U)    /**< ISO7816 custom response code for wrong LE field. */
#define PHAL_MFDFEV2_ISO7816_CUSTOM_ERR_INS_CODE_NOT_SUPPORTED      ((phStatus_t)PH_ERR_CUSTOM_BEGIN + 26U)    /**< ISO7816 custom response code for instruction code not supported or invalid. */

/** @} */

/**
* \name Sizes
*/
/*@{*/
#define PHAL_MFDFEV2_SIZE_TI            4U      /**< Size of Transaction Identifier. */
#define PHAL_MFDFEV2_SIZE_MAC           16U     /**< Size of (untruncated) MAC. */
#define PHAL_MFDFEV2_BLOCK_SIZE         16U     /**< Block Size */
#define PHAL_MFDFEV2_MAX_WRITE_SIZE     0xFFFDU /**< Max size in a Write function. */
/*@}*/


/**
* \name Key Types
*/
/*@{*/
#define PHAL_MFDFEV2_KEY_TYPE_2K3DES            0x00U     /**< 2 Key Triple Des */
#define PHAL_MFDFEV2_KEY_TYPE_3K3DES            0x01U     /**< 3 Key Triple Des */
#define PHAL_MFDFEV2_KEY_TYPE_AES128            0x02U      /**< AES 128 Key */
/*@}*/

/** @} */

#endif /* NXPBUILD__PHAL_MFDFEV2 */

#ifdef NXPBUILD__PHAL_MFDFEV2_SW

/**
* \defgroup phalMfdfEv2_Sw Component : Software
*/
/*@{*/

#define PHAL_MFDFEV2_SW_ID 0x01U   /**< ID for Software MF DesFire layer. */

/**
* \brief struct phalMfdfEv2_Sw_DataParams_t
*
*/
typedef struct
{
    uint16_t wId;                                               /**< Layer ID for this component, NEVER MODIFY! */
    void * pPalMifareDataParams;                                /**< Pointer to the parameter structure of the palMifare component. */
    void * pKeyStoreDataParams;                                 /**< Pointer to the parameter structure of the KeyStore layer. */
    void * pCryptoDataParamsEnc;                                /**< Pointer to the parameter structure of the Crypto layer for encryption. */
    void * pCryptoDataParamsMac;                                /**< Pointer to the parameter structure of the CryptoMAC. */
    void * pCryptoRngDataParams;                                /**< Pointer to the parameter structure of the CryptoRng layer. */
    void * pHalDataParams;                                      /**< Pointer to the HAL parameters structure. */
    uint8_t bSesAuthENCKey[24];                                 /**< Session key for this authentication */
    uint8_t bKeyNo;                                             /**< key number against which this authentication is done */
    uint8_t bIv[16];                                            /**< Max size of IV can be 16 bytes */
    uint8_t bAuthMode;                                          /**< Authenticate (0x0A), AuthISO (0x1A), AuthAES (0xAA) */
    uint8_t pAid[3];                                            /**< Aid of the currently selected application */
    uint8_t bCryptoMethod;                                      /**< DES,3DES, 3K3DES or AES */
    uint8_t bWrappedMode;                                       /**< Wrapped APDU mode. All native commands need to be sent wrapped in ISO 7816 APDUs. */
    uint16_t wCrc;                                              /**< 2 Byte CRC initial value in Authenticate mode. */
    uint32_t dwCrc;                                             /**< 4 Byte CRC initial value in 0x1A, 0xAA mode. */
    uint16_t wAdditionalInfo;                                   /**< Specific error codes for Desfire generic errors. */
    uint32_t dwPayLoadLen;                                       /**< Amount of data to be read. Required for Enc read to verify CRC. */
    uint16_t wCmdCtr ;                                          /**< Command count within transaction. */
    uint8_t bTi[PHAL_MFDFEV2_SIZE_TI];                          /**< Transaction Identifier. */
    uint8_t bSesAuthMACKey[16];                                 /**< Authentication MAC key for the session. */
    uint8_t pUnprocByteBuff[PHAL_MFDFEV2_SIZE_MAC];             /**< Buffer containing unprocessed bytes for read mac answer stream. */
    uint8_t bNoUnprocBytes;                                     /**< Amount of data in the pUnprocByteBuff. */
    uint8_t bLastBlockBuffer[16];                               /**< Buffer to store last Block of encrypted data in case of chaining. */
    uint8_t bLastBlockIndex;                                    /**< Last Block Buffer Index. */
    void * pTMIDataParams;                                      /**< Pointer to the parameter structure for collecting TMI. */
    uint8_t bShortLenApdu;                                      /**< Parameter for force set Short Length APDU in case of BIG ISO read. */
    void * pVCADataParams;                                      /**< Pointer to the parameter structure for Virtual Card. */
} phalMfdfEv2_Sw_DataParams_t;

/**
* \brief Initialise this layer.
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
*/
phStatus_t phalMfdfEv2_Sw_Init(
                              phalMfdfEv2_Sw_DataParams_t * pDataParams,   /**< [In] Pointer to this layer's parameter structure. */
                              uint16_t wSizeOfDataParams,                  /**< [In] Specifies the size of the data parameter structure */
                              void * pPalMifareDataParams,                 /**< [In] Pointer to a palMifare component context. */
                              void * pKeyStoreDataParams,                  /**< [In] Pointer to Key Store data parameters. */
                              void * pCryptoDataParamsEnc,                 /**< [In] Pointer to a Crypto component context for encryption. */
                              void * pCryptoDataParamsMac,                 /**< [In] Pointer to a CryptoMAC component context. */
                              void * pCryptoRngDataParams,                 /**< [In] Pointer to a CryptoRng component context. */
                              void * pTMIDataParams,                       /**< [In] Pointer to a TMI component. */
                              void * pVCADataParams,                       /**< [In] Pointer to a VCA component. */
                              void * pHalDataParams                        /**< [In] Pointer to the HAL parameters structure. */
                              );

phStatus_t phalMfdfEv2_Sw_SetVCAParams(
                               phalMfdfEv2_Sw_DataParams_t * pDataParams,
                               void * pAlVCADataParams
                               );
/** @} */

#endif /* NXPBUILD__PHAL_MFDFEV2_SW */



#ifdef NXPBUILD__PHAL_MFDFEV2

/** \addtogroup phalMfdfEv2
* @{
*/

/**
* \name Security related Commands
*/
/** @{ */

/**
* \brief Performs an Authentication with the specified key number.
*
* The command can be used with DES and 2K3DES keys and performs DESFire4 native
* authentication.
*
* Diversification option (wOption) can be one of \n
* \li for Sw \n
* \li #PHAL_MFDFEV2_DIV_METHOD_ENCR  OR \n
* \li #PHAL_MFDFEV2_DIV_METHOD_ENCR | #PHAL_MFDFEV2_DIV_OPTION_2K3DES_HALF OR \n
* \li #PHAL_MFDFEV2_DIV_METHOD_ENCR | #PHAL_MFDFEV2_DIV_OPTION_2K3DES_FULL OR \n
* \li #PHAL_MFDFEV2_DIV_METHOD_CMAC OR \n
* \li #PHAL_MFDFEV2_NO_DIVERSIFICATION \n
*  \n
* \li for Sam Av3 NonX \n
* \li Option for Authentication mode and Authentication type \n
* \li (0x00)    PHALMFDFEV2_SAM_NONX_AUTH_MODE_D40 \n
* \li (0x00)    PHALMFDFEV2_SAM_NONX_AUTH_MODE_EV1 \n
* \n
* \li Option for Key Derivation Information and Key Diversification Types. \n
* \li (0x20)    PHALMFDFEV2_SAM_NONX_NO_KDF \n
* \li (0x00)    PHALMFDFEV2_SAM_NONX_KDF_AV1 \n
* \li (0x00)    PHALMFDFEV2_SAM_NONX_KDF_AV1_DOUBLE_ENCRYPTION \n
* \li (0x08)    PHALMFDFEV2_SAM_NONX_KDF_AV1_SINGLE_ENCRYPTION \n
* \li (0x10)    PHALMFDFEV2_SAM_NONX_KDF_AV2 \n
* \li (0x18)    PHALMFDFEV2_SAM_NONX_KDF_RFU \n
* \n
* \li Option for Key Selection \n
* \li (0x00)    PHALMFDFEV2_SAM_NONX_KEY_SELECTION_KEY_ENTRY \n
* \li (0x02)    PHALMFDFEV2_SAM_NONX_KEY_SELECTION_DESFIRE \n
* \n
* \li Option for Key Diversification \n
* \li (0x00)    PHALMFDFEV2_SAM_NONX_KEY_DIVERSIFICATION_OFF \n
* \li (0x01)    PHALMFDFEV2_SAM_NONX_KEY_DIVERSIFICATION_ON \n
*
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfdfEv2_Authenticate(
                                    void *pDataParams,     /**< [In] Pointer to this layer's parameter structure. */
                                    uint16_t wOption,      /**< [In] Options mentioned in the description. Multiple options canbe sent by Oring.  */
                                    uint16_t wKeyNo,       /**< [In] key number in keystore of software or SAM. */
                                    uint16_t wKeyVer,      /**< [In] Key version in the key store of software or SAM. */
                                    uint8_t bKeyNoCard,    /**< [In] Key number on card. ORed with PHAL_MFDF_SAI to indicate Shared application identifier. */
                                    uint8_t * pDivInput,   /**< [In] Diversification input. Can be NULL. */
                                    uint8_t bDivLen        /**< [In] Length of diversification input max 31B. */
                                    );


/**
* \brief Performs an DES Authentication in ISO CBS send mode.
*
* The command can be used with DES,3DES and 3K3DES keys
*
* Diversification option (wOption) can be one of \n
* \li for Sw \n
* \li #PHAL_MFDFEV2_DIV_METHOD_ENCR  OR \n
* \li #PHAL_MFDFEV2_DIV_METHOD_ENCR | #PHAL_MFDFEV2_DIV_OPTION_2K3DES_HALF OR \n
* \li #PHAL_MFDFEV2_DIV_METHOD_ENCR | #PHAL_MFDFEV2_DIV_OPTION_2K3DES_FULL OR \n
* \li #PHAL_MFDFEV2_DIV_METHOD_CMAC OR \n
* \li #PHAL_MFDFEV2_NO_DIVERSIFICATION \n
*  \n
* \li for Sam Av3 NonX \n
* \li Option for Authentication mode and Authentication type \n
* \li (0x00)    PHALMFDFEV2_SAM_NONX_AUTH_MODE_D40 \n
* \li (0x00)    PHALMFDFEV2_SAM_NONX_AUTH_MODE_EV1 \n
* \n
* \li Option for Key Derivation Information and Key Diversification Types. \n
* \li (0x20)    PHALMFDFEV2_SAM_NONX_NO_KDF \n
* \li (0x00)    PHALMFDFEV2_SAM_NONX_KDF_AV1 \n
* \li (0x00)    PHALMFDFEV2_SAM_NONX_KDF_AV1_DOUBLE_ENCRYPTION \n
* \li (0x08)    PHALMFDFEV2_SAM_NONX_KDF_AV1_SINGLE_ENCRYPTION \n
* \li (0x10)    PHALMFDFEV2_SAM_NONX_KDF_AV2 \n
* \li (0x18)    PHALMFDFEV2_SAM_NONX_KDF_RFU \n
* \n
* \li Option for Key Selection \n
* \li (0x00)    PHALMFDFEV2_SAM_NONX_KEY_SELECTION_KEY_ENTRY \n
* \li (0x02)    PHALMFDFEV2_SAM_NONX_KEY_SELECTION_DESFIRE \n
* \n
* \li Option for Key Diversification \n
* \li (0x00)    PHALMFDFEV2_SAM_NONX_KEY_DIVERSIFICATION_OFF \n
* \li (0x01)    PHALMFDFEV2_SAM_NONX_KEY_DIVERSIFICATION_ON \n
*
*
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfdfEv2_AuthenticateISO(
                                       void *pDataParams,      /**< [In] Pointer to this layer's parameter structure. */
                                       uint16_t wOption,       /**< [In] Diversification option. */
                                       uint16_t wKeyNo,        /**< [In] key number in keystore to authenticate with. */
                                       uint16_t wKeyVer,       /**< [In] Key version in the key store. */
                                       uint8_t bKeyNoCard,     /**< [In] Key number on card. Can be ORed with PHAL_MFDF_SAI for shared application identifier. */
                                       uint8_t * pDivInput,    /**< [In] Diversification input. Can be NULL. */
                                       uint8_t bDivLen         /**< [In] Length of diversification input max 31B. */
                                       );


/**
* \brief Performs an AES Authentication.
*
* The command should be used with AES128 keys
*
* Diversification option (wOption) can be one of \n
* \li #PHAL_MFDFEV2_DIV_METHOD_ENCR OR \n
* \li #PHAL_MFDFEV2_DIV_METHOD_CMAC OR \n
* \li #PHAL_MFDFEV2_NO_DIVERSIFICATION \n
*
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfdfEv2_AuthenticateAES(
                                       void *pDataParams,      /**< [In] Pointer to this layer's parameter structure. */
                                       uint16_t wOption,       /**< [In] Diversification option. */
                                       uint16_t wKeyNo,        /**< [In] key number in keystore to authenticate with. */
                                       uint16_t wKeyVer,       /**< [In] Key version in the key store. */
                                       uint8_t bKeyNoCard,     /**< [In] Key number on card. Can be ORed with SAI */
                                       uint8_t * pDivInput,    /**< [In] Diversification input. Can be NULL. */
                                       uint8_t bDivLen         /**< [In] Length of diversification input max 31B. */
                                       );

/**
* \brief Performs an Ev2 First or Ev2 Non First Authentication depending upon bFirstAuth Parameter.
*
* The command should be used with AES128 keys
*
* Diversification option (wOption) can be one of \n
* \li for Sw \n
* \li #PHAL_MFDFEV2_DIV_METHOD_ENCR OR \n
* \li #PHAL_MFDFEV2_DIV_METHOD_CMAC OR \n
* \li #PHAL_MFDFEV2_NO_DIVERSIFICATION \n
* \n
* \li for Sam Av3 NonX \n
* \li Option for Key Derivation Information and Key Diversification Types. \n
* \li (0x20)    PHALMFDFEV2_SAM_NONX_NO_KDF \n
* \li (0x00)    PHALMFDFEV2_SAM_NONX_KDF_AV1 \n
* \li (0x00)    PHALMFDFEV2_SAM_NONX_KDF_AV1_DOUBLE_ENCRYPTION \n
* \li (0x08)    PHALMFDFEV2_SAM_NONX_KDF_AV1_SINGLE_ENCRYPTION \n
* \li (0x10)    PHALMFDFEV2_SAM_NONX_KDF_AV2 \n
* \li (0x18)    PHALMFDFEV2_SAM_NONX_KDF_RFU \n
* \n
* \li Option for Key Selection \n
* \li (0x00)    PHALMFDFEV2_SAM_NONX_KEY_SELECTION_KEY_ENTRY \n
* \li (0x02)    PHALMFDFEV2_SAM_NONX_KEY_SELECTION_DESFIRE \n
* \n
* \li Option for Key Diversification \n
* \li (0x00)    PHALMFDFEV2_SAM_NONX_KEY_DIVERSIFICATION_OFF \n
* \li (0x01)    PHALMFDFEV2_SAM_NONX_KEY_DIVERSIFICATION_ON \n
*
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfdfEv2_AuthenticateEv2(
                                       void *pDataParams,      /**< [In] Pointer to this layer's parameter structure. */
                                       uint8_t bFirstAuth,     /**< [In] \c 0: Following Authentication; \c 1: First Authentication; */
                                       uint16_t wOption,       /**< [In] Options mentioned in the description. Multiple options canbe sent by Oring. */
                                       uint16_t wKeyNo,        /**< [In] key number in keystore to authenticate with. */
                                       uint16_t wKeyVer,       /**< [In] Key version in the key store. */
                                       uint8_t bKeyNoCard,     /**< [In] Key number on card. Bit 7 indicates SAI. */
                                       uint8_t * pDivInput,    /**< [In] Diversification input. Can be NULL. */
                                       uint8_t bDivLen,        /**< [In] Length of diversification input max 31B. */
                                       uint8_t bLenPcdCapsIn,  /**< [In] Length of PcdCapsIn. Always zero for following authentication */
                                       uint8_t *bPcdCapsIn,    /**< [In] PCD Capabilities. Upto 6 bytes. */
                                       uint8_t *bPcdCapsOut,   /**< [Out] PCD Capabilities. 6 bytes. */
                                       uint8_t *bPdCapsOut     /**< [Out] PD Capabilities. 6 bytes. */
                                       );

/**
* \brief Changes the master key settings on PICC and application level.
*
*
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfdfEv2_ChangeKeySettings(
                                         void * pDataParams,   /**< [In] Pointer to this layer's parameter structure. */
                                         uint8_t bKeySettings  /**< [In] New key settings. */
                                         );

/**
* \brief Gets information on the PICC and application master key
* settings.
*
* \remarks
* In addition it returns the maximum number of keys
* which are configured for the selected application.
*
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfdfEv2_GetKeySettings(
                                      void * pDataParams,      /**< [In] Pointer to this layer's parameter structure. */
                                      uint8_t * pKeySettings,  /**< [Out]: 2 or 3 bytes key settings. */
                                      uint8_t * bRespLen       /**< [Out]: length of the response received. */
                                      );


/**
* \brief Changes any key on the PICC
*
* \remarks
* The key on the PICC is changed to the new key.
* The key type of the application keys cannot be changed. The key type of only the PICC master key
* can be changed. The keys changeable are PICCDAMAuthKey, PICCDAMMACKey, PICCDAMEncKey, VCConfigurationKey,
* SelectVCKey, VCProximityKey, VCPollingEncKey, VCPollingMACKey.
*
* Diversification option can be one or combination of of \n
* \li for Sw \n
* \li #PHAL_MFDFEV2_NO_DIVERSIFICATION OR \n
* \li #PHAL_MFDFEV2_CHGKEY_DIV_NEW_KEY | #PHAL_MFDFEV2_CHGKEY_DIV_METHOD_CMAC \n
* \li #PHAL_MFDFEV2_CHGKEY_DIV_OLD_KEY | #PHAL_MFDFEV2_CHGKEY_DIV_METHOD_CMAC \n
* \li #PHAL_MFDFEV2_CHGKEY_DIV_NEW_KEY | #PHAL_MFDFEV2_CHGKEY_DIV_NEW_KEY_ONERND \n
* \li #PHAL_MFDFEV2_CHGKEY_DIV_OLD_KEY | #PHAL_MFDFEV2_CHGKEY_DIV_OLD_KEY_ONERND \n
* \li #PHAL_MFDFEV2_CHGKEY_DIV_NEW_KEY | #PHAL_MFDFEV2_CHGKEY_DIV_OLD_KEY \n
* \li #PHAL_MFDFEV2_CHGKEY_DIV_NEW_KEY | #PHAL_MFDFEV2_CHGKEY_DIV_OLD_KEY | #PHAL_MFDFEV2_CHGKEY_DIV_METHOD_CMAC \n
* \li #PHAL_MFDFEV2_CHGKEY_DIV_NEW_KEY | #PHAL_MFDFEV2_CHGKEY_DIV_OLD_KEY | #PHAL_MFDFEV2_CHGKEY_DIV_NEW_KEY_ONERND | #PHAL_MFDFEV2_CHGKEY_DIV_OLD_KEY_ONERND \n
* \n
* \li for Sam Av3 NonX \n
* \li Key diversification method. \n
* \li (0x00)    PHALMFDFEV2_SAM_NONX_DIV_METHOD_AV1 \n
* \li (0x20)    PHALMFDFEV2_SAM_NONX_DIV_METHOD_AV2 \n
* \n
* \li Sam AV1 and Sam AV2 Key diversification method\n
* \li (0x00)    PHALMFDFEV2_SAM_NONX_KDF_RFU \n
* \li (0x00)    PHALMFDFEV2_SAM_NONX_KDF_CURRENT_KEY_DOUBLE_ENCRYPTION \n
* \li (0x10)    PHALMFDFEV2_SAM_NONX_KDF_CURRENT_KEY_SINGLE_ENCRYPTION \n
* \li (0x00)    PHALMFDFEV2_SAM_NONX_KDF_NEW_KEY_DOUBLE_ENCRYPTION \n
* \li (0x08)    PHALMFDFEV2_SAM_NONX_KDF_NEW_KEY_SINGLE_ENCRYPTION \n
* \li (0x00)    PHALMFDFEV2_SAM_NONX_KDF_CURRENT_KEY_OFF \n
* \li (0x04)    PHALMFDFEV2_SAM_NONX_KDF_CURRENT_KEY_ON \n
* \li (0x00)    PHALMFDFEV2_SAM_NONX_KDF_NEW_KEY_OFF \n
* \li (0x02)    PHALMFDFEV2_SAM_NONX_KDF_NEW_KEY_ON \n
* \n
* \li Cryptogram computation mode \n
* \li (0x00)    PHALMFDFEV2_SAM_NONX_CRYPTO_MODE_TARGET_AUTH_KEY_DIFFERENT \n
* \li (0x01)    PHALMFDFEV2_SAM_NONX_CRYPTO_MODE_TARGET_AUTH_KEY_SAME \n
* \n
* \li PICC master key update \n
* \li (0x00)    PHALMFDFEV2_SAM_NONX_MASTER_KEY_UPDATE_EXCLUDE_KEYTYPE \n
* \li (0x40)    PHALMFDFEV2_SAM_NONX_MASTER_KEY_UPDATE_INCLUDE_KEYTYPE
*
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfdfEv2_ChangeKey(
                                 void * pDataParams,     /**< [In] Pointer to this layer's parameter structure. */
                                 uint16_t wOption,       /**< [In] Diversification option. */
                                 uint16_t wOldKeyNo,     /**< [In] Old key number in keystore. */
                                 uint16_t wOldKeyVer,    /**< [In] Old key version in keystore. */
                                 uint16_t wNewKeyNo,     /**< [In] New key number in keystore. */
                                 uint16_t wNewKeyVer,    /**< [In] New key version in keystore. */
                                 uint8_t bKeyNoCard,     /**< [In] One byte Card number to be changed. Bit 7 will indicate SAI if card master app is not selected else bit 7,6 indicate key type. */
                                 uint8_t * pDivInput,    /**< [In] Diversification input. Can be NULL. */
                                 uint8_t bDivLen         /**< [In] Length of diversification input max 31B. */
                                 );

/**
* \brief Changes any key present in keyset on the PICC
*
* \remarks
* The key on the PICC is changed to the new key.
* The key type of the application keys cannot be changed. The key type of only the PICC master key
* can be changed. The keys changeable are PICCDAMAuthKey, PICCDAMMACKey, PICCDAMEncKey, VCConfigurationKey,
* SelectVCKey, VCProximityKey, VCPollingEncKey, VCPollingMACKey.
*
* Diversification option can be one or combination of of \n
* \li for Sw \n
* \li #PHAL_MFDFEV2_NO_DIVERSIFICATION OR \n
* \li #PHAL_MFDFEV2_CHGKEY_DIV_NEW_KEY | #PHAL_MFDFEV2_CHGKEY_DIV_METHOD_CMAC \n
* \li #PHAL_MFDFEV2_CHGKEY_DIV_OLD_KEY | #PHAL_MFDFEV2_CHGKEY_DIV_METHOD_CMAC \n
* \li #PHAL_MFDFEV2_CHGKEY_DIV_NEW_KEY | #PHAL_MFDFEV2_CHGKEY_DIV_NEW_KEY_ONERND \n
* \li #PHAL_MFDFEV2_CHGKEY_DIV_OLD_KEY | #PHAL_MFDFEV2_CHGKEY_DIV_OLD_KEY_ONERND \n
* \li #PHAL_MFDFEV2_CHGKEY_DIV_NEW_KEY | #PHAL_MFDFEV2_CHGKEY_DIV_OLD_KEY \n
* \li #PHAL_MFDFEV2_CHGKEY_DIV_NEW_KEY | #PHAL_MFDFEV2_CHGKEY_DIV_OLD_KEY | #PHAL_MFDFEV2_CHGKEY_DIV_METHOD_CMAC \n
* \li #PHAL_MFDFEV2_CHGKEY_DIV_NEW_KEY | #PHAL_MFDFEV2_CHGKEY_DIV_OLD_KEY | #PHAL_MFDFEV2_CHGKEY_DIV_NEW_KEY_ONERND | #PHAL_MFDFEV2_CHGKEY_DIV_OLD_KEY_ONERND \n
* \n
* \li for Sam Av3 NonX \n
* \li Key diversification method. \n
* \li (0x00)    PHALMFDFEV2_SAM_NONX_DIV_METHOD_AV1 \n
* \li (0x20)    PHALMFDFEV2_SAM_NONX_DIV_METHOD_AV2 \n
* \n
* \li Sam AV1 and Sam AV2 Key diversification method\n
* \li (0x00)    PHALMFDFEV2_SAM_NONX_KDF_RFU \n
* \li (0x00)    PHALMFDFEV2_SAM_NONX_KDF_CURRENT_KEY_DOUBLE_ENCRYPTION \n
* \li (0x10)    PHALMFDFEV2_SAM_NONX_KDF_CURRENT_KEY_SINGLE_ENCRYPTION \n
* \li (0x00)    PHALMFDFEV2_SAM_NONX_KDF_NEW_KEY_DOUBLE_ENCRYPTION \n
* \li (0x08)    PHALMFDFEV2_SAM_NONX_KDF_NEW_KEY_SINGLE_ENCRYPTION \n
* \li (0x00)    PHALMFDFEV2_SAM_NONX_KDF_CURRENT_KEY_OFF \n
* \li (0x04)    PHALMFDFEV2_SAM_NONX_KDF_CURRENT_KEY_ON \n
* \li (0x00)    PHALMFDFEV2_SAM_NONX_KDF_NEW_KEY_OFF \n
* \li (0x02)    PHALMFDFEV2_SAM_NONX_KDF_NEW_KEY_ON \n
* \n
* \li Cryptogram computation mode \n
* \li (0x00)    PHALMFDFEV2_SAM_NONX_CRYPTO_MODE_TARGET_AUTH_KEY_DIFFERENT \n
* \li (0x01)    PHALMFDFEV2_SAM_NONX_CRYPTO_MODE_TARGET_AUTH_KEY_SAME \n
* \n
* \li PICC master key update \n
* \li (0x00)    PHALMFDFEV2_SAM_NONX_MASTER_KEY_UPDATE_EXCLUDE_KEYTYPE \n
* \li (0x40)    PHALMFDFEV2_SAM_NONX_MASTER_KEY_UPDATE_INCLUDE_KEYTYPE
*
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfdfEv2_ChangeKeyEv2(
                                    void * pDataParams,     /**< [In] Pointer to this layer's parameter structure. */
                                    uint16_t wOption,       /**< [In] Diversification option. */
                                    uint16_t wOldKeyNo,     /**< [In] Old key number in keystore. */
                                    uint16_t wOldKeyVer,    /**< [In] Old key version in keystore. */
                                    uint16_t wNewKeyNo,     /**< [In] New key number in keystore. */
                                    uint16_t wNewKeyVer,    /**< [In] New key version in keystore. */
                                    uint8_t bKeySetNo,      /**< [In] Key set number. */
                                    uint8_t bKeyNoCard,     /**< [In] One byte key number to be changed. If AID=000000, then bits 7,6 indicate the key type else bit 7 indicates SAI. */
                                    uint8_t * pDivInput,    /**< [In] Diversification input. Can be NULL. */
                                    uint8_t bDivLen         /**< [In] Length of diversification input max 31B. */
                                    );

/**
* \brief Reads out the current key version of any key stored on the PICC
*
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfdfEv2_GetKeyVersion(
                                     void * pDataParams,    /**< [In] Pointer to this layer's parameter structure. */
                                     uint8_t bKeyNo,        /**< [In] 1 byte Card key number. Bit 7 indicates SAI. Bit 6 indicates key version retrieval or keyset version retrieval. */
                                     uint8_t bKeySetNo,     /**< [In] 1 byte Key set number. Optional as it is passed only when bit[6] of bKeyNo is set. */
                                     uint8_t * pKeyVersion, /**< [Out] 1 byte key version or 2..16 bytes keyset version. */
                                     uint8_t * bRxLen       /**< [Out] Length of Response received. */
                                     );

/**
* \brief Initializes KeySet with bKeySetNo specified with type of the keyset bKeyType
*
* \remarks
* Sets the KeySetVersion to 0x00
*
* bkeytype Possible Values are:\n
* \li #PHAL_MFDFEV2_KEY_TYPE_2K3DES
* \li #PHAL_MFDFEV2_KEY_TYPE_AES128
* \li #PHAL_MFDFEV2_KEY_TYPE_3K3DES
*
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfdfEv2_InitializeKeySet(
                                        void * pDataParams,                /**< [In] Pointer to this layer's parameter structure. */
                                        uint8_t bKeySetNo,                 /**< [In] KeySet Number. Bit 7 indicates SAI. */
                                        uint8_t bKeyType                   /**< [In] 1 byte Card key type. it can be PHAL_MFDFEV2_KEY_TYPE_AES128/KEY_TYPE_2K3DES/KEY_TYPE_3K3DES*/
                                        );

/**
* \brief Finalizes KeySet targeted by bKeySetNo by setting the key set version to the bKeySetVersion
*
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfdfEv2_FinalizeKeySet(
                                      void * pDataParams,           /**< [In] Pointer to this layer's parameter structure. */
                                      uint8_t bKeySetNo,            /**< [In] KeySet number. Can be 1 to 15. Bit 7 indicates SAI */
                                      uint8_t bKeySetVersion        /**< [In] KeySet version of the key set to be finalized. */
                                      );

/**
* \brief RollKeySet changes the ActiveKeySet to key set currently targeted with bKeySetNumber
*
* \remarks
* After successful execution of this command the keys of new AKS can be used
* Any active authentication is lost
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t  phalMfdfEv2_RollKeySet(
                                   void * pDataParams,      /**< [In] Pointer to this layer's parameter structure. */
                                   uint8_t bKeySetNo        /**< [In] KeySet number. Can be 1 to 15. Bit 7 will indicate SAI. */
                                   );

/** @} */

/**
* \name PICC level Commands
*/
/** @{ */

/**
* \brief Creates new applications on the PICC
*
* bOption value can be \n
* \li 01 meaning wISOFileId is supplied \n
* \li 02 meaning pISODFName is present \n
* \li 03 meaning both wISOFileId and pISODFName are present \n
* \li 00 meaning both not present
*
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfdfEv2_CreateApplication(
                                         void * pDataParams,       /**< [In] Pointer to this layers param structure */
                                         uint8_t bOption,          /**< [In] Option parameter. Will indicate the presence of ISO File Id and DF Name. */
                                         uint8_t * pAid,           /**< [In] array of 3 bytes. */
                                         uint8_t bKeySettings1,    /**< [In] 1 byte. */
                                         uint8_t bKeySettings2,    /**< [In] 1 byte. bit 4 of this byte should be set to 1 if KeySetting3 is present. */
                                         uint8_t bKeySettings3,    /**< [In] 1 byte. bit 0 of this byte should be set to 1 if pKeySetValues is valid. */
                                         uint8_t * pKeySetValues,  /**< [In] 4 byte keyset values. Byte0 = AKS ver, byte1 = keysets, byte2 = MaxKeysize, byte3 = AppKeySetSettings */
                                         uint8_t * pISOFileId,     /**< [In] 2 btyes ISO File ID. */
                                         uint8_t * pISODFName,     /**< [In] 1 to 16 Bytes. Can also be NULL. */
                                         uint8_t bISODFNameLen     /**< [In] Size of pISODFName if that is present. */
                                         );

/**
* \brief Creates new Delegated application
* For delegated application creation, the PICC level (AID 0x000000) must have been selected.
* An active authentication with the PICCDAMAuthKey is required.
* bOption value can be \n
* \li 01 meaning wISOFileId is supplied \n
* \li 02 meaning pISODFName is present \n
* \li 03 meaning both wISOFileId and pISODFName are present \n
* \li 00 meaning both not present
*
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfdfEv2_CreateDelegatedApplication(
    void * pDataParams,       /**< [In] Pointer to this layers param structure */
    uint8_t bOption,          /**< [In] Option parameter. Indicates the presence of ISO File Id, ISO DFName */
    uint8_t * pAid,           /**< [In] array of 3 bytes. */
    uint8_t * pDamParams,     /**< [In] 5 byte array. Byte0, byte1  = DAM Slot, Byte2 = DAMSlotVersion, Byte3, Byte 4  = QuotaLimit. Multiple of 32 byte block. */
    uint8_t bKeySettings1,    /**< [In] 1 byte Application key settings. */
    uint8_t bKeySettings2,    /**< [In] 1 byte. bit 4 of this byte should be set to 1 if KeySetting3 is present. */
    uint8_t bKeySettings3,    /**< [In] 1 byte. bit 0 of this byte should be set to 1 if bKeySetValues is valid. */
    uint8_t * bKeySetValues,  /**< [In] 4 byte keyset values. Byte0 = AKS ver, byte1 = keysets, byte2 = MaxKeysize, byte3 = AppKeySetSettings */
    uint8_t * pISOFileId,     /**< [In] 2 bytes ISO File ID. */
    uint8_t * pISODFName,     /**< [In] 1 to 16 Bytes. Can also be NULL. */
    uint8_t bISODFNameLen,    /**< [In] Size of pISODFName if that is present. */
    uint8_t * pEncK,            /**< [In] Encrypted initial application key. 32 bytes long. */
    uint8_t * pDAMMAC           /**< [In] 8 byte DAM MAC. */
    );

/**
* \brief Permanently deactivates applications on the PICC
*
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfdfEv2_DeleteApplication(
    void * pDataParams,   /**< [In] Pointer to this layers param structure. */
    uint8_t * pAid        /**< [In] 3 byte array. LSB First. */
    );

/**
* \brief Returns application identifiers of all applications on the PICC
*
* \remarks
* This response will be PH_ERR_SUCCESS if all the application ids can be
* obtained in one call. If not, then PH_ERR_SUCCESS_CHAINING is returned.
* The user has to call this function with bOption = PH_ERR_SUCCESS_CHAINING
* to get the remaining AIDs.
*
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval #PH_ERR_SUCCESS_CHAINING Operation successful with chaining.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfdfEv2_GetApplicationIDs(
                                         void * pDataParams,   /**< [In] Pointer to this layers param structure. */
                                         uint8_t bOption,      /**< [In] Option field specifying PH_EXCHANGE_DEFAULT or PH_EXCHANGE_RXCHAINING */
                                         uint8_t ** pAidBuff,  /**< [Out] Buffer for storing obtained AIDs */
                                         uint8_t * pNumAIDs     /**< [Out] Number of AIDs read. */
                                         );

/**
* \brief Returns the Dedicated File(DF) names
*
* \remarks
* The pDFBuffer will be filled with 3 byte AID + 2 byte ISO Fid + one DF Name
* at a time.If there are more DFs, then status PH_ERR_SUCCESS_CHAINING is returned.
* The caller should call this again with bOption = PH_EXCHANGE_RXCHAINING.
*
* CAUTION: This should not be called with AES or ISO authentication
* DOING SO WILL DAMAGE THE DESFIRE Card
* \n
* bOption can be one of \n
* \li #PH_EXCHANGE_DEFAULT \n
* \li #PH_EXCHANGE_RXCHAINING
*
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval #PH_ERR_SUCCESS_CHAINING More DF Names to be returned
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfdfEv2_GetDFNames(
                                  void * pDataParams,      /**< [In] Pointer to this layers param structure. */
                                  uint8_t bOption,         /**< [In] PH_EXCHANGE_DEFAULT or PH_EXCHANGE_RXCHAINING. */
                                  uint8_t * pDFBuffer,     /**< [Out] One DF Name at a time. Should be 21(3+2+16U) bytes long. */
                                  uint8_t * pDFInfoLen     /**< [Out] The size of the DF info returned in this frame. */
                                  );

/**
* \brief Parameters associated with the delegated application can be retrieved using this command
*
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfdfEv2_GetDelegatedInfo(
                                        void * pDataParams,     /**< [In] Pointer to this layers param structure. */
                                        uint8_t * pDAMSlot,     /**< [In] Pointer to DAM Slot number buffer. */
                                        uint8_t * pDamSlotVer,  /**< [Out] 1 byte DAM Slot version. */
                                        uint8_t * pQuotaLimit,  /**< [Out] 2 bytes Quota limit. */
                                        uint8_t * pFreeBlocks,  /**< [Out] 2 bytes Free Blocks. */
                                        uint8_t * pAid          /**< [Out] 3 bytes AID. */
                                        );

/**
* \brief Selects one particular application on the PICC for
* further access
*
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfdfEv2_SelectApplication(
    void * pDataParams,   /**< [In] Pointer to this layers param structure. */
    uint8_t bOption,      /**< [In] Option to indicate the presence of second Aid. */
    uint8_t * pAid,       /**< [In] 3 byte AID. LSB First. */
    uint8_t * pAid2       /**< [In] 3 byte Shared AID. LSB First. */
    );

/**
* \brief Releases the PICC user memory
*
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfdfEv2_Format(
                              void * pDataParams   /**< [In] Pointer to this layers param structure. */
                              );

/**
* \brief Returns manufacturing related data of the PICC
*
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfdfEv2_GetVersion(
                                  void * pDataParams,  /**< [In] Pointer to this layers param structure. */
                                  uint8_t * pVerInfo   /**< [Out] 28bytes of version info. User has to parse this. */
                                  );

/**
* \brief Returns free memory available on the PICC
*
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfdfEv2_FreeMem(
                               void * pDataParams,  /**< [In] Pointer to this layers param structure. */
                               uint8_t * pMemInfo   /**< [Out] 3 bytes memory info. LSB first. */
                               );

/**
* \brief Configures the card and pre personalizes the card with a key, defines
* if the UID or the random ID is sent back during communication setup and
* configures the ATS string.
*
* \remarks
* bOption can be one of \n
* \li #PHAL_MFDFEV2_SET_CONFIG_OPTION1 \n
* \li #PHAL_MFDFEV2_SET_CONFIG_OPTION2 \n
* \li #PHAL_MFDFEV2_SET_CONFIG_OPTION3 \n
* \li #PHAL_MFDFEV2_SET_CONFIG_OPTION4 \n
* \li #PHAL_MFDFEV2_SET_CONFIG_OPTION5 \n
* \li #PHAL_MFDFEV2_SET_CONFIG_OPTION6 \n
*
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/

phStatus_t phalMfdfEv2_SetConfiguration(
                                        void * pDataParams,    /**< [In] Pointer to this layers param structure. */
                                        uint8_t bOption,       /**< [In] Option parameter. 00..04 */
                                        uint8_t * pData,       /**< [In] Data for the option specified.*/
                                        uint8_t bDataLen       /**< [In] length for the data provided above. */
                                        );

/**
* \brief Returns the Unique ID of the PICC
*
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfdfEv2_GetCardUID(
                                  void * pDataParams,  /**< [In] Pointer to this layers param structure. */
                                  uint8_t * pUid       /**< [Out] UID of the card. Buffer size should be 7 bytes. */
                                  );

/** @} */

/**
* \name Application level Commands
*/
/** @{ */

/**
* \brief Returns the file IDs of all active files within the
* currently selected application
*
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfdfEv2_GetFileIDs(
                                  void * pDataParams,  /**< [In] Pointer to this layers param structure. */
                                  uint8_t * pFid,      /**< [Out] Max size = 32 bytes. */
                                  uint8_t * bNumFID    /**< [Out] Number of FIDs read. */
                                  );

/**
* \brief Get the ISO File IDs.
*
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfdfEv2_GetISOFileIDs(
                                     void * pDataParams,   /**< [In] Pointer to this layers param structure. */
                                     uint8_t * pFidBuffer, /**< [Out] Max size = 64 bytes. */
                                     uint8_t * pNumFID     /**< [Out] Number of FIDs read. */
                                     );

/**
* \brief Get informtion on the properties of a specific file
*
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfdfEv2_GetFileSettings(
                                       void * pDataParams,     /**< [In] Pointer to this layers param structure. */
                                       uint8_t bFileNo,        /**< [In] file number. Bit 8 will indicate SAI. */
                                       uint8_t * pFSBuffer,    /**< [Out] size should be max info returned. */
                                       uint8_t * bBufferLen    /**< [Out] size of data put in pFSBuffer. */
                                       );


/**
* \brief Changes the access parameters of an existing file
* \remarks
* bOption can be one of \n
* \li #PHAL_MFDFEV2_COMMUNICATION_ENC OR \n
* \li #PHAL_MFDFEV2_COMMUNICATION_PLAIN
*
* bCommSett can be one of \n
* \li #PHAL_MFDFEV2_COMMUNICATION_ENC OR \n
* \li #PHAL_MFDFEV2_COMMUNICATION_PLAIN or \n
* \li #PHAL_MFDFEV2_COMMUNICATION_MACD
*
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfdfEv2_ChangeFileSettings(
                                          void * pDataParams,       /**< [In] Pointer to this layers param structure. */
                                          uint8_t bOption,          /**< [In] Indicates whether the settings to be sent enciphered or plain or MACd. */
                                          uint8_t bFileNo,          /**< [In] file number. Bit 7 indicates SAI. */
                                          uint8_t bCommSett,        /**< [In] new communication settings for the file. */
                                          uint8_t * pAccessRights,  /**< [In] 2 byte access rights. */
                                          uint8_t bNumAddARs,       /**< [In] number of additional ac rights. */
                                          uint8_t * pAddARs         /**< [In] Additional access rights. Should be 2*bNumAddARs. */
                                          );

/**
* \brief Creates files for storage of plain unformatted user data within
* an existing application on the PICC
*
* \remarks
* If bOption==1U, it means pIsoFileId is present and is valid.
* If bOption=0, it means pIsoFileId is not present. \n
*
* Communication option (bCommSett) Possible Values are:\n
* \li #PHAL_MFDFEV2_COMMUNICATION_PLAIN
* \li #PHAL_MFDFEV2_COMMUNICATION_ENC
* \li #PHAL_MFDFEV2_COMMUNICATION_MACD
*
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfdfEv2_CreateStdDataFile(
                                         void * pDataParams,       /**< [In] Pointer to this layers param structure. */
                                         uint8_t bOption,          /**< [In] option parameter. 0x00 means wISOFileId is not provided. 0x01 means wISOFileId is provided and is valid. */
                                         uint8_t bFileNo,          /**< [In] file number. Bit 7 indicates SAI. */
                                         uint8_t * pISOFileId,     /**< [In] ISO File ID. */
                                         uint8_t bFileOption,      /**< [In] communication settings + Additional AR indicator. */
                                         uint8_t * pAccessRights,  /**< [In] 2 byte access rights. Sent LSB first to PICC. */
                                         uint8_t * pFileSize       /**< [In] 3bytes. Sent LSB first to PICC. */
                                         );

/**
* \brief Creates files for storage of plain unformatted user data within
* an existing application on the PICC
*
* \remarks
* If bOption==1U, it means pIsoFileId is present and is valid.
* If bOption=0, it means pIsoFileId is not present. \n
*
* Communication option (bCommSett) Possible Values are:\n
* \li #PHAL_MFDFEV2_COMMUNICATION_PLAIN
* \li #PHAL_MFDFEV2_COMMUNICATION_ENC
* \li #PHAL_MFDFEV2_COMMUNICATION_MACD
*
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfdfEv2_CreateBackupDataFile(
                                            void * pDataParams,    /**< [In] Pointer to this layers param structure. */
                                            uint8_t bOption,       /**< [In] option parameter. 0x00 means wISOFileId is not provided. 0x01 means wISOFileId is provided and is valid */
                                            uint8_t bFileNo,       /**< [In] file number. Bit 7 indicates SAI. */
                                            uint8_t *pISOFileId,   /**< [In] ISO File ID. */
                                            uint8_t bFileOption,   /**< [In] communication settings + AAR indicator. */
                                            uint8_t *pAccessRights,/**< [In] 2 byte access rights. Sent LSB first to PICC. */
                                            uint8_t * pFileSize    /**< [In] 3bytes. Sent LSB first to PICC. */
                                           );

/**
* \brief Creates backup data file for the storage of plain unformatted user data within
* an existing application, additionally supporting the feature of an integrated
* backup mechanism.
*
* \remarks
* If bOption==1U, it means pIsoFileId is present and is valid.
* If bOption=0, it means pIsoFileId is not present. \n
* bFileOption needs to be ORed with PHAL_MFDF_AAR_PRESENT to indicate additional access rights for this file.
*
* Communication option (bCommSett) Possible Values are:\n
* \li #PHAL_MFDFEV2_COMMUNICATION_PLAIN
* \li #PHAL_MFDFEV2_COMMUNICATION_ENC
* \li #PHAL_MFDFEV2_COMMUNICATION_MACD
*
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfdfEv2_CreateBkupDataFile(
                                          void * pDataParams,       /**< [In] Pointer to this layers param structure. */
                                          uint8_t bOption,          /**< [In] option parameter. 0x00 means wISOFileId is not provided. 0x01 means wISOFileId is provided and is valid */
                                          uint8_t bFileNo,          /**< [In] file number. Bit 7 indicates SAI. */
                                          uint8_t * pISOFileId,     /**< [In] ISO File ID. */
                                          uint8_t bFileOption,      /**< [In] communication settings + AAR indicator. */
                                          uint8_t * pAccessRights,  /**< [In] 2 byte access rights. Sent LSB first to PICC. */
                                          uint8_t * pFileSize       /**< [In] 3bytes. Sent LSB first to PICC. */
                                          );


/**
* \brief CreateValueFile
*
* Creates files for the storage and manipulation of 32bit
* signed integer values within an existing application on the PICC.
* User provides the entire information in the valInfo buffer.
*
* Communication option (bCommSett) Possible Values are:\n
* \li #PHAL_MFDFEV2_COMMUNICATION_PLAIN
* \li #PHAL_MFDFEV2_COMMUNICATION_ENC
* \li #PHAL_MFDFEV2_COMMUNICATION_MACD
*
* bLimitedCredit values are one or combination of the following: \n
* \li #PHAL_MFDFEV2_ENABLE_LIMITEDCREDIT
* \li #PHAL_MFDFEV2_ENABLE_FREE_GETVALUE
* OR can be set to zero if none of above are desired.
*
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfdfEv2_CreateValueFile(
                                       void * pDataParams,         /**< [In] Pointer to this layers param structure. */
                                       uint8_t bFileNo,            /**< [In] file number + SAI indicator. */
                                       uint8_t bCommSett,          /**< [In] communication settings+ AAR indicator. */
                                       uint8_t * pAccessRights,    /**< [In] 2 byte access rights. Sent LSB first to PICC. */
                                       uint8_t * pLowerLmit,       /**< [In] 4 byte Lower limit value. Sent LSB first to PICC. */
                                       uint8_t * pUpperLmit,       /**< [In] 4 byte Upper limit value. Sent LSB first to PICC. */
                                       uint8_t * pValue,           /**< [In] 4 byte Value. Sent LSB first to PICC. */
                                       uint8_t bLimitedCredit      /**< [In] Limited Credit and free getvalue setting. */
                                       );

/**
* \brief Creates files for multiple storage of structural similar
* data, for example for layalty programs within an existing application.
* Once the file is filled, further writing is not possible unless it is
* cleared.
*
* \remarks
* If bOption==1U, it means pIsoFileId is present and is valid.
* If bOption==0U, it means pIsoFileId is not present. \n
*
* Communication option (bCommSett) Possible Values are:\n
* \li #PHAL_MFDFEV2_COMMUNICATION_PLAIN
* \li #PHAL_MFDFEV2_COMMUNICATION_ENC
* \li #PHAL_MFDFEV2_COMMUNICATION_MACD
*
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfdfEv2_CreateLinearRecordFile(
                                              void * pDataParams,       /**< [In] Pointer to this layers param structure */
                                              uint8_t bOption,          /**< [In] Indicates ISO file ID is present or not. */
                                              uint8_t  bFileNo,         /**< [In] Linear record file Number + SAI. */
                                              uint8_t  *pIsoFileId,     /**< [In] 2 Byte IsoFileId. Sent LSB first to PICC. */
                                              uint8_t bCommSett,        /**< [In] communication settings + AAR indicator. */
                                              uint8_t * pAccessRights,  /**< [In] 2 byte access rights. Sent LSB first to PICC. */
                                              uint8_t * pRecordSize,    /**< [In] 3 byte Record Size. Sent LSB first to PICC. */
                                              uint8_t * pMaxNoOfRec     /**< [In] 3 byte Max Number of Records. Sent LSB first to PICC. */
                                              );

/**
* \brief Creates files for multiple storage of structural similar
* data, for example for logging transactions, within an existing application.
* Once the file is filled, the PICC automatically overwrites the oldest record
* with the latest written one.
*
* \remarks
* If bOption==1U, it means pIsoFileId is present and is valid.
* If bOption==0U, it means pIsoFileId is not present. \n
*
* Communication option (bCommSett) Possible Values are:\n
* \li #PHAL_MFDFEV2_COMMUNICATION_PLAIN
* \li #PHAL_MFDFEV2_COMMUNICATION_ENC
* \li #PHAL_MFDFEV2_COMMUNICATION_MACD
*
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfdfEv2_CreateCyclicRecordFile(
                                              void * pDataParams,       /**< [In] Pointer to this layers param structure */
                                              uint8_t bOption,          /**< [In] Indicates ISO file ID is present or not. */
                                              uint8_t  bFileNo,         /**< [In] Linear record file Number + SAI indicator. */
                                              uint8_t  *pIsoFileId,     /**< [In] 2 Byte IsoFileId. Sent LSB first to PICC. */
                                              uint8_t bCommSett,        /**< [In] communication settings + AAR indicator */
                                              uint8_t * pAccessRights,  /**< [In] 2 byte access rights. Sent LSB first to PICC. */
                                              uint8_t * pRecordSize,    /**< [In] 3 byte Record Size. Sent LSB first to PICC. */
                                              uint8_t * pMaxNoOfRec     /**< [In] 3 byte Max Number of Records. Sent LSB first to PICC. */
                                              );

/**
* \brief Creates a Transaction MAC file
* An application can have only one Transaction MAC File
*
* Communication option (bCommSett) Possible Values are:\n
* \li #PHAL_MFDFEV2_COMMUNICATION_PLAIN
* \li #PHAL_MFDFEV2_COMMUNICATION_ENC
* \li #PHAL_MFDFEV2_COMMUNICATION_MACD
*
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfdfEv2_CreateTransactionMacFile(
    void * pDataParams,         /**< [In] Pointer to this layers param structure */
    uint16_t wOption,           /**< [In] Options for Diversification for Sam Non X mode operations.
                                 *        The option can be one of the following.
                                 *          \c (0x00)   PHALMFDFEV2_SAM_NONX_KEY_DIVERSIFICATION_OFF;
                                 *          \c (0x01)   PHALMFDFEV2_SAM_NONX_KEY_DIVERSIFICATION_ON;
                                 */
    uint8_t bFileNo,            /**< [In] file Number + SAI. */
    uint8_t bCommSett,          /**< [In] communication settings. */
    uint8_t * pAccessRights,    /**< [In] 2 byte access rights. Sent LSB first to PICC. */
    uint16_t wKeyNo,            /**< [In] key number in keystore. */
    uint8_t bKeyType,           /**< [In] 1byte. Bit0, 1 indicate key type.. and it should be always PHAL_MFDFEV2_KEY_TYPE_AES128 */
    uint8_t * bTMKey,           /**< [In] Key value. 16 bytes. */
    uint8_t bTMKeyVer,          /**< [In] TM Key version. Value should be valid for AES key. Ignored for other key types. */
    uint8_t * pDivInput,        /**< [In] Diversification input. Can be NULL. */
    uint8_t bDivInputLength     /**< [In] Diversification input Length. */
    );

/**
* \brief Permanently deactivates a file within the file directory of the
* currently selected application.
*
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfdfEv2_DeleteFile(
                                  void * pDataParams,  /**< [In] Pointer to this layers param structure. */
                                  uint8_t bFileNo      /**< [In] File number. Bit 7 indicates SAI. */
                                  );

/** @} */

/**
* \name Data Manipulation Commands
*/
/** @{ */

/**
* \brief Reads data from standard data files or backup data files
*
* \remarks
*
* Chaining upto the size of the HAL Rx buffer is handled within this function.
* If more data is to be read, the user has to call this function again with
* bOption = PH_EXCHANGE_RXCHAINING | [one of the communication options below]
*
* \c Communication option (bOption) can be one of:\n
* \li #PHAL_MFDFEV2_COMMUNICATION_PLAIN
* \li #PHAL_MFDFEV2_COMMUNICATION_ENC
* \li #PHAL_MFDFEV2_COMMUNICATION_MACD
* \li #PH_EXCHANGE_RXCHAINING | #PHAL_MFDFEV2_COMMUNICATION_ENC
* (or OR'd with other two options when re-calling the API if PHAL_MFDFEV2_INFO_MOREDATA is
* received)
*
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval #PH_ERR_SUCCESS_CHAINING indicating more data to be read.
* \retval Depending on implementation and underlying component.
*/
phStatus_t phalMfdfEv2_ReadData(
                                void * pDataParams,     /**< [In] Pointer to this layers param structure. */
                                uint8_t bOption,        /**< [In] Is either plain or encrypted or MAC'd. */
                                uint8_t bIns,           /**< [In] If set, uses ISO 14443-4 chaining instead of DESFire application chaining. */
                                uint8_t bFileNo,        /**< [In] 1 byte file number. 7th bit indicates SAI. */
                                uint8_t * pOffset,      /**< [In] 3 bytes offset. LSB First. */
                                uint8_t * pLength,      /**< [In] 3 bytes. length of data to be read. If 00, entire file will be read. */
                                uint8_t ** ppRxdata,    /**< [Out] Pointer to HAL Rx buffer returned back to user. */
                                uint16_t * pRxdataLen   /**< [Out] Pointer to Length of RxData. */
                                );

/**
* \brief Writes data to standard data files or backup data files
*
* \remarks
* Implements chaining to the card.
*
* \c Communication option (bCommOption) can be one of:\n
* \li #PHAL_MFDFEV2_COMMUNICATION_PLAIN
* \li #PHAL_MFDFEV2_COMMUNICATION_ENC
* \li #PHAL_MFDFEV2_COMMUNICATION_MACD
*
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/

phStatus_t phalMfdfEv2_WriteData(
                                 void * pDataParams,    /**< [In] Pointer to this layers param structure. */
                                 uint8_t bOption,       /**< [In] Communication Mode. Plain, Mac'd or encrypted. */
                                 uint8_t bIns,          /**< [In] If set, uses ISO 14443-4 chaining instead of DESFire application chaining. */
                                 uint8_t bFileNo,       /**< [In] 1 byte file number + SAI. */
                                 uint8_t * pOffset,     /**< [In] 3 bytes offset. LSB First. */
                                 uint8_t * pTxData,     /**< [in] Data to be written. */
                                 uint8_t * pTxDataLen   /**< [in] 3 bytes. length of data to be written. */
                                 );

/**
* \brief Reads the currently stored value from value files.
*
* Communication option  Possible Values are:\n
* \li #PHAL_MFDFEV2_COMMUNICATION_PLAIN
* \li #PHAL_MFDFEV2_COMMUNICATION_ENC
* \li #PHAL_MFDFEV2_COMMUNICATION_MACD
*
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfdfEv2_GetValue(
                                void * pDataParams,     /**< [In] Pointer to this layers param structure. */
                                uint8_t bOption,        /**< [In] Communication option. */
                                uint8_t bFileNo,        /**< [In] 1 byte file number + SAI. */
                                uint8_t * pValue        /**< [Out] 4 Byte array to store the value read out. LSB First. */
                                );

/**
* \brief Increases a value stored in a Value File
*
* Communication option  Possible Values are:\n
* \li #PHAL_MFDFEV2_COMMUNICATION_PLAIN
* \li #PHAL_MFDFEV2_COMMUNICATION_ENC
* \li #PHAL_MFDFEV2_COMMUNICATION_MACD
*
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfdfEv2_Credit(
                              void * pDataParams,   /**< [In] Pointer to this layers param structure. */
                              uint8_t bOption,      /**< [In] Communication option */
                              uint8_t bFileNo,      /**< [In] 1 byte file number and SAI. */
                              uint8_t * pValue      /**< [In] 4 byte value array. LSB first. */
                              );

/**
* \brief Decreases a value stored in a Value File
*
* Communication option  Possible Values are:\n
* \li #PHAL_MFDFEV2_COMMUNICATION_PLAIN
* \li #PHAL_MFDFEV2_COMMUNICATION_ENC
* \li #PHAL_MFDFEV2_COMMUNICATION_MACD
*
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfdfEv2_Debit(
                             void * pDataParams,  /**< [In] Pointer to this layers param structure. */
                             uint8_t bCommOption, /**< [In] Communication option. */
                             uint8_t bFileNo,     /**< [In] 1 byte file number and SAI. */
                             uint8_t * pValue     /**< [In] 4 byte value array. LSB first. */
                             );

/**
* \brief Allows a limited increase of a value stored in a Value File
* without having full credit permissions to the file.
*
* Communication option  Possible Values are:\n
* \li #PHAL_MFDFEV2_COMMUNICATION_PLAIN
* \li #PHAL_MFDFEV2_COMMUNICATION_ENC
* \li #PHAL_MFDFEV2_COMMUNICATION_MACD
*
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfdfEv2_LimitedCredit(
                                     void * pDataParams,  /**< [In] Pointer to this layers param structure. */
                                     uint8_t bCommOption, /**< [In] Communication option. */
                                     uint8_t bFileNo,     /**< [In] 1 byte file number and SAI. */
                                     uint8_t * pValue     /**< [In] 4 byte value array. LSB first. */
                                     );

/**
* \brief Writes data to a record in a Cyclic or Linear Record File.
*
* \remarks
* Implements chaining to the card.
* The data provided on pData will be chained to the card
* by sending data upto the frame size of the DESFire PICC, at a time.
*
* Communication option  Possible Values are:\n
* \li #PHAL_MFDFEV2_COMMUNICATION_PLAIN
* \li #PHAL_MFDFEV2_COMMUNICATION_ENC
* \li #PHAL_MFDFEV2_COMMUNICATION_MACD
*
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfdfEv2_WriteRecord(
                                   void * pDataParams,    /**< [In] Pointer to this layers param structure. */
                                   uint8_t bCommOption,   /**< [In] Communication option. Plain, Mac'd or enc. */
                                   uint8_t bIns,          /**< [In] If set, uses ISO 14443-4 chaining instead of DESFire application chaining. */
                                   uint8_t bFileNo,       /**< [In] 1 byte file number and SAI.. */
                                   uint8_t * pOffset,     /**< [In] 3 bytes offset. LSB First. */
                                   uint8_t * pData,       /**< [In] data to be written. */
                                   uint8_t * pDataLen     /**< [In] 3 bytes. length of data to be written. */
                                   );

/**
* \brief Reads out a set of complete records from a Cyclic or Linear Record File.
*
* \remarks
* The readrecords command reads and stores data in the rxbuffer upto the rxbuffer size before returning
* to the user. The rxbuffer is configured during the HAL init and this is specified by the user.
*
* Chaining upto the size of the HAL Rx buffer is handled within this function.
* If more data is to be read, the user has to call this function again with
* bCommOption = PH_EXCHANGE_RXCHAINING | [one of the communication options below]
*
* \c Communication option (bCommOption) can be one of:\n
* \li #PHAL_MFDFEV2_COMMUNICATION_PLAIN
* \li #PHAL_MFDFEV2_COMMUNICATION_ENC
* \li #PHAL_MFDFEV2_COMMUNICATION_MACD
* \li #PH_EXCHANGE_RXCHAINING | #PHAL_MFDFEV2_COMMUNICATION_ENC
* (or OR'd with other two options when re-calling the API if PH_ERR_SUCCESS_CHAINING is
* received)
*
* If TMI collection is ON, if pRecCount is zero then pRecSize is madatory parameter.
* If pRecSize and RecCount are zero and TMI collection is ON, then  PH_ERR_INVALID_PARAMETER error returned.
* If TMI collection is ON; and if wrong pRecSize is provided, then wrong RecCount value will be calculated and updated for TMI collection.
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval #PH_ERR_SUCCESS_CHAINING indicating more data to be read.
* \retval Depending on implementation and underlying component.
*/
phStatus_t phalMfdfEv2_ReadRecords(
                                   void * pDataParams,      /**< [In] Pointer to this layers param structure. */
                                   uint8_t bCommOption,     /**< [In] communcation option. */
                                   uint8_t bIns,            /**< [In] If set, uses ISO 14443-4 chaining instead of DESFire application chaining. */
                                   uint8_t bFileNo,         /**< [In] 1 byte file number and SAI. */
                                   uint8_t * pRecNo,        /**< [In] 3 bytes LSB first. Record number of the newest record targeted, starting to count from the latest record written. */
                                   uint8_t * pRecCount,     /**< [In] 3 bytes LSB first. Number of records to be read. If 0x00 00 00, then all the records are read. */
                                   uint8_t * pRecSize,      /**< [In] Record size. 3Bytes LSB first. */
                                   uint8_t ** ppRxdata,     /**< [Out] pointer to the HAL buffer that stores the read data. */
                                   uint16_t * pRxdataLen    /**< [Out] number of bytes read (= number of records read * size of record). */
                                   );

/**
* \brief Updates data to a record in a Cyclic or Linear Record File.
*
* \remarks
* Implements chaining to the card.
* The data provided on pData will be chained to the card
* by sending data upto the frame size of the DESFire PICC, at a time.
*
* Communication option  Possible Values are:\n
* \li #PHAL_MFDFEV2_COMMUNICATION_PLAIN
* \li #PHAL_MFDFEV2_COMMUNICATION_ENC
* \li #PHAL_MFDFEV2_COMMUNICATION_MACD
*
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfdfEv2_UpdateRecord(
                                    void * pDataParams,     /**< [In] Pointer to this layers param structure. */
                                    uint8_t bCommOption,    /**< [In] Communication option. Plain, Mac'd or enc. */
                                    uint8_t bIns,           /**< [In] If set, uses ISO 14443-4 chaining instead of DESFire application chaining. */
                                    uint8_t bFileNo,        /**< [In] 1 byte file number and SAI. */
                                    uint8_t * pRecNo,       /**< [In] 3 byte record number. */
                                    uint8_t * pOffset,      /**< [In] 3 bytes offset. LSB First. */
                                    uint8_t * pData,        /**< [In] data to be written. */
                                    uint8_t * pDataLen      /**< [In] 3 bytes. length of data to be written. */
                                    );

/**
* \brief Resets a Cyclic or Linear Record File.
*
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfdfEv2_ClearRecordFile(
                                       void * pDataParams, /**< [In] Pointer to this layers param structure. */
                                       uint8_t bFileNo     /**< [In] File number. Bit 7 indicates SAI. */
                                       );

/**
* \brief Secures the transaction by commiting the application to ReaderID specified
*
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfdfEv2_CommitReaderID(
                                      void * pDataParams,   /**< [In] Pointer to this layers param structure. */
                                      uint8_t * pTMRI,      /**< [In] 16 bytes. TM Reader ID */
                                      uint8_t * pEncTMRI    /**< [Out] Encrypted TM Reader ID of the previous transaction. */
                                      );

/**
* \brief Validates all previous write access' on Backup Data files, value
* files and record files within one application.
*
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfdfEv2_CommitTransaction(
                                         void * pDataParams,    /**< [In] Pointer to this layers param structure. */
                                         uint8_t bOption,       /**< [In] Lower nibble : Return Calculated TMAC or not.*/
                                         uint8_t * pTMC,        /**< [Out] 4 byte TMAC counter. */
                                         uint8_t * pTMV         /**< [Out] 8 byte TMAC value. */
                                         );

/**
* \brief Invalidates all previous write access' on Backup Data files, value
* files and record files within one application.
*
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfdfEv2_AbortTransaction(
                                        void * pDataParams /**< [In] Pointer to this layers param structure. */
                                        );

/** @} */

/**
* \name ISO 7816 COMMANDS
*/
/** @{ */

/**
* \brief ISO Select
*
* \remarks
* bSelector = 0x00 => Selection by 2 byte file Id. \n
* bSelector = 0x02 => Select EF under current DF. Fid = EF id \n
* bSelector = 0x04 => Selection by DF Name. DFName and len is then valid \n
*
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/

phStatus_t phalMfdfEv2_IsoSelectFile(
                                     void * pDataParams,        /**< [In] Pointer to this layers param structure. */
                                     uint8_t bOption,           /**< [In] If bOption == 00 FCI is returned. If 0x0C no FCI returned. */
                                     uint8_t bSelector,         /**< [In] bSelector equals either 0x00 or 0x02 or 0x04. */
                                     uint8_t * pFid,            /**< [In] two byte file id. Send LSB first. */
                                     uint8_t * pDFname,         /**< [In] DFName upto 16 bytes. valid only when bOption = 0x04. */
                                     uint8_t bDFnameLen,        /**< [In] Length of DFName string provided by the user. */
                                     uint8_t bExtendedLenApdu,  /**< [In] Flag for Extended Length APDU. 0x01 for Extended Length APDUs. 0x00 or any other value for Short APDUs. */
                                     uint8_t ** ppFCI,          /**< [Out] File control information. */
                                     uint16_t * pwFCILen        /**< [Out] Length of FCI returned. */
                                     );

/**
* \brief ISO Read Binary
* \c wOption can be one of:\n
* \li #PH_EXCHANGE_DEFAULT
* \li #PH_EXCHANGE_RXCHAINING
*
* If status of #PH_ERR_SUCCESS_CHAINING is returned
* Recall this function with wOption PH_EXCHANGE_RXCHAINING to
* get remaining data.
*
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval #PH_ERR_SUCCESS_CHAINING operation success with chaining.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfdfEv2_IsoReadBinary(
                                     void * pDataParams,        /**< [In] Pointer to this layers param structure. */
                                     uint16_t wOption,          /**< [In] #PH_EXCHANGE_DEFAULT or #PH_EXCHANGE_RXCHAINING. */
                                     uint8_t bOffset,           /**< [In] Offset from where to read. */
                                     uint8_t bSfid,             /**< [In] Short ISO File Id. Bit 7 should be 1 to indicate Sfid is supplied.Else it is treated as MSB of 2Byte offset. */
                                     uint32_t dwBytesToRead,    /**< [In] number of bytes to read. If 0, then entire file to be read. */
                                     uint8_t bExtendedLenApdu,  /**< [In] Flag for Extended Length APDU. 0x01 for Extended Length APDUs. 0x00 or any other value for Short APDUs. */
                                     uint8_t ** ppRxBuffer,     /**< [Out] buffer where the read bytes will be stored. */
                                     uint32_t * pBytesRead      /**< [Out] number of bytes read. */
                                     );

/**
* \brief Iso Update Binary
*
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfdfEv2_IsoUpdateBinary(
                                       void * pDataParams,      /**< [In] Pointer to this layers param structure. */
                                       uint8_t bOffset,         /**< [In] Offset from where to write. */
                                       uint8_t bSfid,           /**< [In] Short ISO File Id.Bit 7 should be 1 to indicate Sfid is supplied Else it is treated as MSB of 2Byte offset. */
                                       uint8_t bExtendedLenApdu,/**< [In] Flag for Extended Length APDU. 0x01 for Extended Length APDUs. 0x00 or any other value for Short APDUs. */
                                       uint8_t * pData,         /**< [In] data to be written. */
                                       uint32_t dwDataLen       /**< [In] number of bytes to write. */
                                       );

/**
* \brief Iso Read Records
*
* \c wOption can be one of:\n
* \li #PH_EXCHANGE_DEFAULT
* \li #PH_EXCHANGE_RXCHAINING
*
* If status of #PH_ERR_SUCCESS_CHAINING is returned
* Recall this function with wOption PH_EXCHANGE_RXCHAINING to
* get remaining data.
*
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfdfEv2_IsoReadRecords(
                                      void * pDataParams,       /**< [In] Pointer to this layers param structure. */
                                      uint16_t wOption,         /**< [In] #PH_EXCHANGE_DEFAULT or #PH_EXCHANGE_RXCHAINING. */
                                      uint8_t bRecNo,           /**< [In] Record to read / from where to read. */
                                      uint8_t bReadAllFromP1,   /**< [In] Whether to read all records from bRecNo or just one. */
                                      uint8_t bSfid,            /**< [In] Short ISO File Id bits 0..4 only code this value. */
                                      uint32_t dwBytesToRead,   /**< [In] number of bytes to read. Multiple of record size. */
                                      uint8_t bExtendedLenApdu, /**< [In] Flag for Extended Length APDU. 0x01 for Extended Length APDUs. 0x00 or any other value for Short APDUs. */
                                      uint8_t ** ppRxBuffer,    /**< [Out] buffer where the read bytes will be stored. */
                                      uint32_t * pBytesRead     /**< [Out] number of bytes read. */
                                      );

/**
* \brief Iso Append record
*
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfdfEv2_IsoAppendRecord(
                                       void * pDataParams,      /**< [In] Pointer to this layers param structure. */
                                       uint8_t bSfid,           /**< [In] Short Iso File Id bits 0..4 only code this value. Either 0 or sfid. */
                                       uint8_t * pData,         /**< [In] data to write. */
                                       uint32_t dwDataLen,      /**< [In] number of bytes to write. */
                                       uint8_t bExtendedLenApdu /**< [In] Flag for Extended Length APDU. 0x01 for Extended Length APDUs. 0x00 or any other value for Short APDUs. */
                                       );

/**
* \brief Iso Update record
*
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfdfEv2_IsoUpdateRecord(
                                       void * pDataParams,     /**< [In] Pointer to this layers param structure. */
                                       uint8_t bIns,           /**< [In] Either 0xDC or 0xDD. */
                                       uint8_t bRecNo,         /**< [In] Record number. 00 indicates current record. */
                                       uint8_t bSfid,          /**< [In] Short Iso File Id bits 0..4 only code this value. Either 0 or sfid. */
                                       uint8_t bRefCtrl,       /**< [In] Bit 0 to bit 3 code the value based on bIns as defined in ISO 7816-4 Update Record. */
                                       uint8_t * pData,        /**< [In] data to write. */
                                       uint8_t bDataLen        /**< [In] number of bytes to write. */
                                       );

/**
* \brief GetChallenge
*
* \remarks
*
* THIS COMMAND IS NOT SUPPORTED IN SAM-X Configuration.
*
* Returns the random number from the PICC. Size depends on the key type
* referred by wKeyNo and wKeyVer
*
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfdfEv2_IsoGetChallenge(
                                       void * pDataParams,      /**< [In] Pointer to this layers param structure. */
                                       uint16_t wKeyNo,         /**< [In] Key number in key store. */
                                       uint16_t wKeyVer,        /**< [In] Key version in key store. */
                                       uint8_t bExtendedLenApdu,/**< [In] Flag for Extended Length APDU. 0x01 for Extended Length APDUs. 0x00 or any other value for Short APDUs. */
                                       uint32_t dwLe,           /**< [In] Length of expected challenge RPICC1. */
                                       uint8_t * pRPICC1        /**< [Out] RPICC1 returned from PICC. */
                                       );


/**
* \brief Iso External Authenticate
*
* \remarks
*
* THIS COMMAND IS NOT SUPPORTED IN SAM-X Configuration.
*
* pInput should have \n
* \li Reference to crypto algorigthm - 1 Byte 00 => context defined, 02=>2K3DES, 04=>3k3DES, 09=>AES128
* \li Card master key flag - 1 Byte:  0x00 if card master key, 0x01 otherwise.
* \li key number on card - 1 Byte: 0x0 to 0xD
* \li length of random number : 1 Byte
* \li Random number generated by PCD : 8 or 16 bytes. Not required for Sam non X mode.
* \li Random number returned by GetChallenge command : 8 Bytes or 16 Bytes
* \li key number : 2 bytes
* \li key version : 2 bytes
*
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfdfEv2_IsoExternalAuthenticate(
    void * pDataParams,       /**< [In] Pointer to this layers param structure. */
    uint8_t * pInput,         /**< [In] Input data. */
    uint8_t bInputLen,        /**< [In] Length of pInput. */
    uint8_t bExtendedLenApdu, /**< [In] Flag for Extended Length APDU. 0x01 for Extended Length APDUs. 0x00 or any other value for Short APDUs. */
    uint8_t * pDataOut,       /**< [Out] Returns Rnd number PCD2 in sam non x mode. Nothing in S/W mode. */
    uint8_t * pOutLen         /**< [Out] Length of data returned in pDataOut. */
    );

/**
* \brief Iso Internal Authenticate
*
* \remarks
*
* THIS COMMAND IS NOT SUPPORTED IN SAM-X Configuration.
*
* pInput should have \n
* \li Reference to crypto algorigthm - 1 Byte. 02 = 2kDES, 03 = 3k3des, 09=AES, 00 = context defined.
* \li Card master key flag - 1 Byte:  0x00 if card master key, 0x01 otherwise.
* \li key number on card - 1 Byte: 0x0 to 0xD
* \li length of random number : 1 Byte
* \li Random number Rpcd2 : 8 Bytes or 16 Bytes
* \li key number : 2 bytes
* \li key version : 2 bytes
*
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfdfEv2_IsoInternalAuthenticate(
    void * pDataParams,      /**< [In] Pointer to this layers param structure. */
    uint8_t * pInput,        /**< [In] Input data. */
    uint8_t bInputLen,       /**< [In] Length of pInput. */
    uint8_t bExtendedLenApdu,/**< [In] Flag for Extended Length APDU. 0x01 for Extended Length APDUs. 0x00 or any other value for Short APDUs. */
    uint8_t * pDataOut,      /**< [Out] RRPICC2||RPCD2 after decryption in S/W mode. Nothing in Sam non x mode. */
    uint8_t * pOutLen        /**< [Out] Length of data returned in pDataOut. */
    );

/**
* \brief Perform Iso authentication GetChallenge, External Authenticate &
* Internal Authenticate of a DESFire PICC
*
* Internally performs the three pass Iso authentication by calling
* GetChallenge \n
* External Authenticate \n
* Internal Authenticate \n
* Generates and stores the session key \n
*
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfdfEv2_IsoAuthenticate(
                                       void * pDataParams,     /**< [In] Pointer to this layers param structure. */
                                       uint16_t wKeyNo,        /**< [In] DESFire key number or SAM Key entry number. */
                                       uint16_t wKeyVer,       /**< [In] Key version. */
                                       uint8_t bKeyNoCard,     /**< [In] Key number on card. 0x0 to 0xD. */
                                       uint8_t bIsPICCkey      /**< [In] Is it PICC Master key? 1=YES. */
                                       );

/** @} */

/**
* \name Miscellaneous functions
*/
/** @{ */

/**
* \brief Perform a GetConfig command.
*
* \c wConfig can be one of:\n
* \li #PHAL_MFDFEV2_ADDITIONAL_INFO
* \li #PHAL_MFDFEV2_WRAPPED_MODE
*
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfdfEv2_GetConfig(
                                 void * pDataParams,  /**< [In] Pointer to this layers parameter structure. */
                                 uint16_t wConfig,    /**< [In] Item to read. */
                                 uint16_t * pValue    /**< [Out] Read value. */
                                 );

/**
* \brief Perform a SetConfig command.
*
* \c wConfig can be one of:\n
* \li #PHAL_MFDFEV2_ADDITIONAL_INFO
* \li #PHAL_MFDFEV2_WRAPPED_MODE
*
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfdfEv2_SetConfig(
                                 void * pDataParams,   /**< [In] Pointer to this layers parameter structure. */
                                 uint16_t wConfig,     /**< [In] Item to set. */
                                 uint16_t wValue       /**< [In] Value to set. */
                                 );

/**
* \brief Reset the authentication
*
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfdfEv2_ResetAuthentication(
                                           void * pDataParams   /**< [In] Pointer to this layers parameter structure. */
                                           );

/** @} */

/**
* \name Utility functions
*/
/** @{ */

/**
* \brief Generates Encrypted Key for Delegated application management
*
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfdfEv2_GenerateDAMEncKey(
    void * pDataParams,             /**< [In] Pointer to this layers parameter structure. */
    uint16_t wKeyNoDAMEnc,          /**< [In] Key number in key store of DAM Encryption key. */
    uint16_t wKeyVerDAMEnc,         /**< [In] Key version in key store of DAM Encryption key. */
    uint16_t wKeyNoAppDAMDefault,   /**< [In] Key number in key store of DAM default key. */
    uint16_t wKeyVerAppDAMDefault,  /**< [In] Key version in key store of DAM default key. */
    uint8_t bAppDAMDefaultKeyVer,   /**< [In] DAM Default Key version. Value should be valid for AES key. Ignored for other key types. */
    uint8_t * pDAMEncKey            /**< [Out] Encrypted DAM Default key data. */
    );

/**
* \brief Generate DAMMAC
*
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfdfEv2_GenerateDAMMAC(
                                      void * pDataParams,       /**< [In] Pointer to this layers parameter structure. */
                                      uint8_t bOption,          /**< [In] Option parameter. Indicates the presence of ISO File Id, ISO DFName */
                                      uint16_t wKeyNoDAMMAC,    /**< [In] Key number in key store of DAM MAC key. */
                                      uint16_t wKeyVerDAMMAC,   /**< [In] Key version in key store of DAM MAC key. */
                                      uint8_t * pAid,           /**< [In] array of 3 bytes. */
                                      uint8_t * pDamParams,     /**< [In] 5 byte array. Byte0,Byte1  = DAM Slot, Byte2 = DAMSlotVersion, Byte3, Byte 4 = QuotaLimit. Multiple of 32 byte block. */
                                      uint8_t bKeySettings1,    /**< [In] 1 byte. */
                                      uint8_t bKeySettings2,    /**< [In] 1 byte. bit 4 of this byte should be set to 1 if KeySetting3 is present. */
                                      uint8_t bKeySettings3,    /**< [In] 1 byte. bit 0 of this byte should be set to 1 if pKeySetValues is valid. */
                                      uint8_t * pKeySetValues,  /**< [In] 4 byte keyset values. Byte0 = AKS ver, byte1 = keysets, byte2 = MaxKeysize, byte3 = AppKeySetSettings */
                                      uint8_t * pISOFileId,     /**< [In] 2 bytes ISO File ID. */
                                      uint8_t * pISODFName,     /**< [In] 1 to 16 Bytes. Can also be NULL. */
                                      uint8_t bISODFNameLen,    /**< [In] Size of pISODFName if that is present. */
                                      uint8_t * pEncK,          /**< [In] Encrypted initial application key. 32 bytes long. */
                                      uint8_t * pDAMMAC         /**< [Out] 8 byte DAMMAC. */
                                      );

/**
* \brief Generates DAMMAC for Set Configuration with option 0x06 for Delegated Application
*
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfdfEv2_GenerateDAMMACSetConfig(
                    void  * pDataParams,        /**< [In] Pointer to parameters data structure */
                    uint16_t wKeyNoDAMMAC,      /**< [In] Key number in key store of DAM MAC Key */
                    uint16_t wKeyVerDAMMAC,     /**< [In] Key version in key store of DAM MAC Key*/
                    uint16_t wOldDFNameLen,     /**< [In] Length of existing DF Name */
                    uint8_t * pOldISODFName,    /**< [In] This means already created delegated app ISO DF Name. Maximum 16 bytes */
                    uint16_t wNewDFNameLen,     /**< [In] Length of new DF Name */
                    uint8_t * pNewISODFName,    /**< [In] This means new delegated app ISO DF Name which will replace the existing one. Maximum 16 bytes */
                    uint8_t * pDAMMAC           /**< [Out] generated 8 bytes DAM MAC for setconfig option 0x06 */
                    );

/**
* \brief Calculate TMV
*
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfdfEv2_CalculateTMV(
                                    void * pDataParams,         /**< [In] Pointer to this layers parameter structure. */
                                    uint16_t wOption,           /**< [In] Diversification option. */
                                    uint16_t wKeyNoTMACKey,     /**< [In] Key number in key store of DAM MAC key. */
                                    uint16_t wKeyVerTMACKey,    /**< [In] Key version in key store of DAM MAC key. */
                                    uint8_t * pDivInput,        /**< [In] Diversification input for TMACKey. */
                                    uint8_t bDivInputLen,       /**< [In] Length of diversification input. */
                                    uint8_t * pTMC,              /**< [In] 4 bytes Transaction MAC Counter. -LSB first */
                                    uint8_t * pUid,             /**< [In] 7 byte UID of the card. */
                                    uint8_t bUidLen,            /**< [In] Length of UID supplied. */
                                    uint8_t * pTMI,             /**< [In] Transaction MAC Input. */
                                    uint32_t dwTMILen,            /**< [In] Length of TMI. */
                                    uint8_t * pTMV              /**< [Out] Transaction MAC Value. */
                                    );

/**
* \brief Decrypt Reader ID
*
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfdfEv2_DecryptReaderID(
                                       void * pDataParams,      /**< [In] Pointer to this layers parameter structure. */
                                       uint16_t wOption,        /**< [In] Diversification option. */
                                       uint16_t wKeyNoTMACKey,  /**< [In] Key number in key store of DAM MAC key. */
                                       uint16_t wKeyVerTMACKey, /**< [In] Key version in key store of DAM MAC key. */
                                       uint8_t * pDivInput,     /**< [In] Diversification input for TMACKey. */
                                       uint8_t bDivInputLen,    /**< [In] Length of diversification input. */
                                       uint8_t *pTMC,           /**< [In] 4 bytes Transaction MAC Counter. */
                                       uint8_t * pUid,          /**< [In] 7 (or 10) byte UID of the card. */
                                       uint8_t bUidLen,         /**< [In] Length of UID supplied. */
                                       uint8_t * pEncTMRI,      /**< [In] Encrypted TMAC Reader Id (16 bytes). */
                                       uint8_t * pTMRIPrev      /**< [Out] Reader ID of the last successful transaction. */
                                       );

/**
* \brief Performs the originality check to verify the genuineness of MF3Dx2 chip
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfdfEv2_ReadSign(
                                 void * pDataParams,    /**< [In] Pointer to this layer's parameter structure. */
                                 uint8_t bAddr,         /**< [In] Value is always 00. Present for forward compatibility reasons */
                                 uint8_t ** pSignature  /**< [Out] Pointer to a 56 byte signature read from the card */
                               );
/**
* \brief This is a utility API which sets the VCA structure in Desfire Ev2 structure params
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfdfEv2_SetVCAParams(
                            void * pDataParams,
                            void * pAlVCADataParams
                            );
/** @} */

/** @} */
#endif /* NXPBUILD__PHAL_MFDFEV2 */

#ifdef __cplusplus
} /* Extern C */
#endif

#endif /* PHALMFDFEV2_H */
