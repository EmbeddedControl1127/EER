/*
*         Copyright (c), NXP Semiconductors Gratkorn / Austria
*
*                     (C)NXP Semiconductors
*       All rights are reserved. Reproduction in whole or in part is
*      prohibited without the written consent of the copyright owner.
*  NXP reserves the right to make changes without notice at any time.
* NXP makes no warranty, expressed, implied or statutory, including but
* not limited to any implied warranty of merchantability or fitness for any
*particular purpose, or that the use will not infringe any third party patent,
* copyright or trademark. NXP must not be liable for any loss or damage
*                          arising from its use.
*/

/** \file
* Generic MIFARE(R) PLUS EV1 Application Component of Reader Library Framework.
* $Author: nxa34640 $
* $Revision: 2085 $ (v05.07.00)
* $Date: 2016-08-24 12:12:20 +0530 (Wed, 24 Aug 2016) $
*
* History:
*  Kumar GVS: Generated 15. Apr 2013
*
*/

#ifndef PHALMFPEV1_H
#define PHALMFPEV1_H

#include <ph_Status.h>
#include <phhalHw.h>
#include <phpalMifare.h>

#ifdef __cplusplus
extern "C" {
#endif  /* __cplusplus */

#ifdef NXPBUILD__PHAL_MFPEV1

/** \defgroup phalMfpEv1 MIFARE Plus (R) EV1
* \brief These Components implement the MIFARE Plus (R) commands.
* @{
*/

/**
* \name Authentication Parameters
*/
/*@{*/
#define PHAL_MFPEV1_KEYA           0x0AU   /**< MIFARE(R) Key A. */
#define PHAL_MFPEV1_KEYB           0x0BU   /**< MIFARE(R) Key B. */
/*@}*/

/** \name Custom Error Codes
*/
/*@{*/
#define PHAL_MFPEV1_ERR_AUTH           ((phStatus_t)PH_ERR_CUSTOM_BEGIN + 0U)     /*< MFP EV1 Authentication Error. */
#define PHAL_MFPEV1_ERR_CMD_OVERFLOW   ((phStatus_t)PH_ERR_CUSTOM_BEGIN + 1U)     /*< MFP EV1 Command Overflow Error. */
#define PHAL_MFPEV1_ERR_MAC_PCD        ((phStatus_t)PH_ERR_CUSTOM_BEGIN + 2U)     /*< MFP EV1 MAC Error. */
#define PHAL_MFPEV1_ERR_BNR            ((phStatus_t)PH_ERR_CUSTOM_BEGIN + 3U)     /*< MFP EV1 Blocknumber Error. */
#define PHAL_MFPEV1_ERR_EXT            ((phStatus_t)PH_ERR_CUSTOM_BEGIN + 4U)     /*< MFP EV1 Extension Error. */
#define PHAL_MFPEV1_ERR_CMD_INVALID    ((phStatus_t)PH_ERR_CUSTOM_BEGIN + 5U)     /*< MFP EV1 Invalid Command Error. */
#define PHAL_MFPEV1_ERR_FORMAT         ((phStatus_t)PH_ERR_CUSTOM_BEGIN + 6U)     /*< MFP EV1 Authentication Error. */
#define PHAL_MFPEV1_ERR_GEN_FAILURE    ((phStatus_t)PH_ERR_CUSTOM_BEGIN + 7U)     /*< MFP EV1 Generic Error. */
#define PHAL_MFPEV1_ERR_TM             ((phStatus_t)PH_ERR_CUSTOM_BEGIN + 8U)     /*< MFP EV1 Transaction MAC related Error. */
#define PHAL_MFPEV1_ERR_NOT_SUP        ((phStatus_t)PH_ERR_CUSTOM_BEGIN + 9U)     /*< MFP EV1 Not Supported Error. */

#define PHAL_MFPEV1_ISO7816_ERR_WRONG_LENGTH    ((phStatus_t)PH_ERR_CUSTOM_BEGIN + 10U) /*< MFP Ev1 7816 wrong length error */
#define PHAL_MFPEV1_ISO7816_ERR_WRONG_PARAMS    ((phStatus_t)PH_ERR_CUSTOM_BEGIN + 11U) /*< MFP Ev1 7816 wrong params error */
#define PHAL_MFPEV1_ISO7816_ERR_WRONG_LC        ((phStatus_t)PH_ERR_CUSTOM_BEGIN + 12U) /*< MFP Ev1 7816 wrong Lc error */
#define PHAL_MFPEV1_ISO7816_ERR_WRONG_LE        ((phStatus_t)PH_ERR_CUSTOM_BEGIN + 13U) /*< MFP Ev1 7816 wrong LE error */
#define PHAL_MFPEV1_ISO7816_ERR_WRONG_CLA       ((phStatus_t)PH_ERR_CUSTOM_BEGIN + 14U) /*< MFP Ev1 7816 wrong CLA error */
/*@}*/

/**
* \name Sizes
*/
/*@{*/
#define PHAL_MFPEV1_SIZE_TI             4U      /**< Size of Transaction Identifier. */
#define PHAL_MFPEV1_SIZE_TMC            4U      /**< Size of the transaction MAC counter */
#define PHAL_MFPEV1_SIZE_TMV            8U      /**< Size of the transaction MAC vale */
#define PHAL_MFPEV1_SIZE_IV             16U     /**< Size of Initialization vector. */
#define PHAL_MFPEV1_SIZE_TMRI           16U     /**< Size of TMRI */
#define PHAL_MFPEV1_SIZE_ENCTMRI        16U     /**< Size of encrypted transaction MAC reader ID */
#define PHAL_MFPEV1_SIZE_KEYMODIFIER    6U      /**< Size of MIFARE KeyModifier. */
#define PHAL_MFPEV1_SIZE_MAC            16U     /**< Size of (untruncated) MAC. */
/*@}*/

#define PHAL_MFPEV1_UID_TYPE_UIDF0      0x00U     /**< MIFARE(R) Plus EV1 UID type UIDF0. */
#define PHAL_MFPEV1_UID_TYPE_UIDF1      0x40U     /**< MIFARE(R) Plus EV1 UID type UIDF1. */
#define PHAL_MFPEV1_UID_TYPE_UIDF2      0x20U     /**< MIFARE(R) Plus EV1 UID type UIDF2. */
#define PHAL_MFPEV1_UID_TYPE_UIDF3      0x60U     /**< MIFARE(R) Plus EV1 UID type UIDF3. */

#define PHAL_MFPEV1_WRAPPED_MODE        0xA1U   /**< Option for GetConfig/SetConfig to get/set current status of command wrapping in ISO 7816-4 APDUs. */
#define PHAL_MFPEV1_EXTENDED_APDU       0xA2U   /**< Option for GetConfig/SetConfig to get/set current status of extended wrapping in ISO 7816-4 APDUs. */
#define PHAL_MFPEV1_AUTH_MODE           0xA3U   /**< Option to set the autho mode to perform negative testing. */

#define PHAL_MFPEV1_ORIGINALITY_KEY_0          0x8000U
#define PHAL_MFPEV1_ORIGINALITY_KEY_1          0x8001U
#define PHAL_MFPEV1_ORIGINALITY_KEY_2          0x8002U
#define PHAL_MFPEV1_ORIGINALITY_KEY_3          0x8003U
#define PHAL_MFPEV1_ORIGINALITY_KEY_FIRST      PHAL_MFPEV1_ORIGINALITY_KEY_0
#define PHAL_MFPEV1_ORIGINALITY_KEY_LAST       PHAL_MFPEV1_ORIGINALITY_KEY_3
#define PHAL_MFPEV1_L3SWITCHKEY                0x9003U
#define PHAL_MFPEV1_SL1CARDAUTHKEY             0x9004U
#define PHAL_MFPEV1_L3SECTORSWITCHKEY          0x9006U
#define PHAL_MFPEV1_L1L3MIXSECTORSWITCHKEY     0x9007U

/** @} */
#endif /* NXPBUILD__PHAL_MFPEV1 */

#ifdef NXPBUILD__PHAL_MFPEV1_SW



/** \defgroup phalMfpEv1_Sw Component : Software
* @{
*/

#define PHAL_MFPEV1_SW_ID          0x01U    /**< ID for Software MIFARE Plus layer. */

/**
* \name Security Level
*/
/** @{ */
#define PHAL_MFPEV1_NOTAUTHENTICATED            0x00U                    /**< MFP EV1 not authenticated. */
#define PHAL_MFPEV1_SL1_MIFARE_AUTHENTICATED    0x01U                    /**< MFP EV1 SL1 MIFARE Authentication mode. */
#define PHAL_MFPEV1_SL1_MFP_AUTHENTICATED       0x02U                    /**< MFP EV1 SL1 Authentication mode. */
#define PHAL_MFPEV1_SL3_MFP_AUTHENTICATED       0x03U                    /**< MFP EV1 SL3 Authentication mode. */
#define PHAL_MFPEV1_NOT_AUTHENTICATED_L3        0x04U                    /**< MFP EV1 not authenticated in ISO Layer 3. */
#define PHAL_MFPEV1_NOT_AUTHENTICATED_L4        0x05U                    /**< MFP EV1 not authenticated in ISO Layer 4. */
/** @} */

/**
* \name MIFARE Plus EV1 response sizes for GetVersion command.
*/
/*@{*/
#define PHAL_MFPEV1_VERSION_COMMAND_LENGTH      41U /**< Version command buffer size. Size = Status(1) + R_Ctr(2) + TI(4) + VersionA(7) + VersionB(7) + VersionC(20) */
#define PHAL_MFPEV1_VERSION_INFO_LENGTH         33U /**< Version buffer size to store the complete information. Size = VersionA(7) + VersionB(7) + VersionC(20) */
#define PHAL_MFPEV1_VERSION_PART1_LENGTH        07U /**< Version part 1 length in the received response. */
#define PHAL_MFPEV1_VERSION_PART2_LENGTH        07U /**< Version part 2 length in the received response. */

#define PHAL_MFPEV1_VERSION_PART3_LENGTH_04B    13U /**< Version part 3 length in the received response in case of 4 byte UID. */
#define PHAL_MFPEV1_VERSION_PART3_LENGTH_07B    14U /**< Version part 3 length in the received response in case of 7 byte UID. */
#define PHAL_MFPEV1_VERSION_PART3_LENGTH_10B    19U /**< Version part 3 length in the received response in case of 10 byte UID. */
/*@}*/

/**
* \brief MIFARE Plus EV1 Software parameter structure
*/
typedef struct
{
    uint16_t wId;                                           /**< Layer ID for this component, NEVER MODIFY! */
    void * pPalMifareDataParams;                            /**< Pointer to the parameter structure of the palMifare component. */
    void * pKeyStoreDataParams;                             /**< Pointer to the parameter structure of the KeyStore layer. */
    void * pCryptoDataParamsEnc;                            /**< Pointer to the parameter structure of the Crypto layer for encryption. */
    void * pCryptoDataParamsMac;                            /**< Pointer to the parameter structure of the Crypto layer for macing. */
    void * pCryptoRngDataParams;                            /**< Pointer to the parameter structure of the CryptoRng layer. */
    void * pCryptoDiversifyDataParams;                      /**< Pointer to the parameter structure of the CryptoDiversify layer (can be NULL). */
    uint8_t bKeyModifier[PHAL_MFPEV1_SIZE_KEYMODIFIER];     /**< Key Modifier for MIFARE Plus SL2 authentication. */
    uint16_t wRCtr;                                         /**< R_CTR (read counter); The PICC's read counter is used for a following authentication. */
    uint16_t wWCtr;                                         /**< W_CTR (write counter); The PICC's write counter is used for a following authentication. */
    uint8_t bWrappedMode;                                   /**< Wrapped APDU mode. All native commands need to be sent wrapped in ISO 7816 APDUs. */
    uint8_t bExtendedLenApdu;                               /**< Extended length APDU. If set the native commands should be wrapped in extended format */
    uint8_t bTi[PHAL_MFPEV1_SIZE_TI];                       /**< Transaction Identifier; unused if 'bFirstAuth' = 1; uint8_t[4]. */
    uint8_t bNumUnprocessedReadMacBytes;                    /**< Amount of data in the pUnprocessedReadMacBuffer. */
    uint8_t pUnprocessedReadMacBuffer[PHAL_MFPEV1_SIZE_MAC];/**< Buffer containing unprocessed bytes for read mac answer stream. */
    uint8_t pIntermediateMac[PHAL_MFPEV1_SIZE_MAC];         /**< Intermediate MAC for Read Calculation. */
    uint8_t bFirstRead;                                     /**< Indicates whether the next read is a first read in a read (MACed) sequence or not. */
    uint8_t bTMC[PHAL_MFPEV1_SIZE_TMC];                     /**< Buffer containing the Transaction MAC counter data. */
    uint8_t bTMV[PHAL_MFPEV1_SIZE_TMV];                     /**< Buffer containing the Transaction MAC value. */
    uint8_t bIv[16];                                        /**< Initialization vector. Max size of IV can be 16 bytes */
    uint8_t bSesAuthENCKey[16];                             /**< Authentication ENC key for the session. */
    uint8_t bSesAuthMACKey[16];                             /**< Authentication MAC key for the session. */
    void * pTMIDataParams;                                  /**< Pointer to the parameter structure for collecting TMI. */
    uint8_t bAuthMode;                                      /**< Security level authenticate */
    uint8_t bSMMode;                                        /**< Secure messaging mode. \c 0: EV0 Mode; \c 1: EV1 mode */
    void * pVCADataParams;                                  /**< Pointer to the parameter structure for Virtual Card. */
} phalMfpEv1_Sw_DataParams_t;

/**
* \brief Initialise this layer.
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
*/
phStatus_t phalMfpEv1_Sw_Init(
    phalMfpEv1_Sw_DataParams_t * pDataParams,/**< [In] Pointer to this layer's parameter structure. */
    uint16_t wSizeOfDataParams,              /**< [In] Specifies the size of the data parameter structure. */
    void * pPalMifareDataParams,             /**< [In] Pointer to a palMifare component context. */
    void * pKeyStoreDataParams,              /**< [In] Pointer to a KeyStore component context. */
    void * pCryptoDataParamsEnc,             /**< [In] Pointer to a Crypto component context for encryption. */
    void * pCryptoDataParamsMac,             /**< [In] Pointer to a Crypto component context for Macing. */
    void * pCryptoRngDataParams,             /**< [In] Pointer to a CryptoRng component context. */
    void * pCryptoDiversifyDataParams,       /**< [In] Pointer to the parameter structure of the CryptoDiversify layer (can be NULL). */
    void * pTMIDataParams,                   /**< [In] Pointer to a TMI component. */
    void * pVCADataParams                    /**< [In] Pointer to the parameter structure for Virtual Card. */
    );

phStatus_t phalMfpEv1_Sw_SetVCAParams(
                phalMfpEv1_Sw_DataParams_t * pDataParams,
                void * pAlVCADataParams
                );

/** @} */
#endif /* NXPBUILD__PHAL_MFPEV1_SW */



#ifdef NXPBUILD__PHAL_MFPEV1

/** \addtogroup phalMfpEv1
* @{
*/

/**
* \name Security Level 0
*/
/*@{*/

/**
* \brief Performs a MIFARE Plus Write Perso command.
*
* The Write Perso command can be executed using the ISO14443-3 communication protocol (after layer 3 activation)\n
* or using the ISO14443-4 protocol (after layer 4 activation)\n
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfpEv1_WritePerso(
    void * pDataParams,   /**< [In] Pointer to this layer's parameter structure. */
    uint8_t bLayer4Comm,  /**< [In] \c 0: use ISO14443-3 protocol; \c 1: use ISO14443-4 protocol. */
    uint16_t wBlockNr,    /**< [In] MIFARE Block number. */
    uint8_t bNumBlocks,   /**< [In] Number of blocks to write. */
    uint8_t * pValue      /**< [In] Value (16 bytes). */
    );

/**
* \brief Perform MIFARE(R) EV1 Commit Perso command
*
*This API performs a MIFARE Plus EV1 Commit Perso command.
* The Commit Perso command consists of the 1-byte command code and optionally a 1-byte Option field
* The Commit Perso command can be executed using the ISO14443-3 communication protocol (after layer 3 activation)
* or using the ISO14443-4 protocol (after layer 4 activation).
* bOption 0x00, for backward compatibility (i.e. no option byte sent), 0x01..0x03 for L1 cards and 0x03 for L3 cards.
*
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*
*/

phStatus_t phalMfpEv1_CommitPerso(
    void * pDataParams, /**< [In] Pointer to this layer's parameter structure. */
    uint8_t bOption,        /**< [In] 0x01..0x03  for L1 cards, 0x03 for L3 cards and 0 for backward compatibility */
    uint8_t bLayer4Comm /**< [In] \c 0: use ISO14443-3 protocol; \c 1: use ISO14443-4 protocol; */
    );

/**
* \brief Performs a complete MIFARE Plus Authentication for Security Level 0.
*
* The high-level function performs a 2-step (in future applications also 3-step) authentication.\n
* See the section Evolution on the Main Page regarding future changes in the key parameter.\n\n
*
* The following table shows which parameter is relevant depending on the parameters bLayer4Comm and bFirstAuth.\n
* An "X" encodes that this parameter is relevant. A "-" encodes that this parameter is ignored (if it is an in-parameter) or that it shall be ignored (if it is an out-parameter).\n
*
\verbatim
+-------------+-------+-------+
| bFirstAuth  |   0   |   1   |
+-------------+---+---+---+---+
| bLayer4Comm | 0 | 1 | 0 | 1 |
+-------------+---+---+---+---+
| wBlockNr    | X | X | X | X |
| pKx         | X | X | X | X |
| pRndA       | X | X | X | X |
| bLenPcdCap2 | - | - | - | X |
| pPcdCap2    | - | - | - | X |
| pPdCap2     | - | - | - | X |
+-------------+---+---+---+---+
\endverbatim
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfpEv1_AuthenticateSL0(
    void * pDataParams,      /**< [In] Pointer to this layer's parameter structure. */
    uint8_t bLayer4Comm,     /**< [In] \c 0: use ISO14443-3 protocol; \c 1: use ISO14443-4 protocol; */
    uint8_t bFirstAuth,      /**< [In] \c 0: Following Authentication; \c 1: First Authentication; */
    uint16_t wBlockNr,       /**< [In] Key Block number. */
    uint16_t wKeyNumber,     /**< [In] Key Storage number. */
    uint16_t wKeyVersion,    /**< [In] Key Storage version. */
    uint8_t bLenDivInput,    /**< [In] Length of diversification input used to diversify the key. If 0, no diversification is performed. */
    uint8_t * pDivInput,     /**< [In] Diversification Input used to diversify the key. */
    uint8_t bLenPcdCap2,     /**< [In] Length of the supplied PCDCaps. */
    uint8_t * pPcdCap2In,    /**< [In] Pointer to PCDCaps (bLenPcdCap2 bytes), ignored if bLenPcdCap2 == 0. */
    uint8_t * pPcdCap2Out,   /**< [Out] Pointer to PCD Caps sent from the card (6 bytes). */
    uint8_t * pPdCap2        /**< [Out] Pointer to PDCaps sent from the card (6 bytes). */
    );

/** @} */

/**
* \name Security Level 1
*/
/*@{*/

/**
* \brief Performs a complete MIFARE Plus Authentication for Security Level 1.
*
* The high-level function performs a 2-step (in future applications also 3-step) authentication.\n
* See the section Evolution on the Main Page regarding future changes in the key parameter.\n\n
*
* The following table shows which parameter is relevant depending on the parameters bLayer4Comm and bFirstAuth.\n
* An "X" encodes that this parameter is relevant. A "-" encodes that this parameter is ignored (if it is an in-parameter) or that it shall be ignored (if it is an out-parameter).\n
*
\verbatim
+-------------+-------+-------+
| bFirstAuth  |   0   |   1   |
+-------------+---+---+---+---+
| bLayer4Comm | 0 | 1 | 0 | 1 |
+-------------+---+---+---+---+
| wBlockNr    | X | X | X | X |
| pKx         | X | X | X | X |
| pRndA       | X | X | X | X |
| bLenPcdCap2 | - | - | - | X |
| pPcdCap2    | - | - | - | X |
| pPdCap2     | - | - | - | X |
+-------------+---+---+---+---+
\endverbatim
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfpEv1_AuthenticateSL1(
    void * pDataParams,      /**< [In] Pointer to this layer's parameter structure. */
    uint8_t bLayer4Comm,     /**< [In] \c 0: use ISO14443-3 protocol; \c 1: use ISO14443-4 protocol; */
    uint8_t bFirstAuth,      /**< [In] \c 0: Following Authentication; \c 1: First Authentication; */
    uint16_t wBlockNr,       /**< [In] Key Block number. */
    uint16_t wKeyNumber,     /**< [In] Key Storage number. */
    uint16_t wKeyVersion,    /**< [In] Key Storage version. */
    uint8_t bLenDivInput,    /**< [In] Length of diversification input used to diversify the key. If 0, no diversification is performed. */
    uint8_t * pDivInput,     /**< [In] Diversification Input used to diversify the key. */
    uint8_t bLenPcdCap2,     /**< [In] Length of the supplied PCDCaps. */
    uint8_t * pPcdCap2In,    /**< [In] Pointer to PCDCaps (bLenPcdCap2 bytes), ignored if bLenPcdCap2 == 0. */
    uint8_t * pPcdCap2Out,   /**< [Out] Pointer to PCD Caps sent from the card (6 bytes). */
    uint8_t * pPdCap2        /**< [Out] Pointer to PDCaps sent from the card (6 bytes). */
    );

/**
* \brief Perform MIFARE(R) Sector switch authentication command.
*
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*
*/
phStatus_t phalMfpEv1_SSAuthenticate (
    void * pDataParams,                 /**< [In] Pointer to this layer's parameter structure. */
    uint8_t bOption,                    /**< [In] Options for key diversification. Only applicable for SAM component, ignored for Software component.
                                         *        0x00 : No Master key diversification using Sector number.
                                         *        0x04 : Master key diversification using Sector number.
                                         */
    uint16_t wSSKeyBNr,                 /**< [In] Appropriate block number for Sector Switch key. */
    uint16_t wSSKeyNr,                  /**< [In] Key Storage number of the sector switch key(SSKey) */
    uint16_t wSSKeyVer,                 /**< [In] Key Storage version of the sector switch key(SSKey) */
    uint8_t bLenDivInputSSKey,          /**< [In] Length of diversification input used to diversify the sector switch key. If 0, no diversification is performed. */
    uint8_t * pDivInputSSKey,           /**< [In] Diversification Input used to diversify the sector switch key. */
    uint8_t bSecCount,                  /**< [In] Number of sectors to be moved to higher security level */
    uint16_t *pSectorNos,               /**< [In] The list of AES sector B key numbers. */
    uint16_t *pKeyNos,                  /**< [In] If Option is set to use the Master sector key, then the master sector key number should be passed, else
                                         *        individual Sector B key number should be passed.
                                         */
    uint16_t *pKeyVers,                 /**< [In] If Option is set to use the Master sector key, then the master sector key version should be passed, else
                                         *        individual Sector B key version should be passed.
                                         */
    uint8_t bLenDivInputSectorKeyBs,    /**< [In] Length of diversification input used to diversify the AES Sector B key.
                                         *        For SAM if length is 0, the diversification input passed for Sector Switch key will be used.
                                         *        For SW if length is 0, no diversification is performed.
                                         */
    uint8_t * pDivInputSectorKeyBs      /**< [In] Diversification Input used to diversify the AES Sector B key. */
    );


/**
* \brief Perform MIFARE Authenticate command in Security Level 1 with MIFARE CLASSIC.
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfpEv1_AuthenticateMfc(
    void * pDataParams,     /**< [In] Pointer to this layer's parameter structure. */
    uint8_t bBlockNo,       /**< [In] Blocknumber on Card to authenticate to. */
    uint8_t bKeyType,       /**< [In] Either /ref PHHAL_HW_MFC_KEYA or /ref PHHAL_HW_MFC_KEYB. */
    uint16_t wKeyNumber,    /**< [In] Key number to be used in authentication. */
    uint16_t wKeyVersion,   /**< [In] Key version to be used in authentication. */
    uint8_t * pUid,         /**< [In] UID. */
    uint8_t bUidLength      /**< [In] UID length provided. */
    );

/**
* \brief Perform MIFARE(R) Personalize UID usage command sequence with MIFARE Picc.
* UID type can be one of
* \li #PHAL_MFPEV1_UID_TYPE_UIDF0
* \li #PHAL_MFPEV1_UID_TYPE_UIDF1
* \li #PHAL_MFPEV1_UID_TYPE_UIDF2
* \li #PHAL_MFPEV1_UID_TYPE_UIDF3
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
*/
phStatus_t phalMfpEv1_PersonalizeUid(
    void * pDataParams,   /**< [In] Pointer to this layer's parameter structure. */
    uint8_t bUidType      /**< [In] UID type. */
    );

/**
* \brief Performs a configuration for ISO1443-4 enabling in Security Level 1.
*
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfpEv1_SetConfigSL1(
                                void * pDataParams, /**< [In] Pointer to this layer's parameter structure. */
                                uint8_t bOption     /**< [In] Option for ISO14443-4. \c0x00 - Enable ISO14443-4; \c0x01 - Disable ISO14443-4; */
                                );

/**
* \brief Performs read of the TMAC block in security layer 1 with ISO14443 Layer 3 activated.
*
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfpEv1_ReadSL1TMBlock(
                                void * pDataParams,     /**< [In] Pointer to this layer's parameter structure. */
                                uint16_t wBlockNr,      /**< [In] MIFARE TMAC block number. */
                                uint8_t * pBlocks       /**< [Out] TMAC block data.  */
                                );
/** @} */

/**
* \name Security Level 3
*/
/*@{*/

/**
* \brief Performs a complete MIFARE Plus Authentication and Key Derivation for Security Level 3.
*
* The high-level function performs a 2-step (in future applications also 3-step) authentication.\n
* The function computes the resulting session keys for encryption and MACing and stores them in the card state structure.\n
* See the section Evolution on the Main Page regarding future changes in the key parameter.\n\n
*
* The following table shows which parameter is relevant depending on the parameters bLayer4Comm and bFirstAuth.\n
* An "X" encodes that this parameter is relevant. A "-" encodes that this parameter is ignored (if it is an in-parameter) or that it shall be ignored (if it is an out-parameter).\n
*
\verbatim
+-------------+-------+-------+
| bFirstAuth  |   0   |   1   |
+-------------+---+---+---+---+
| wBlockNr    | X | X | X | X |
| pKx         | X | X | X | X |
| pRndA       | X | X | X | X |
| bLenPcdCap2 | - | - | - | X |
| pPcdCap2    | - | - | - | X |
| pPdCap2     | - | - | - | X |
+-------------+---+---+---+---+
\endverbatim
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfpEv1_AuthenticateSL3(
    void * pDataParams,      /**< [In] Pointer to this layer's parameter structure. */
    uint8_t bFirstAuth,      /**< [In] \c 0: Following Authentication; \c 1: First Authentication; */
    uint16_t wBlockNr,       /**< [In] Key Block number. */
    uint16_t wKeyNumber,     /**< [In] Key Storage number. */
    uint16_t wKeyVersion,    /**< [In] Key Storage version. */
    uint8_t bLenDivInput,    /**< [In] Length of diversification input used to diversify the key. If 0, no diversification is performed. */
    uint8_t * pDivInput,     /**< [In] Diversification Input used to diversify the key. */
    uint8_t bLenPcdCap2,     /**< [In] Length of the supplied PCDCaps. */
    uint8_t * pPcdCap2In,    /**< [In] Pointer to PCDCaps (bLenPcdCap2 bytes), ignored if bLenPcdCap2 == 0. */
    uint8_t * pPcdCap2Out,   /**< [Out] Pointer to PCD Caps sent from the card (6 bytes). */
    uint8_t * pPdCap2        /**< [Out] Pointer to PDCaps sent from the card (6 bytes). */
    );
/** @} */

/**
* \name Security Level 1 and 3 - Data operations.
*/
/*@{*/

/**
* \brief Performs a Write / Write MACed command.
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfpEv1_Write(
    void * pDataParams,    /**< [In] Pointer to this layer's parameter structure. */
    uint8_t bEncrypted,    /**< [In] \c 0: Plain communication; \c 1: Encrypted communication; */
    uint8_t bWriteMaced,   /**< [In] \c 0: No MAC on response; \c 1: MAC on response; */
    uint16_t wBlockNr,     /**< [In] MIFARE block number. */
    uint8_t bNumBlocks,    /**< [In] Number of blocks to write (must not be more than 3). */
    uint8_t * pBlocks,      /**< [In] Block(s) (16u*bNumBlocks bytes).  */
    uint8_t * pTMC,         /**< [Out] 4 byte TMAC counter. */
    uint8_t * pTMV          /**< [Out] 8 byte TMAC value. */
    );

/**
* \brief Performs a Read / Read MACed command.
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfpEv1_Read(
    void * pDataParams,     /**< [In] Pointer to this layer's parameter structure. */
    uint8_t bEncrypted,     /**< [In] \c 0: Plain communication; \c 1: Encrypted communication; */
    uint8_t bReadMaced,     /**< [In] \c 0: No MAC on response; \c 1: MAC on response; */
    uint8_t bMacOnCmd,      /**< [In] \c 0: No MAC on command; \c 1: MAC on command; */
    uint16_t wBlockNr,      /**< [In] MIFARE block number. */
    uint8_t bNumBlocks,     /**< [In] Number of blocks to read. */
    uint8_t * pBlocks       /**< [Out] Block(s) (16u*bNumBlocks bytes).  */
    );
/** @} */

/**
* \name Security Level 1 and 3 - Value Operations
*/
/*@{*/

/**
* \brief Performs a Write / Write MACed command of a value.
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfpEv1_WriteValue(
    void * pDataParams,     /**< [In] Pointer to this layer's parameter structure. */
    uint8_t bEncrypted,     /**< [In] \c 0: Plain communication; \c 1: Encrypted communication; */
    uint8_t bWriteMaced,    /**< [In] \c 0: No MAC on response; \c 1: MAC on response; */
    uint16_t wBlockNr,      /**< [In] MIFARE block number. */
    uint8_t * pValue,       /**< [In] pValue[4] containing value (LSB first) read from the MIFARE(R) card */
    uint8_t bAddrData,      /**< [In] bAddrData containing address written to the MIFARE(R) card value block. */
    uint8_t * pTMC,         /**< [Out] 4 byte TMAC counter. */
    uint8_t * pTMV          /**< [Out] 8 byte TMAC value. */
    );

/**
* \brief Performs a Read / Read MACed Value command.
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfpEv1_ReadValue(
    void * pDataParams,    /**< [In] Pointer to this layer's parameter structure. */
    uint8_t bEncrypted,    /**< [In] \c 0: Plain communication; \c 1: Encrypted communication; */
    uint8_t bReadMaced,    /**< [In] \c 0: No MAC on response; \c 1: MAC on response; */
    uint8_t bMacOnCmd,     /**< [In] \c 0: No MAC on command; \c 1: MAC on command; */
    uint16_t wBlockNr,     /**< [In] MIFARE block number. */
    uint8_t * pValue,      /**< [Out] pValue[4] containing value (LSB first) read from the MIFARE(R) card */
    uint8_t * pAddrData    /**< [Out] bAddrData containing address read from the MIFARE(R) card value block*/
    );

/**
* \brief Performs an Increment / Increment MACed command.
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfpEv1_Increment(
    void * pDataParams,        /**< [In] Pointer to this layer's parameter structure. */
    uint8_t bIncrementMaced,   /**< [In] \c 0: No MAC on response; \c 1: MAC on response; */
    uint16_t wBlockNr,         /**< [In] MIFARE Source block number. */
    uint8_t * pValue           /**< [In] pValue[4] containing value (LSB first) read from the MIFARE(R) card */
    );

/**
* \brief Performs a Decrement / Decrement MACed command.
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfpEv1_Decrement(
    void * pDataParams,        /**< [In] Pointer to this layer's parameter structure. */
    uint8_t bDecrementMaced,   /**< [In] \c 0: No MAC on response; \c 1: MAC on response; */
    uint16_t wBlockNr,         /**< [In] MIFARE Source block number. */
    uint8_t * pValue           /**< [In] pValue[4] containing value (LSB first) read from the MIFARE(R) card */
    );

/**
* \brief Performs an Increment Transfer / Increment Transfer MACed command.
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfpEv1_IncrementTransfer(
    void * pDataParams,                /**< [In] Pointer to this layer's parameter structure. */
    uint8_t bIncrementTransferMaced,   /**< [In] \c 0: No MAC on response; \c 1: MAC on response; */
    uint16_t wSourceBlockNr,           /**< [In] MIFARE Source block number. */
    uint16_t wDestinationBlockNr,      /**< [In] MIFARE Destination block number. */
    uint8_t * pValue,                   /**< [In] pValue[4] containing value (LSB first) read from the MIFARE(R) card */
    uint8_t * pTMC,         /**< [Out] 4 byte TMAC counter. */
    uint8_t * pTMV          /**< [Out] 8 byte TMAC value. */
    );

/**
* \brief Performs a Decrement Transfer / Decrement Transfer MACed command.
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfpEv1_DecrementTransfer(
                                     void * pDataParams,                /**< [In] Pointer to this layer's parameter structure. */
                                     uint8_t bDecrementTransferMaced,   /**< [In] \c 0: No MAC on response; \c 1: MAC on response; */
                                     uint16_t wSourceBlockNr,           /**< [In] Source block number. */
                                     uint16_t wDestinationBlockNr,      /**< [In] Destination block number. */
                                     uint8_t * pValue,                   /**< [In] pValue[4] containing value (LSB first) read from the MIFARE(R) card */
                                     uint8_t * pTMC,            /**< [Out] 4 byte TMAC counter. */
                                     uint8_t * pTMV             /**< [Out] 8 byte TMAC value. */
                                     );

/**
* \brief Performs a Transfer / Transfer MACed command.
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfpEv1_Transfer(
    void * pDataParams,         /**< [In] Pointer to this layer's parameter structure. */
    uint8_t bTransferMaced,     /**< [In] \c 0: No MAC on response; \c 1: MAC on response; */
    uint16_t wBlockNr,           /**< [In] MIFARE Destination block number. */
    uint8_t * pTMC,         /**< [Out] 4 byte TMAC counter. */
    uint8_t * pTMV          /**< [Out] 8 byte TMAC value. */
    );

/**
* \brief Performs a Restore / Restore MACed command.
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfpEv1_Restore(
    void * pDataParams,      /**< [In] Pointer to this layer's parameter structure. */
    uint8_t bRestoreMaced,   /**< [In] \c 0: No MAC on response; \c 1: MAC on response; */
    uint16_t wBlockNr        /**< [In] MIFARE Source block number. */
    );
/** @} */

/**
* \name Special Commands
*/
/*@{*/

/**
* \brief Performs a Reset Auth command.
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfpEv1_ResetAuth(
    void * pDataParams     /**< [In] Pointer to this layer's parameter structure. */
    );

/**
* \brief Returns manufacturing related data of the PICC
* This API is valid in the following states.
* SL0NotAuthenticatedISOL4
* SL1NotAuthenticatedISOL4
* SL1MFPAuthenticated
* SL3NotAuthenticated
* SL3MFPAuthenticated
*
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfpEv1_GetVersion(
    void * pDataParams,     /**< [In] Pointer to this layers param structure. */
    uint8_t * pVerInfo      /**< [Out] 28 bytes of buffer to be provided by the user.The result has to be parsed for Sw, Hw and maufacturer info */
    );

/**
* \brief Read Signature
*
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfpEv1_ReadSign(
                                void * pDataParams,     /**< [In] Pointer to this layer's parameter structure. */
                                uint8_t bLayer4Comm,    /**< [In] \c 0: use ISO14443-3 protocol; \c 1: use ISO14443-4 protocol; */
                                uint8_t bAddr,          /**< [In] Targeted ECC originality check signature. */
                                uint8_t ** pSignature   /**< [Out] Card's orginality signature. */
                                );

/**
* \brief Performs a complete MIFARE Plus EV1 Post Delivery Configuration Authenticate.
*
* The high-level function performs a 2-step (in future applications also 3-step) authentication.\n
* See the section Evolution on the Main Page regarding future changes in the key parameter.\n\n
* The following table shows the dat for UpgradeInfo parameter.\n
* Where X being any value.\n
*
\verbatim
+-----------------+---------------+
| CardSize/SubType| bUpgrade Info |
+-----------------+---------------+
|      0.5k       |      0xX0     |
|      1k         |      0xX1     |
|      2k         |      0xX2     |
|      4k         |      0xX4     |
|      8k         |      0xX8     |
|      RFU        |   Other data  |
+-----------------+---------------+
\endverbatim
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfpEv1_AuthenticatePDC(
    void * pDataParams,      /**< [In] Pointer to this layer's parameter structure. */
    uint16_t wBlockNr,       /**< [In] Key Block number. */
    uint16_t wKeyNumber,     /**< [In] Key Storage number. */
    uint16_t wKeyVersion,    /**< [In] Key Storage version. */
    uint8_t bLenDivInput,    /**< [In] Length of diversification input used to diversify the key. If 0, no diversification is performed. */
    uint8_t * pDivInput,     /**< [In] Diversification Input used to diversify the key. */
    uint8_t bUpgradeInfo     /**< [In] The upgrade info input. */
    );

/**
* \brief Secures the transaction by commiting the application to ReaderID specified.
* The encrypted Transaction MAC Reader Id of the previous transaction is used by the
* backend that will decrypt this and check if the transaction was reported to be backend or not.
* This command is always sent with MAC protection.
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfpEv1_CommitReaderID(
                                      void * pDataParams,   /**< [In] Pointer to this layers param structure. */
                                      uint16_t wBlockNr,    /**< [In] Block numner of the TMProtectedblock. */
                                      uint8_t * pTMRI,      /**< [In] 16 bytes. TM Reader ID */
                                      uint8_t * pEncTMRI    /**< [Out] Encrypted TM Reader ID of the previous transaction. */
                                      );
/** @} */

/**
* \name General Commands.
*/
/*@{*/

/**
* \brief Performs a Key Change of a MIFARE Plus key. Same as phalMfpEv1_Write, but diversification input can be provided
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfpEv1_ChangeKey(
    void * pDataParams,         /**< [In] Pointer to this layer's parameter structure. */
    uint8_t bChangeKeyMaced,    /**< [In] \c 0: No MAC on response; \c 1: MAC on response; */
    uint16_t wBlockNr,          /**< [In] MIFARE block number. */
    uint16_t wKeyNumber,        /**< [In] Key number of key to be written to the card. */
    uint16_t wKeyVersion,       /**< [In] Key version of key to be written to the card. */
    uint8_t bLenDivInput,       /**< [In] Length of diversification input used to diversify the key. If 0, no diversification is performed. */
    uint8_t * pDivInput         /**< [In] Diversification Input used to diversify the key. */
    );

/**
* \brief Calculate TMV
*
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfpEv1_CalculateTMV(
                                    void * pDataParams,         /**< [In] Pointer to this layers parameter structure. */
                                    uint16_t wOption,           /**< [In] Diversification option. */
                                    uint16_t wKeyNoTMACKey,     /**< [In] Key number in key store of DAM MAC key. */
                                    uint16_t wKeyVerTMACKey,    /**< [In] Key version in key store of DAM MAC key. */
                                    uint8_t * pDivInput,        /**< [In] Diversification input for TMACKey. */
                                    uint8_t bDivInputLen,       /**< [In] Length of diversification input. */
                                    uint8_t *pTMC,              /**< [In] 4 bytes Transaction MAC Counter. */
                                    uint8_t * pUid,             /**< [In] 7 (or 10) byte UID of the card. */
                                    uint8_t bUidLen,            /**< [In] Length of UID supplied. */
                                    uint8_t * pTMI,             /**< [In] Transaction MAC Input. */
                                    uint16_t wTMILen,            /**< [In] Length of TMI. */
                                    uint8_t * pTMV              /**< [Out] Transaction MAC Value. */
                                    );

/**
* \brief Decrypt Reader ID
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfpEv1_DecryptReaderID(
                                        void * pDataParams,     /**< [In] Pointer to this layers parameter structure. */
                                        uint16_t wOption,       /**< [In] Diversification option. */
                                        uint16_t wKeyNoTMACKey, /**< [In] Key number in key store of DAM MAC key. */
                                        uint16_t wKeyVerTMACKey,/**< [In] Key version in key store of DAM MAC key. */
                                        uint8_t * pDivInput,    /**< [In] Diversification input for TMACKey. */
                                        uint8_t bDivInputLen,   /**< [In] Length of diversification input. */
                                        uint8_t *pTMC,          /**< [In] 4 bytes Transaction MAC Counter. */
                                        uint8_t * pUid,         /**< [In] 7 (or 10) byte UID of the card. */
                                        uint8_t bUidLen,        /**< [In] Length of UID supplied. */
                                        uint8_t * pEncTMRI,     /**< [In] Encrypted TMAC Reader Id (16 bytes). */
                                        uint8_t * pTMRIPrev     /**< [Out] Reader ID of the last successful transaction. */
                                        );

/**
* \brief Returns the Transaction MAC block data (TMC and TMV) received from the card after Write/Transfer
* command.
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfpEv1_GetTransactionMACBlockData(
    void * pDataParams, /**< [In] Pointer to this layer's parameter structure. */
    uint8_t* pTMC,      /**< [Out] Pointer to transaction MAC counter data received from the card. */
    uint8_t* pTMV       /**< [Out] Pointer to transaction MAC value received from the card. */
    );

/**
* \brief Perform a SetConfig command. Function to set the option for Wrapped mode and Extended APDU support.
*
* \c wOtpion can be one of:\n
* \li #PHAL_MFPEV1_WRAPPED_MODE
* \li #PHAL_MFPEV1_EXTENDED_APDU
* \li #PHAL_MFPEV1_AUTH_MODE
*
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfpEv1_SetConfig(
                                 void * pDataParams,   /**< [In] Pointer to this layers parameter structure. */
                                 uint16_t wOption,     /**< [In] Option to set.
                                                        *       \c 0xA1: Wrapped Mode;
                                                        *       \c 0xA2: Extended Mode;
                                                        *       \c 0xA3: Auth Mode
                                                        */
                                 uint16_t wValue       /**< [In] Value of the selected option.
                                                        *           Wrapped Mode:
                                                        *               \c 0: Disable; \c 1: Enable
                                                        *           Extended Mode:
                                                        *               \c 0: Disable; \c 1: Enable
                                                        *           Auth Mode:
                                                        *               \c 0: NotAuthenticate;
                                                        *               \c 1: SL1 Mifare Classic Authenticated;
                                                        *               \c 2: SL1 Mifare Plus Authenticated;
                                                        *               \c 3: SL3 Mifare Plus Authenticated;
                                                        *               \c 4: NotAuthenticate ISO14443 L3;
                                                        *               \c 5: NotAuthenticate ISO14443 L4
                                                        */
                                 );
/**
* \brief Perform a GetConfig command. Function to set the option of Wrapped mode and Extended APDU support.
*
* \c wOtpion can be one of:\n
* \li #PHAL_MFPEV1_WRAPPED_MODE
* \li #PHAL_MFPEV1_EXTENDED_APDU
* \li #PHAL_MFPEV1_AUTH_MODE
*
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfpEv1_GetConfig(
                                 void * pDataParams,  /**< [In] Pointer to this layers parameter structure. */
                                 uint16_t wOption,    /**< [In] Option to read.
                                                        *       \c 0xA1: Wrapped Mode;
                                                        *       \c 0xA2: Extended Mode;
                                                        *       \c 0xA3: Auth Mode
                                                        */
                                 uint16_t * pValue    /**< [Out] Value of the selected option.
                                                        *           Wrapped Mode:
                                                        *               \c 0: Disable; \c 1: Enable
                                                        *           Extended Mode:
                                                        *               \c 0: Disable; \c 1: Enable
                                                        *           Auth Mode:
                                                        *               \c 0: NotAuthenticate;
                                                        *               \c 1: SL1 Mifare Classic Authenticated;
                                                        *               \c 2: SL1 Mifare Plus Authenticated;
                                                        *               \c 3: SL3 Mifare Plus Authenticated;
                                                        *               \c 4: NotAuthenticate ISO14443 L3;
                                                        *               \c 5: NotAuthenticate ISO14443 L4
                                                        */
                                 );

/**
* \brief Reset the libraries internal secure messaging state.
*
* This function must be called before interacting with the PICC to set the libraries internal card-state back to default.\n
* E.g. when an error occurred or after a reset of the field.
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfpEv1_ResetSecMsgState(
    void * pDataParams  /**< [In] Pointer to this layer's parameter structure. */
    );
/** @} */

/**
* \name Virtual Card Commands.
*/
/*@{*/

/**
* \brief Performs a VCSupportLastISOL3 command operation. This command is a special variant of virtual card operation.
* This command can be sent after a ISO14443-3 activation.
*
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfpEv1_VCSupportLastISOL3(
                            void * pDataParams,     /* [IN] MFP EV1 parameter structure */
                            uint8_t *pIid,          /* [IN] IID Targeting ISO 14443-3 VC */
                            uint8_t *pPcdCapL3,     /* [IN] PCD capabilities. */
                            uint8_t *pInfo          /* [out] Info Byte */
                            );

/*@}*/

/**
* \name Security Level 2
* \see phalMfc
*/
/*@{*/

/**
* \brief Performs a complete MIFARE Plus Authentication and Key Derivation for Security Level 2.
*
* The high-level function performs a 2-step (in future applications also 3-step) authentication.\n
* The function provides the resulting MIFARE Sector Key Modifier.\n
* If a MIFARE Classic authentication is performed afterwards, use the MIFARE Sector Key Modifier XOR the MIFARE Classic sector key as the key.\n
* See the section Evolution on the Main Page regarding future changes in the key parameter.\n\n
*
* The following table shows which parameter is relevant depending on the parameters bLayer4Comm and bFirstAuth.\n
* An "X" encodes that this parameter is relevant. A "-" encodes that this parameter is ignored (if it is an in-parameter) or that it shall be ignored (if it is an out-parameter).\n
*
\verbatim
+-------------+-------+-------+
| bFirstAuth  |   0   |   1   |
+-------------+---+---+---+---+
| bLayer4Comm | 0 | 1 | 0 | 1 |
+-------------+---+---+---+---+
| wBlockNr    | X | X | X | X |
| pKx         | X | X | X | X |
| pRndA       | X | X | X | X |
| bLenPcdCap2 | - | - | - | X |
| pPcdCap2    | - | - | - | X |
| pPdCap2     | - | - | - | X |
| pKmf        | X | - | - | - |
+-------------+---+---+---+---+
\endverbatim
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfpEv1_AuthenticateSL2(
    void * pDataParams,      /**< [In] Pointer to this layer's parameter structure. */
    uint8_t bLayer4Comm,     /**< [In] \c 0: use ISO14443-3 protocol; \c 1: use ISO14443-4 protocol; */
    uint8_t bFirstAuth,      /**< [In] \c 0: Following Authentication; \c 1: First Authentication; */
    uint16_t wBlockNr,       /**< [In] Key Block number. */
    uint16_t wKeyNumber,     /**< [In] Key Storage number. */
    uint16_t wKeyVersion,    /**< [In] Key Storage version. */
    uint8_t bLenDivInput,    /**< [In] Length of diversification input used to diversify the key. If 0, no diversification is performed. */
    uint8_t * pDivInput,     /**< [In] Diversification Input used to diversify the key. */
    uint8_t bLenPcdCap2,     /**< [In] Length of the supplied PCDCaps. */
    uint8_t * pPcdCap2In,    /**< [In] Pointer to PCDCaps (bLenPcdCap2 bytes), ignored if bLenPcdCap2 == 0. */
    uint8_t * pPcdCap2Out,   /**< [Out] Pointer to PCD Caps sent from the card (6 bytes). */
    uint8_t * pPdCap2,       /**< [Out] Pointer to PDCaps sent from the card (6 bytes). */
    uint8_t * pKmf           /**< [Out] MIFARE Sector Key Modifier (6 bytes). */
    );

/**
* \brief Performs a Multi Block Read command.
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfpEv1_MultiBlockRead(
    void * pDataParams,   /**< [In] Pointer to this layer's parameter structure. */
    uint8_t bBlockNr,     /**< [In] MIFARE block number. */
    uint8_t bNumBlocks,   /**< [In] Number of blocks to read (must not be more than 3). */
    uint8_t * pBlocks     /**< [Out] Block(s) (16u*bNumBlocks bytes). */
    );

/**
* \brief Performs a Multi Block Write command.
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfpEv1_MultiBlockWrite(
    void * pDataParams,  /**< [In] Pointer to this layer's parameter structure. */
    uint8_t bBlockNr,    /**< [In] MIFARE block number. */
    uint8_t bNumBlocks,  /**< [In] Number of blocks to write (must not be more than 3). */
    uint8_t * pBlocks    /**< [In] Block(s) (16u*bNumBlocks bytes). */
    );

/**
* \brief This is a utility API which sets the VCA structure in MFP Ev1 structure params
* \return Status code
* \retval #PH_ERR_SUCCESS Operation successful.
* \retval Other Depending on implementation and underlying component.
*/
phStatus_t phalMfpEv1_SetVCAParams(
            void * pDataParams,
            void * pAlVCADataParams
            );
/** @} */

#endif /* NXPBUILD__PHAL_MFPEV1 */

#ifdef __cplusplus
} /* Extern C */
#endif

#endif /* PHALMFPEV1_H */
