/*
*         Copyright (c), NXP Semiconductors Bangalore / India
*
*                     (C)NXP Semiconductors
*       All rights are reserved. Reproduction in whole or in part is
*      prohibited without the written consent of the copyright owner.
*  NXP reserves the right to make changes without notice at any time.
* NXP makes no warranty, expressed, implied or statutory, including but
* not limited to any implied warranty of merchantability or fitness for any
*particular purpose, or that the use will not infringe any third party patent,
* copyright or trademark. NXP must not be liable for any loss or damage
*                          arising from its use.
*/

/** \file
* Internal functions of Software implementation of MIFARE DESFIRE EV2 application layer.
* $Author: NXP99556 $
* $Revision: 2139 $ (v05.07.00)
* $Date: 2016-09-19 15:52:28 +0530 (Mon, 19 Sep 2016) $
*/

#ifndef PHALMFDFEV2_INT_H
#define PHALMFDFEV2_INT_H

#include <ph_Status.h>
#include <phalMfdfEv2.h>

/** \addtogroup ph_Private
* @{
*/

/**
* \name MIFARE Desfire Native Commands
*/

/*@{*/

#define PHAL_MFDFEV2_CMD_AUTHENTICATE                  0x0AU    /**< MFDFEV2 Authenticate command. */
#define PHAL_MFDFEV2_CMD_AUTHENTICATE_ISO              0x1AU    /**< MFDFEV2 Authenticate ISO command. */
#define PHAL_MFDFEV2_CMD_AUTHENTICATE_AES              0xAAU    /**< MFDFEV2 Authenticate AES command. */
#define PHAL_MFDFEV2_CMD_AUTHENTICATE_EV2_FIRST        0x71U    /**< MFDFEV2 Authenticate Ev2 First command. */
#define PHAL_MFDFEV2_CMD_AUTHENTICATE_EV2_NON_FIRST    0x77U    /**< MFDFEV2 Authenticate Ev2 Non First command. */
#define PHAL_MFDFEV2_CMD_AUTHENTICATE_PART2            0xAFU   /**< Authentication second part; 0xAFU. */
#define PHAL_MFDFEV2_CMD_CHANGE_KEY_SETTINGS           0x54U    /**< MFDFEV2 Change key settings cmd. */
#define PHAL_MFDFEV2_CMD_GET_KEY_SETTINGS              0x45U    /**< MFDFEV2 Get Key Settings Cmd.  */
#define PHAL_MFDFEV2_CMD_CHANGE_KEY                    0xC4U    /**< MFDFEV2 Change key cmd. */
#define PHAL_MFDFEV2_CMD_CHANGE_KEY_EV2                0xC6U    /**< MFDFEV2 Change key stored on PICC cmd. */
#define PHAL_MFDFEV2_CMD_GET_KEY_VERSION               0x64U    /**< MFDFEV2 Get Key Version. */
#define PHAL_MFDFEV2_CMD_INITIALIZE_KEY_SET            0x56U    /**< MFDFEV2 Initialize a key set cmd. */
#define PHAL_MFDFEV2_CMD_FINALIZE_KEY_SET              0x57U    /**< MFDFEV2 Finalize a key set cmd. */
#define PHAL_MFDFEV2_CMD_ROLL_KEY_SET                  0x55U    /**< MFDFEV2 Roll to a new key set cmd. */
#define PHAL_MFDFEV2_CMD_CREATE_APPLN                  0xCAU    /**< MFDFEV2 Create Application cmd. */
#define PHAL_MFDFEV2_CMD_CREATE_DELEGATED_APPLN        0xC9U    /**< MFDFEV2 Create Delegated Application cmd. */
#define PHAL_MFDFEV2_CMD_DELETE_APPLN                  0xDAU    /**< MFDFEV2 Delete Application cmd. */
#define PHAL_MFDFEV2_CMD_GET_APPLN_IDS                 0x6AU    /**< MFDFEV2 Get Application Ids cmd. */
#define PHAL_MFDFEV2_CMD_GET_DF_NAMES                  0x6DU    /**< MFDFEV2 Get Dedicated Fine names cmd. */
#define PHAL_MFDFEV2_CMD_GET_DELEGATED_INFO            0x69U    /**< MFDFEV2 Get Delegated info cmd. */
#define PHAL_MFDFEV2_CMD_SELECT_APPLN                  0x5AU    /**< MFDFEV2 Select Application Cmd. */
#define PHAL_MFDFEV2_CMD_FORMAT                        0xFCU    /**< MFDFEV2 Format PICC Cmd. */
#define PHAL_MFDFEV2_CMD_GET_VERSION                   0x60U    /**< MFDFEV2 Get Version cmd. */
#define PHAL_MFDFEV2_CMD_FREE_MEM                      0x6EU    /**< MFDFEV2 Free Memory cmd. */
#define PHAL_MFDFEV2_CMD_SET_CONFIG                    0x5CU    /**< MFDFEV2 Set Configuration Cmd. */
#define PHAL_MFDFEV2_CMD_GET_CARD_UID                  0x51U    /**< MFDFEV2 Get Card UID cmd. */
#define PHAL_MFDFEV2_CMD_GET_FILE_IDS                  0x6FU    /**< MFDFEV2 Get File IDs cmd. */
#define PHAL_MFDFEV2_CMD_GET_ISO_FILE_IDS              0x61U    /**< MFDFEV2 Get ISO File IDs cmd. */
#define PHAL_MFDFEV2_CMD_GET_FILE_SETTINGS             0xF5U    /**< MFDFEV2 Get File settings cmd. */
#define PHAL_MFDFEV2_CMD_CHANGE_FILE_SETTINGS          0x5FU    /**< MFDFEV2 Change file settings cmd. */
#define PHAL_MFDFEV2_CMD_CREATE_STD_DATAFILE           0xCDU    /**< MFDFEV2 Create Standard data file cmd. */
#define PHAL_MFDFEV2_CMD_CREATE_BKUP_DATAFILE          0xCBU    /**< MFDFEV2 Create Backup data file cmd. */
#define PHAL_MFDFEV2_CMD_CREATE_VALUE_FILE             0xCCU    /**< MFDFEV2 Create Value File cmd. */
#define PHAL_MFDFEV2_CMD_CREATE_LINEAR_RECFILE         0xC1U    /**< MFDFEV2 Create Linear record file cmd. */
#define PHAL_MFDFEV2_CMD_CREATE_CYCLIC_RECFILE         0xC0U    /**< MFDFEV2 Create Cyclic record file cmd. */
#define PHAL_MFDFEV2_CMD_CREATE_TRANSTN_MACFILE        0xCEU    /**< MFDFEV2 Create Transaction MAC file cmd. */
#define PHAL_MFDFEV2_CMD_DELETE_FILE                   0xDFU    /**< MFDFEV2 Delete File cmd. */
#define PHAL_MFDFEV2_CMD_READ_DATA                     0xBDU    /**< MFDFEV2 Read Data cmd. */
#define PHAL_MFDFEV2_CMD_READ_DATA_ISO                 0xADU    /**< MFDFEV2 Read Data cmd using ISO chaining. */
#define PHAL_MFDFEV2_CMD_WRITE_DATA                    0x3DU    /**< MFDFEV2 Write data cmd. */
#define PHAL_MFDFEV2_CMD_WRITE_DATA_ISO                0x8DU    /**< MFDFEV2 Write data cmd using ISO chaining. */
#define PHAL_MFDFEV2_CMD_GET_VALUE                     0x6CU    /**< MFDFEV2 Get Value cmd. */
#define PHAL_MFDFEV2_CMD_CREDIT                        0x0CU    /**< MFDFEV2 Credit cmd. */
#define PHAL_MFDFEV2_CMD_DEBIT                         0xDCU    /**< MFDFEV2 Debit cmd. */
#define PHAL_MFDFEV2_CMD_LIMITED_CREDIT                0x1CU    /**< MFDFEV2 Limited Credit cmd. */
#define PHAL_MFDFEV2_CMD_WRITE_RECORD                  0x3BU    /**< MFDFEV2 Write Record cmd. */
#define PHAL_MFDFEV2_CMD_WRITE_RECORD_ISO              0x8BU    /**< MFDFEV2 Write Record cmd using ISO chaining. */
#define PHAL_MFDFEV2_CMD_UPDATE_RECORD                 0xDBU    /**< MFDFEV2 Update Record cmd. */
#define PHAL_MFDFEV2_CMD_UPDATE_RECORD_ISO             0xBAU    /**< MFDFEV2 Update Record cmd using ISO chaining. */
#define PHAL_MFDFEV2_CMD_READ_RECORDS                  0xBBU    /**< MFDFEV2 Read Records cmd. */
#define PHAL_MFDFEV2_CMD_READ_RECORDS_ISO              0xABU    /**< MFDFEV2 Read Records cmd using ISO chaining. */
#define PHAL_MFDFEV2_CMD_UPDATE_RECORDS                0xF0U    /**< MFDFEV2 Update Records cmd. */
#define PHAL_MFDFEV2_CMD_CLEAR_RECORD_FILE             0xEBU    /**< MFDFEV2 Clear records file cmd. */
#define PHAL_MFDFEV2_CMD_COMMIT_TXN                    0xC7U    /**< MFDFEV2 Commit transaction cmd. */
#define PHAL_MFDFEV2_CMD_ABORT_TXN                     0xA7U    /**< MFDFEV2 Abort transaction cmd. */
#define PHAL_MFDFEV2_CMD_COMMIT_READER_ID              0xC8U    /**< MFDFEV2 Commit Reader ID cmd. */
#define PHAL_MFDFEV2_CMD_READ_SIG                      0x3CU    /**< MFDFEV2 Verify read signature command. */
#define PHAL_MFDFEV2_CMD_FORMAT_PICC                   0xFCU    /**< MFDFEV2 Format PICC Cmd. */
#define PHAL_MFDFEV2_CMD_CLEAR_RECORDS_FILE            0xEBU    /**< MFDFEV2 Clear records file cmd. */
#define PHAL_MFDFEV2_CMD_APPLY_SM                      0xAEU    /**< MFDFEV2 Apply Secure Messaging cmd. */
#define PHAL_MFDFEV2_CMD_UNDO_SM                       0xADU    /**< MFDFEV2 Undo Secure Messaging cmd. */

/*@}*/

/**
* \name MIFARE Desfire Response Codes
*/

/*@{*/

#define PHAL_MFDFEV2_RESP_OPERATION_OK                 0x00U    /**< MFDFEV2 Response - Successful operation. */
#define PHAL_MFDFEV2_RESP_OK                           0x90U    /**< MFDFEV2 Response - Successful operation. */
#define PHAL_MFDFEV2_RESP_NO_CHANGES                   0x0CU    /**< MFDFEV2 Response - No changes done to backup files. */
#define PHAL_MFDFEV2_RESP_ERR_OUT_OF_EEPROM_ERROR      0x0EU    /**< MFDFEV2 Response - Insufficient NV-Memory. */
#define PHAL_MFDFEV2_RESP_ILLEGAL_COMMAND_CODE         0x1CU    /**< MFDFEV2 command code not supported. */
#define PHAL_MFDFEV2_RESP_ERR_INTEGRITY_ERROR          0x1EU    /**< MFDFEV2 CRC or MAC does not match data padding bytes not valid. */
#define PHAL_MFDFEV2_RESP_NO_SUCH_KEY                  0x40U    /**< MFDFEV2 Invalid key number specified. */
#define PHAL_MFDFEV2_RESP_CHAINING                     0x71U    /**< MFDFEV2 ISO Chaining Status. */
#define PHAL_MFDFEV2_RESP_ERR_LENGTH_ERROR             0x7EU    /**< MFDFEV2 Length of command string invalid. */
#define PHAL_MFDFEV2_RESP_PERMISSION_DENIED            0x9DU    /**< MFDFEV2 Current configuration/status does not allow the requested command. */
#define PHAL_MFDFEV2_RESP_ERR_PARAMETER_ERROR          0x9EU    /**< MFDFEV2 Value of params invalid. */
#define PHAL_MFDFEV2_RESP_APPLICATION_NOT_FOUND        0xA0U    /**< MFDFEV2 Requested AID not found on PICC. */
#define PHAL_MFDFEV2_RESP_ERR_APPL_INTEGRITY_ERROR     0xA1U    /**< MFDFEV2 Unrecoverable error within application, appln will be disabled. */
#define PHAL_MFDFEV2_RESP_ERR_AUTHENTICATION_ERROR     0xAEU    /**< MFDFEV2 Current authentication status does not allow the requested cmd. */
#define PHAL_MFDFEV2_RESP_ADDITIONAL_FRAME             0xAFU    /**< MFDFEV2 Additional data frame is expected to be sent. */
#define PHAL_MFDFEV2_RESP_ERR_BOUNDARY_ERROR           0xBEU    /**< MFDFEV2 Attempt to read/write data from/to beyond the files/record's limits. */
#define PHAL_MFDFEV2_RESP_ERR_PICC_INTEGRITY           0xC1U    /**< MFDFEV2 Unrecoverable error within PICC. PICC will be disabled. */
#define PHAL_MFDFEV2_RESP_ERR_COMMAND_ABORTED          0xCAU    /**< MFDFEV2 Previous cmd not fully completed. Not all frames were requested or provided by the PCD. */
#define PHAL_MFDFEV2_RESP_ERR_PIC_DISABLED             0xCDU    /**< MFDFEV2 PICC was disabled by an unrecoverable error. */
#define PHAL_MFDFEV2_RESP_ERR_COUNT                    0xCEU    /**< MFDFEV2 Num. of applns limited to 28. No additional applications possible. */
#define PHAL_MFDFEV2_RESP_ERR_DUPLICATE                0xDEU    /**< MFDFEV2 File/Application with same number already exists. */
#define PHAL_MFDFEV2_RESP_ERR_EEPROM                   0xEEU    /**< MFDFEV2 Could not complete NV-Write operation due to loss of power. */
#define PHAL_MFDFEV2_RESP_ERR_FILE_NOT_FOUND           0xF0U    /**< MFDFEV2 Specified file number does not exist. */
#define PHAL_MFDFEV2_RESP_ERR_FILE_INTEGRITY           0xF1U    /**< MFDFEV2 Unrecoverable error within file. File will be disabled. */

/*@}*/

/**
* \name ISO 7816 Instructions
*/

/*@{*/
#define PHAL_MFDFEV2_CMD_ISO7816_SELECT_FILE       0xA4U    /**< ISO Select File. */
#define PHAL_MFDFEV2_CMD_ISO7816_READ_RECORDS      0xB2U    /**< ISO Read records. */
#define PHAL_MFDFEV2_CMD_ISO7816_READ_BINARY       0xB0U    /**< ISO Read Binary. */
#define PHAL_MFDFEV2_CMD_ISO7816_UPDATE_BINARY     0xD6U    /**< ISO UPDATE Binary. */
#define PHAL_MFDFEV2_CMD_ISO7816_APPEND_RECORD     0xE2U    /**< ISO Append record. */
#define PHAL_MFDFEV2_CMD_ISO7816_UPDATE_RECORD     0xD2U    /**< ISO Update record. */
#define PHAL_MFDFEV2_CMD_ISO7816_GET_CHALLENGE     0x84U    /**< ISO Get challenge. */
#define PHAL_MFDFEV2_CMD_ISO7816_EXT_AUTHENTICATE  0x82U    /**< ISO Ext. Authenticate. */
#define PHAL_MFDFEV2_CMD_ISO7816_INT_AUTHENTICATE  0x88U    /**< ISO Int. Authenticate. */
/*@}*/

/**
* \name MIFARE Desfire specific defines
*/

/*@{*/
#define PHAL_MFDFEV2_MAXWRAPPEDAPDU_SIZE   0x37u   /**< Maximum size of wrapped APDU 55 bytes. */
#define PHAL_MFDFEV2_MAXDFAPDU_SIZE        0x3Cu   /**< Maximum size of DESFire APDU 60 bytes. */
#define PHAL_MFDFEV2_DFAPPID_SIZE          0x03u   /**< Size of MFDFEV2 application Id. */
#define PHAL_MFDFEV2_DATA_BLOCK_SIZE       0x10u   /**< Data block size need for internal purposes. */
#define PHAL_MFDFEV2_MAX_FRAME_SIZE        0x40u   /**< Max size in a ISO 14443-4 frame. */
/*@}*/

/**
* \name ISO 7816 DFEV2 return Codes
*/
/*@{*/
#define PHAL_MFDFEV2_ISO7816_SUCCESS                        0x9000U /**< Correct execution. */
#define PHAL_MFDFEV2_ISO7816_ERR_WRONG_LENGTH               0x6700U /**< Wrong length. */
#define PHAL_MFDFEV2_ISO7816_ERR_INVALID_APPLN              0x6A82U /**< Application / file not found. */
#define PHAL_MFDFEV2_ISO7816_ERR_WRONG_PARAMS               0x6A86U /**< Wrong parameters P1 and/or P2. */
#define PHAL_MFDFEV2_ISO7816_ERR_WRONG_LC                   0x6A87U /**< Lc inconsistent with P1/p2. */
#define PHAL_MFDFEV2_ISO7816_ERR_WRONG_LE                   0x6C00U /**< Wrong Le. */
#define PHAL_MFDFEV2_ISO7816_ERR_NO_PRECISE_DIAGNOSTICS     0x6F00U /**< No precise diagnostics. */
#define PHAL_MFDFEV2_ISO7816_ERR_EOF_REACHED                0x6282U /**< End of File reached. */
#define PHAL_MFDFEV2_ISO7816_ERR_FILE_ACCESS                0x6982U /**< File access not allowed. */
#define PHAL_MFDFEV2_ISO7816_ERR_FILE_EMPTY                 0x6985U /**< File empty or access conditions not satisfied. */
#define PHAL_MFDFEV2_ISO7816_ERR_FILE_NOT_FOUND             0x6A82U /**< File not found. */
#define PHAL_MFDFEV2_ISO7816_ERR_MEMORY_FAILURE             0x6581U /**< Memory failure (unsuccessful update). */
#define PHAL_MFDFEV2_ISO7816_ERR_INCORRECT_PARAMS           0x6B00U /**< Wrong parameter p1 or p2. READ RECORDS. */
#define PHAL_MFDFEV2_ISO7816_ERR_WRONG_CLA                  0x6E00U /**< Wrong Class byte. */
#define PHAL_MFDFEV2_ISO7816_ERR_UNSUPPORTED_INS            0x6D00U /**< Instruction not supported. */
/*@}*/

#define PHAL_MFDFEV2_WRAP_HDR_LEN      0x05U   /* Wrapped APDU header length */
#define PHAL_MFDFEV2_WRAPPEDAPDU_CLA   0x90U   /* Wrapped APDU default class. */
#define PHAL_MFDFEV2_WRAPPEDAPDU_P1    0x00U   /* Wrapped APDU default P1. */
#define PHAL_MFDFEV2_WRAPPEDAPDU_P2    0x00U   /* Wrapped APDU default P2. */
#define PHAL_MFDFEV2_WRAPPEDAPDU_LE    0x00U   /* Wrapped APDU default LE. */

#define PHAL_MFDFEV2_TRUNCATED_MAC_SIZE     8u      /**< Size of the truncated MAC. */
#define PHAL_MFDFEV2_KEYSETVERSIONS         0x40U   /**< 6th bit KeyNo used to retrieve all keyset versions. */
#define PHAL_MFDFEV2_ISO_CHAINING_MODE      0x04U   /**< Option to enable ISO chaining. */
#define PHAL_MFDFEV2_DEFAULT_MODE           0x00U   /**< Native Chaining. */
#define PHAL_MFDFEV2_PC_RND_LEN             7u      /**< Size of the Proximity Check Random numbers. */
#define PHAL_MFDFEV2_SIG_LENGTH             0x38U   /**< NXP Originality Signature length */
#define PHAL_MFDFEV2_DEFAULT_UID_LENGTH     0x07U   /**< By default EV2 card is configures as 7 byte UID */
#define PHAL_MFDFEV2_10B_UID_LENGTH         0x0CU   /**< EV2 can also be configured as 10 byte UID. */
#define PHAL_MFDFEV2_4B_UID_LENGTH          0x06U   /**< EV2 can also be configured as 4 byte UID. */
#define PHAL_MFDFEV2_DEF_VERSION_LENGTH     0x1CU   /**< Version String is of 28 bytes by default(If its 7 Byte UID) */
#define PHAL_MFDFEV2_10B_VERSION_LENGTH     0x21U   /**< Version String is of 30 bytes If its 10B Byte UID */
#define PHAL_MFDFEV2_4B_VERSION_LENGTH      0x1BU   /**< Version String is of 27 bytes If its 4B Byte UID */
#define PHAL_MFDFEV2_ISO_CHAINING_MODE_MAPPED   (PHAL_MFDFEV2_ISO_CHAINING_MODE << 2U)   /**< Option to enable ISO chaining mapped for internal use. */

#define PHAL_MFDFEV2_ISO_7816_NO_LC_LE       0x00U                                /**< Check if Lc=0 and Le=0 */
#define PHAL_MFDFEV2_ISO_7816_LC_SHORT_APDU  0x01U                                /**< Indicates Lc=1 byte */
#define PHAL_MFDFEV2_ISO_7816_LC_EXT_APDU_3B 0x03U                                /**< Indicates Lc=3 bytes */
#define PHAL_MFDFEV2_ISO_7816_LE_SHORT_APDU  PHAL_MFDFEV2_ISO_7816_LC_SHORT_APDU  /**< Indicates Le=1 byte */
#define PHAL_MFDFEV2_ISO_7816_LE_EXT_APDU_2B 0x02U                                /**< Indicates Le=2 bytes */
#define PHAL_MFDFEV2_ISO_7816_LE_EXT_APDU_3B PHAL_MFDFEV2_ISO_7816_LC_EXT_APDU_3B /**< Indicates Le=3 bytes */
/**
* \name Proximity Check return Codes
*/
/*@{*/
#define PHAL_MFDFEV2_RESP_NACK0             0x00U   /*< MFDFEV2 NACK 0 (in ISO14443-3 mode). */
#define PHAL_MFDFEV2_RESP_NACK1             0x01U   /*< MFDFEV2 NACK 1 (in ISO14443-3 mode). */
#define PHAL_MFDFEV2_RESP_NACK4             0x04U   /*< MFDFEV2 NACK 4 (in ISO14443-3 mode). */
#define PHAL_MFDFEV2_RESP_NACK5             0x05U   /*< MFDFEV2 NACK 5 (in ISO14443-3 mode). */
#define PHAL_MFDFEV2_RESP_ACK_ISO3          0x0AU   /*< MFDFEV2 ACK (in ISO14443-3 mode). */
#define PHAL_MFDFEV2_RESP_ACK_ISO4          0x90U   /*< MFDFEV2 ACK (in ISO14443-4 mode). */
#define PHAL_MFDFEV2_RESP_ERR_AUTH          0x06U   /*< MFDFEV2 Authentication Error. */
#define PHAL_MFDFEV2_RESP_ERR_CMD_OVERFLOW  0x07U   /*< MFDFEV2 Command Overflow Error. */
#define PHAL_MFDFEV2_RESP_ERR_MAC_PCD       0x08U   /*< MFDFEV2 MAC Error. */
#define PHAL_MFDFEV2_RESP_ERR_BNR           0x09U   /*< MFDFEV2 Blocknumber Error. */
#define PHAL_MFDFEV2_RESP_ERR_EXT           0x0AU   /*< MFDFEV2 Extension Error. */
#define PHAL_MFDFEV2_RESP_ERR_CMD_INVALID   0x0BU   /*< MFDFEV2 Invalid Command Error. */
#define PHAL_MFDFEV2_RESP_ERR_FORMAT        0x0CU   /*< MFDFEV2 Format Error. */
#define PHAL_MFDFEV2_RESP_ERR_GEN_FAILURE   0x0FU   /*< MFDFEV2 Generic Error. */
/*@}*/

/* To avoid unused variable warnings. */
#define PHAL_MFDFEV2_UNUSED_VARIABLE(x)  {for( ( x ) = ( x ) ; ( x ) != ( x ) ; );}
#define PHAL_MFDFEV2_UNUSED_ARRAY(x)  {for( ( (x)[0] ) = ( (x)[0] ) ; ( (x)[0] ) != ( (x)[0] ) ; );}

phStatus_t phalMfdfEv2_ExchangeCmd(
                                   void * pDataParams,         /* Pointer to params data structure */
                                   void * pPalMifareDataParams,  /*  Pointer to mifare protocol layer */
                                   uint8_t bWrappedMode,
                                   uint8_t * pSendBuff,
                                   uint16_t wCmdLen,
                                   uint8_t ** ppResponse,
                                   uint16_t * pRxlen
                                   );

phStatus_t phalMfdfEv2_Int_ComputeErrorResponse(
    void * pDataParams,
    uint16_t wStatus
    );

phStatus_t phalMfdfEv2_Int_Send7816Apdu(
                                        void * pDataParams,
                                        void * pPalMifareDataParams,
                                        uint8_t bOption,
                                        uint8_t bIns,
                                        uint8_t bP1,
                                        uint8_t bP2,
                                        uint32_t bLc,
                                        uint8_t bExtendedLenApdu,
                                        uint8_t * pDataIn,  /*  Data In of Lc bytes. */
                                        uint32_t bLe,
                                        uint8_t ** ppDataOut,  /*  Data received from the card. */
                                        uint16_t *pDataLen  /*  Length of data returned. */
                                        );

phStatus_t phalMfdfEv2_Int_ISOSelectFile(
                                            void * pDataParams,
                                            void * pPalMifareDataParams,
                                            uint8_t bOption,
                                            uint8_t * bCmdBuff,
                                            uint16_t wCmdLen,
                                            uint8_t bLc,
                                            uint8_t bExtendedLenApdu,
                                            uint8_t * pDataIn,
                                            uint8_t bLe,
                                            uint8_t ** ppDataOut,
                                            uint16_t *pDataLen
                                        );

phStatus_t phalMfdfEv2_Int_ISOUpdateBinary(
                                            void * pDataParams,
                                            void * pPalMifareDataParams,
                                            uint8_t bOption,
                                            uint8_t * bCmdBuff,
                                            uint16_t wCmdLen,
                                            uint32_t dwLc,
                                            uint8_t bExtendedLenApdu,
                                            uint8_t * pDataIn,
                                            uint8_t ** ppDataOut,
                                            uint16_t *pDataLen
                                          );

phStatus_t phalMfdfEv2_Int_ISOAppendRecord(
                                            void * pDataParams,
                                            void * pPalMifareDataParams,
                                            uint8_t bOption,
                                            uint8_t * bCmdBuff,
                                            uint16_t wCmdLen,
                                            uint32_t dwLc,
                                            uint8_t bExtendedLenApdu,
                                            uint8_t * pDataIn,
                                            uint8_t ** ppDataOut,
                                            uint16_t *pDataLen
                                         );

phStatus_t phalMfdfEv2_Int_ISOGetChallenge(
                                            void * pDataParams,
                                            void * pPalMifareDataParams,
                                            uint8_t bOption,
                                            uint8_t * bCmdBuff,
                                            uint16_t wCmdLen,
                                            uint8_t bLe,
                                            uint8_t bExtendedLenApdu,
                                            uint8_t ** ppDataOut,
                                            uint16_t *pDataLen
                                        );

phStatus_t phalMfdfEv2_Int_ISOExternalAuthenticate(
                                                    void * pDataParams,
                                                    void * pPalMifareDataParams,
                                                    uint8_t bOption,
                                                    uint8_t * bCmdBuff,
                                                    uint16_t wCmdLen,
                                                    uint8_t bLc,
                                                    uint8_t bExtendedLenApdu,
                                                    uint8_t * pDataIn,
                                                    uint8_t ** ppDataOut,
                                                    uint16_t *pDataLen
                                                 );

phStatus_t phalMfdfEv2_Int_ISOInternalAuthenticate(
                                                    void * pDataParams,
                                                    void * pPalMifareDataParams,
                                                    uint8_t bOption,
                                                    uint8_t * bCmdBuff,
                                                    uint16_t wCmdLen,
                                                    uint8_t bLc,
                                                    uint8_t bExtendedLenApdu,
                                                    uint8_t * pDataIn,
                                                    uint32_t dwLe,
                                                    uint8_t ** ppDataOut,
                                                    uint16_t *pDataLen
                                                );
/*@}*/

#endif /* PHALMFDFEV2_INT_H */
