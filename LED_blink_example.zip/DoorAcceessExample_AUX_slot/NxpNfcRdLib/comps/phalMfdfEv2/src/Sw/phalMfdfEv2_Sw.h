/*
* Copyright (c), NXP Semiconductors Bangalore / India
*
* (C)NXP Semiconductors
* All rights are reserved. Reproduction in whole or in part is
* prohibited without the written consent of the copyright owner.
* NXP reserves the right to make changes without notice at any time.
* NXP makes no warranty, expressed, implied or statutory, including but
* not limited to any implied warranty of merchantability or fitness for any
* particular purpose, or that the use will not infringe any third party patent,
* copyright or trademark. NXP must not be liable for any loss or damage
* arising from its use.
*/

#ifndef PHALMFDFEV2_SW_H
#define PHALMFDFEV2_SW_H

/*
*  Authenticate
*/
phStatus_t phalMfdfEv2_Sw_Authenticate(
                                       phalMfdfEv2_Sw_DataParams_t * pDataParams,
                                       uint16_t wOption,
                                       uint16_t wKeyNo,
                                       uint16_t wKeyVer,
                                       uint8_t bKeyNoCard,
                                       uint8_t * pDivInput,
                                       uint8_t bDivLen
                                       );

/*
*  AuthenticateISO
*/
phStatus_t phalMfdfEv2_Sw_AuthenticateISO(
    phalMfdfEv2_Sw_DataParams_t * pDataParams,
    uint16_t wOption,
    uint16_t wKeyNo,
    uint16_t wKeyVer,
    uint8_t bKeyNoCard,
    uint8_t * pDivInput,
    uint8_t bDivLen
    );

/*
*  Authenticate AES
*/
phStatus_t phalMfdfEv2_Sw_AuthenticateAES(
    phalMfdfEv2_Sw_DataParams_t * pDataParams,
    uint16_t wOption,
    uint16_t wKeyNo,
    uint16_t wKeyVer,
    uint8_t bKeyNoCard,
    uint8_t * pDivInput,
    uint8_t bDivLen
    );

/*
* Authenticate Ev2
*/
phStatus_t phalMfdfEv2_Sw_AuthenticateEv2(
    phalMfdfEv2_Sw_DataParams_t * pDataParams,
    uint8_t bFirstAuth,
    uint16_t wOption,
    uint16_t wKeyNo,
    uint16_t wKeyVer,
    uint8_t bKeyNoCard,
    uint8_t * pDivInput,
    uint8_t bDivLen,
    uint8_t bLenPcdCapsIn,
    uint8_t *pPcdCapsIn,
    uint8_t *pPcdCapsOut,
    uint8_t *pPdCapsOut
    );
/*
*  ChangeKeySettings
*/
phStatus_t phalMfdfEv2_Sw_ChangeKeySettings(
    phalMfdfEv2_Sw_DataParams_t * pDataParams,
    uint8_t bKeySettings
    );

/*
*  GetKeySettings
*/
phStatus_t phalMfdfEv2_Sw_GetKeySettings(
    phalMfdfEv2_Sw_DataParams_t * pDataParams,
    uint8_t * pKeySettings,
    uint8_t * bRespLen
    );

/*
*  ChangeKey
*/
phStatus_t phalMfdfEv2_Sw_ChangeKey(
                                    phalMfdfEv2_Sw_DataParams_t * pDataParams,
                                    uint16_t wOption,
                                    uint16_t wOldKeyNo,
                                    uint16_t wOldKeyVer,
                                    uint16_t wNewKeyNo,
                                    uint16_t wNewKeyVer,
                                    uint8_t bKeyNoCard,
                                    uint8_t * pDivInput,
                                    uint8_t bDivLen
                                    );

/*
* ChangeKeyEv2
*/
phStatus_t phalMfdfEv2_Sw_ChangeKeyEv2(
                                       phalMfdfEv2_Sw_DataParams_t * pDataParams,
                                       uint16_t wOption,
                                       uint16_t wOldKeyNo,
                                       uint16_t wOldKeyVer,
                                       uint16_t wNewKeyNo,
                                       uint16_t wNewKeyVer,
                                       uint8_t bKeySetNo,
                                       uint8_t bKeyNoCard,
                                       uint8_t * pDivInput,
                                       uint8_t bDivLen
                                       );

/*
*  GetKeyVersion
*/
phStatus_t phalMfdfEv2_Sw_GetKeyVersion(
                                        phalMfdfEv2_Sw_DataParams_t * pDataParams,
                                        uint8_t bKeyNo,
                                        uint8_t bKeySetNo,
                                        uint8_t * pKeyVersion,
                                        uint8_t * bRxLen
                                        );

/*
* InitializeKeySet
*/
phStatus_t phalMfdfEv2_Sw_InitializeKeySet(
    phalMfdfEv2_Sw_DataParams_t * pDataParams,
    uint8_t bKeySetNo,
    uint8_t bKeyType
    );

/*
* FinalizeKeySet
*/
phStatus_t phalMfdfEv2_Sw_FinalizeKeySet(
    phalMfdfEv2_Sw_DataParams_t * pDataParams,
    uint8_t bKeySetNo,
    uint8_t bKeySetVersion
    );

/*
* RollKeySet
*/
phStatus_t phalMfdfEv2_Sw_RollKeySet(
                                     phalMfdfEv2_Sw_DataParams_t * pDataParams,
                                     uint8_t bKeySetNo
                                     );

/*
*  CreateApplication
*/
phStatus_t phalMfdfEv2_Sw_CreateApplication(
    phalMfdfEv2_Sw_DataParams_t * pDataParams,
    uint8_t bOption,
    uint8_t * pAid,
    uint8_t bKeySettings1,
    uint8_t bKeySettings2,
    uint8_t bKeySettings3,
    uint8_t * pKeySetValues,
    uint8_t * pISOFileId,
    uint8_t * pISODFName,
    uint8_t bISODFNameLen
    );

/*
* CreateDelegated application
*/
phStatus_t phalMfdfEv2_Sw_CreateDelegatedApplication(
    phalMfdfEv2_Sw_DataParams_t * pDataParams,
    uint8_t bOption,
    uint8_t * pAid,
    uint8_t * pDamParams,
    uint8_t bKeySettings1,
    uint8_t bKeySettings2,
    uint8_t bKeySettings3,
    uint8_t * bKeySetValues,
    uint8_t * pISOFileId,
    uint8_t * pISODFName,
    uint8_t bISODFNameLen,
    uint8_t * pEncK,
    uint8_t * pDAMMAC
    );

/*
*  DeleteApplication
*/
phStatus_t phalMfdfEv2_Sw_DeleteApplication(
    phalMfdfEv2_Sw_DataParams_t * pDataParams,
    uint8_t * pAid
    );

/*
*  GetApplicationIDs
*/
phStatus_t phalMfdfEv2_Sw_GetApplicationIDs(
    phalMfdfEv2_Sw_DataParams_t * pDataParams,
    uint8_t bOption,
    uint8_t ** pAidBuff,
    uint8_t * pNumAIDs
    );

/*
*  phalMfdfEv2_Sw_GetDFNames
*/
phStatus_t phalMfdfEv2_Sw_GetDFNames(
                                     phalMfdfEv2_Sw_DataParams_t * pDataParams,
                                     uint8_t bOption,
                                     uint8_t * pDFBuffer,
                                     uint8_t * pDFInfoLen
                                     );

/*
* GetDelegatedInfo
*/
phStatus_t phalMfdfEv2_Sw_GetDelegatedInfo(
    phalMfdfEv2_Sw_DataParams_t * pDataParams,
    uint8_t * pDAMSlot,
    uint8_t * pDamSlotVer,
    uint8_t * pQuotaLimit,
    uint8_t * pFreeBlocks,
    uint8_t * pAid
    );

/*
*  SelectApplication
*/
phStatus_t phalMfdfEv2_Sw_SelectApplication(
    phalMfdfEv2_Sw_DataParams_t * pDataParams,
    uint8_t bOption,
    uint8_t * pAppId,
    uint8_t * pAppId2
    );

/*
*  FormatPICC
*/
phStatus_t phalMfdfEv2_Sw_Format(
                                 phalMfdfEv2_Sw_DataParams_t * pDataParams
                                 );

/*
*  GetVersion
*/
phStatus_t phalMfdfEv2_Sw_GetVersion(
                                     phalMfdfEv2_Sw_DataParams_t * pDataParams,
                                     uint8_t * pVerInfo
                                     );

/*
*  Free Memory
*/
phStatus_t phalMfdfEv2_Sw_FreeMem(
                                  phalMfdfEv2_Sw_DataParams_t * pDataParams,
                                  uint8_t * pMemInfo
                                  );

/*
*  Set Configuration
*/
phStatus_t phalMfdfEv2_Sw_SetConfiguration(
    phalMfdfEv2_Sw_DataParams_t * pDataParams,
    uint8_t bOption,
    uint8_t * pData,
    uint8_t bDataLen
    );

/*
*  GetCardUID
*/
phStatus_t phalMfdfEv2_Sw_GetCardUID(
                                     phalMfdfEv2_Sw_DataParams_t * pDataParams,
                                     uint8_t * pUid,
                                     uint8_t * pUidLength
                                     );

/*
*  GetFileIDs
*/
phStatus_t phalMfdfEv2_Sw_GetFileIDs(
                                     phalMfdfEv2_Sw_DataParams_t * pDataParams,
                                     uint8_t * pFid,
                                     uint8_t * bNumFID
                                     );

/*
*  GetISOFileIDs
*/
phStatus_t phalMfdfEv2_Sw_GetISOFileIDs(
                                        phalMfdfEv2_Sw_DataParams_t * pDataParams,
                                        uint8_t * pFidBuffer,
                                        uint8_t * pNumFID
                                        );

/*
*  GetFileSettings
*/
phStatus_t phalMfdfEv2_Sw_GetFileSettings(
    phalMfdfEv2_Sw_DataParams_t * pDataParams,
    uint8_t bFileNo,
    uint8_t * pFSBuffer,
    uint8_t * pBufferLen
    );


/*
*  ChangeFileSettings
*/
phStatus_t phalMfdfEv2_Sw_ChangeFileSettings(
    phalMfdfEv2_Sw_DataParams_t * pDataParams,
    uint8_t bOption,
    uint8_t bFileNo,
    uint8_t bCommSett,
    uint8_t * pAccessRights,
    uint8_t bNumAddARs,
    uint8_t * pAddARs
    );

/*
*
*  CreateStdDataFile
*/
phStatus_t phalMfdfEv2_Sw_CreateStdDataFile(
    phalMfdfEv2_Sw_DataParams_t * pDataParams,
    uint8_t bOption,
    uint8_t bFileNo,
    uint8_t * pISOFileId,
    uint8_t bFileOption,
    uint8_t * pAccessRights,
    uint8_t * pFileSize
    );

/*
*  CreateBackupDataFile
*/
phStatus_t phalMfdfEv2_Sw_CreateBackupDataFile(
    phalMfdfEv2_Sw_DataParams_t * pDataParams,
    uint8_t bOption,
    uint8_t bFileNo,
    uint8_t * pISOFileId,
    uint8_t bFileOption,
    uint8_t * pAccessRights,
    uint8_t * pFileSize
    );

/*
*  CreateValueFile
*/
phStatus_t phalMfdfEv2_Sw_CreateValueFile(
    phalMfdfEv2_Sw_DataParams_t * pDataParams,
    uint8_t bFileNo,
    uint8_t bCommSett,
    uint8_t * pAccessRights,
    uint8_t * pLowerLmit,
    uint8_t * pUpperLmit,
    uint8_t * pValue,
    uint8_t bLimitedCredit
    );
/*
*
*  CreateLinearRecFile
*/
phStatus_t phalMfdfEv2_Sw_CreateLinearRecordFile(
    phalMfdfEv2_Sw_DataParams_t * pDataParams,
    uint8_t bOption,
    uint8_t  bFileNo,
    uint8_t  *pIsoFileId,
    uint8_t bCommSett,
    uint8_t * pAccessRights,
    uint8_t * pRecordSize,
    uint8_t * pMaxNoOfRec
    );

/*
*  CreateCyclicRecFile
*/
phStatus_t phalMfdfEv2_Sw_CreateCyclicRecordFile(
    phalMfdfEv2_Sw_DataParams_t * pDataParams,
    uint8_t bOption,
    uint8_t  bFileNo,
    uint8_t  *pIsoFileId,
    uint8_t bCommSett,
    uint8_t * pAccessRights,
    uint8_t * pRecordSize,
    uint8_t * pMaxNoOfRec
    );

/*
* CreateTransactionMACFile
*/
phStatus_t phalMfdfEv2_Sw_CreateTransactionMacFile(
    phalMfdfEv2_Sw_DataParams_t * pDataParams,
    uint8_t bFileNo,
    uint8_t bCommSett,
    uint8_t * pAccessRights,
    uint8_t bKeyType,
    uint8_t * bTMKey,
    uint8_t bTMKeyVer
    );

/*
*  DeleteFile
*
*/
phStatus_t phalMfdfEv2_Sw_DeleteFile(
                                     phalMfdfEv2_Sw_DataParams_t * pDataParams,
                                     uint8_t bFileNo
                                     );

/*
*  readdata
*/
phStatus_t phalMfdfEv2_Sw_ReadData(
                                   phalMfdfEv2_Sw_DataParams_t * pDataParams,
                                   uint8_t bOption,
                                   uint8_t bIns,
                                   uint8_t bFileNo,
                                   uint8_t * pOffset,
                                   uint8_t * pLength,
                                   uint8_t ** ppRxdata,
                                   uint16_t * pRxdataLen
                                   );

/*
*  WriteData
*/
phStatus_t phalMfdfEv2_Sw_WriteData(
                                    phalMfdfEv2_Sw_DataParams_t * pDataParams,
                                    uint8_t bCommOption,
                                    uint8_t bIns,
                                    uint8_t bFileNo,
                                    uint8_t * pOffset,
                                    uint8_t * pData,
                                    uint8_t * pDataLen
                                    );

/*
*  GetValue
*/
phStatus_t phalMfdfEv2_Sw_GetValue(
                                   phalMfdfEv2_Sw_DataParams_t * pDataParams,
                                   uint8_t bCommOption,
                                   uint8_t bFileNo,
                                   uint8_t * pValue
                                   );

/*
*  Credit
*/
phStatus_t phalMfdfEv2_Sw_Credit(
                                 phalMfdfEv2_Sw_DataParams_t * pDataParams,
                                 uint8_t bCommOption,
                                 uint8_t bFileNo,
                                 uint8_t * pValue
                                 );

/*
*  debit
*/
phStatus_t phalMfdfEv2_Sw_Debit(
                                phalMfdfEv2_Sw_DataParams_t * pDataParams,
                                uint8_t bCommOption,
                                uint8_t bFileNo,
                                uint8_t * pValue
                                );


/*
*  LimitedCredit
*/
phStatus_t phalMfdfEv2_Sw_LimitedCredit(
                                        phalMfdfEv2_Sw_DataParams_t * pDataParams,
                                        uint8_t bCommOption,
                                        uint8_t bFileNo,
                                        uint8_t * pValue
                                        );


/*
*  WriteRecord
*/
phStatus_t phalMfdfEv2_Sw_WriteRecord(
                                      phalMfdfEv2_Sw_DataParams_t * pDataParams,
                                      uint8_t bCommOption,
                                      uint8_t bIns,
                                      uint8_t bFileNo,
                                      uint8_t * pOffset,
                                      uint8_t * pData,
                                      uint8_t * pDataLen
                                      );

/*
*  ReadRecords
*/
phStatus_t phalMfdfEv2_Sw_ReadRecords(
                                      phalMfdfEv2_Sw_DataParams_t * pDataParams,
                                      uint8_t bCommOption,
                                      uint8_t bIns,
                                      uint8_t bFileNo,
                                      uint8_t * pRecNo,
                                      uint8_t * pRecCount,
                                      uint8_t * pRecSize,
                                      uint8_t ** ppRxdata,
                                      uint16_t * pRxdataLen
                                      );

/*
* UpdateRecords
*/
phStatus_t phalMfdfEv2_Sw_UpdateRecord(
                                       phalMfdfEv2_Sw_DataParams_t * pDataParams,
                                       uint8_t bCommOption,
                                       uint8_t bIns,
                                       uint8_t bFileNo,
                                       uint8_t * pRecNo,
                                       uint8_t * pOffset,
                                       uint8_t * pData,
                                       uint8_t * pDataLen
                                       );
/*
*  ClearRecordFile
*/
phStatus_t phalMfdfEv2_Sw_ClearRecordFile(
    phalMfdfEv2_Sw_DataParams_t * pDataParams,
    uint8_t bFileNo
    );

/*
* CommitReaderID
*/
phStatus_t phalMfdfEv2_Sw_CommitReaderID(
    phalMfdfEv2_Sw_DataParams_t * pDataParams,
    uint8_t * pTMRI,
    uint8_t * pEncTMRI
    );

/*
*  CommitTransaction
*/
phStatus_t phalMfdfEv2_Sw_CommitTransaction(
    phalMfdfEv2_Sw_DataParams_t * pDataParams,
    uint8_t bOption,
    uint8_t * pTMC,
    uint8_t * pTMAC
    );

/*
*  AbortTransaction
*/
phStatus_t phalMfdfEv2_Sw_AbortTransaction(
    phalMfdfEv2_Sw_DataParams_t * pDataParams
    );

/*
*  ISO Select
*/
phStatus_t phalMfdfEv2_Sw_IsoSelectFile(
                                        phalMfdfEv2_Sw_DataParams_t * pDataParams,
                                        uint8_t bOption,
                                        uint8_t bSelector,
                                        uint8_t * pFid,
                                        uint8_t * pDFname,
                                        uint8_t bDFnameLen,
                                        uint8_t bExtendedLenApdu,
                                        uint8_t ** ppFCI,
                                        uint16_t * pwFCILen
                                        );

/*
*  ISO Read Binary
*/
phStatus_t phalMfdfEv2_Sw_IsoReadBinary(
                                        phalMfdfEv2_Sw_DataParams_t * pDataParams,
                                        uint16_t wOption,
                                        uint8_t bOffset,
                                        uint8_t bSfid,
                                        uint32_t dwBytesToRead,
                                        uint8_t bExtendedLenApdu,
                                        uint8_t ** ppRxBuffer,
                                        uint32_t * pBytesRead
                                        );

/*
*  ISO Update Binary
*/
phStatus_t phalMfdfEv2_Sw_IsoUpdateBinary(
    phalMfdfEv2_Sw_DataParams_t * pDataParams,
    uint8_t bOffset,
    uint8_t bSfid,
    uint8_t bExtendedLenApdu,
    uint8_t * pData,
    uint32_t dwDataLen
    );

/*
*  Read Records
*/
phStatus_t phalMfdfEv2_Sw_IsoReadRecords(
    phalMfdfEv2_Sw_DataParams_t * pDataParams,
    uint16_t wOption,
    uint8_t bRecNo,
    uint8_t bReadAllFromP1,
    uint8_t bSfid,
    uint32_t dwBytesToRead,
    uint8_t bExtendedLenApdu,
    uint8_t ** ppRxBuffer,
    uint32_t * pBytesRead
    );

/*
*  ISO Append Record
*/
phStatus_t phalMfdfEv2_Sw_IsoAppendRecord(
    phalMfdfEv2_Sw_DataParams_t * pDataParams,
    uint8_t bSfid,
    uint8_t bExtendedLenApdu,
    uint8_t * pData,
    uint32_t dwDataLen
    );

/*
* ISO Update Record
*/
phStatus_t phalMfdfEv2_Sw_IsoUpdateRecord(
    phalMfdfEv2_Sw_DataParams_t * pDataParams,
    uint8_t bIns,
    uint8_t bRecNo,
    uint8_t bSfid,
    uint8_t bRefCtrl,
    uint8_t * pData,
    uint8_t bDataLen
    );

/*
*  GetChallenge
*/
phStatus_t phalMfdfEv2_Sw_IsoGetChallenge(
    phalMfdfEv2_Sw_DataParams_t * pDataParams,
    uint16_t wKeyNo,
    uint16_t wKeyVer,
    uint8_t bExtendedLenApdu,
    uint32_t dwLe,
    uint8_t * pRPICC1
    );

/*
*  ISO External Authenticate
*/
phStatus_t phalMfdfEv2_Sw_IsoExternalAuthenticate(
    phalMfdfEv2_Sw_DataParams_t * pDataParams,
    uint8_t * pInput,
    uint8_t bInputLen,
    uint8_t bExtendedLenApdu,
    uint8_t * pDataOut,
    uint8_t * pOutLen
    );

/*
*  ISO Internal Authenticate
*/
phStatus_t phalMfdfEv2_Sw_IsoInternalAuthenticate(
    phalMfdfEv2_Sw_DataParams_t * pDataParams,
    uint8_t * pInput,
    uint8_t bInputLen,
    uint8_t bExtendedLenApdu,
    uint8_t * pDataOut,
    uint8_t * pOutLen
    );

/*
*  Perform ISO authentication
*/
phStatus_t phalMfdfEv2_Sw_IsoAuthenticate(
    phalMfdfEv2_Sw_DataParams_t * pDataParams,
    uint16_t wKeyNo,
    uint16_t wKeyVer,
    uint8_t bKeyNoCard,
    uint8_t bIsPICCkey
    );

/*
* Get config
*/

phStatus_t phalMfdfEv2_Sw_GetConfig(
                                    phalMfdfEv2_Sw_DataParams_t * pDataParams,
                                    uint16_t wConfig,
                                    uint16_t * pValue
                                    );

/*
* Set config
*/
phStatus_t phalMfdfEv2_Sw_SetConfig(
                                    phalMfdfEv2_Sw_DataParams_t *pDataParams,
                                    uint16_t wConfig,
                                    uint16_t wValue
                                    );

/*
* Reset Authentication
*/
phStatus_t phalMfdfEv2_Sw_ResetAuthentication(
    phalMfdfEv2_Sw_DataParams_t * pDataParams
    );

/*
* GenerateDAMEncKey
*/
phStatus_t phalMfdfEv2_Sw_GenerateDAMEncKey(
    phalMfdfEv2_Sw_DataParams_t * pDataParams,
    uint16_t wKeyNoDAMEnc,
    uint16_t wKeyVerDAMEnc,
    uint16_t wKeyNoAppDAMDefault,
    uint16_t wKeyVerAppDAMDefault,
    uint8_t bAppDAMDefaultKeyVer,
    uint8_t * pDAMEncKey
    );

/*
* Generate DAMMAC
*/
phStatus_t phalMfdfEv2_Sw_GenerateDAMMAC(
    phalMfdfEv2_Sw_DataParams_t * pDataParams,
    uint8_t bOption,
    uint16_t wKeyNoDAMMAC,
    uint16_t wKeyVerDAMMAC,
    uint8_t * pAid,
    uint8_t * pDamParams,
    uint8_t bKeySettings1,
    uint8_t bKeySettings2,
    uint8_t bKeySettings3,
    uint8_t * pKeySetValues,
    uint8_t * pISOFileId,
    uint8_t * pISODFName,
    uint8_t bISODFNameLen,
    uint8_t * pEncK,
    uint8_t * pDAMMAC
    );

/*
* Generates DAMMAC for Set Configuration with option 0x06 for Delegated Application
*/
phStatus_t phalMfdfEv2_Sw_GenerateDAMMACSetConfig(
    phalMfdfEv2_Sw_DataParams_t * pDataParams,      /* [In] Pointer to parameters data structure */
    uint16_t wKeyNoDAMMAC,                          /* [In] Key number in key store of DAM MAC Key */
    uint16_t wKeyVerDAMMAC,                         /* [In] Key version in key store of DAM MAC Key*/
    uint16_t wOldDFNameLen,                         /* [In] Length of existing DF Name */
    uint8_t * pOldISODFName,                        /* [In] This means already created delegated app ISO DF Name. Maximum 16 bytes */
    uint16_t wNewDFNameLen,                         /* [In] Length of new DF Name */
    uint8_t * pNewISODFName,                        /* [In] This means new delegated app ISO DF Name which will replace the existing one. Maximum 16 bytes */
    uint8_t * pDAMMAC                               /* [Out] generated 8 bytes DAM MAC for setconfig option 0x06 */
    );

/*
* Calculate TMV
*/
phStatus_t phalMfdfEv2_Sw_CalculateTMV(
                                       phalMfdfEv2_Sw_DataParams_t *pDataParams,
                                       uint16_t wOption,
                                       uint16_t wKeyNoTMACKey,
                                       uint16_t wKeyVerTMACKey,
                                       uint8_t * pDivInput,
                                       uint8_t bDivInputLen,
                                       uint8_t * pTMC,
                                       uint8_t * pUid,
                                       uint8_t bUidLen,
                                       uint8_t * pTMI,
                                       uint32_t dwTMILen,
                                       uint8_t * pTMV
                                       );

/*
* Decrypt Reader ID
*/
phStatus_t phalMfdfEv2_Sw_DecryptReaderID(
    phalMfdfEv2_Sw_DataParams_t *pDataParams,
    uint16_t wOption,
    uint16_t wKeyNoTMACKey,
    uint16_t wKeyVerTMACKey,
    uint8_t * pDivInput,
    uint8_t bDivInputLen,
    uint8_t * pTMC,
    uint8_t * pUid,
    uint8_t bUidLen,
    uint8_t * pEncTMRI,
    uint8_t * pTMRIPrev
    );

/*
* Activate TMI Collection
*/
phStatus_t phalMfdfEv2_Sw_ActivateTMICollection(
    phalMfdfEv2_Sw_DataParams_t *pDataParams,
    uint8_t bOption,
    uint8_t * pTMIBuffer,
    uint16_t wBufLen
    );

/*
* Get TMI
*/
phStatus_t phalMfdfEv2_Sw_GetTMI(
                                 phalMfdfEv2_Sw_DataParams_t * pDataParams,
                                 uint8_t ** ppTMIBuffer,
                                 uint16_t * wTMILen
                                 );

phStatus_t phalMfdfEv2_Sw_ReadSign(
                                phalMfdfEv2_Sw_DataParams_t * pDataParams,
                                uint8_t bAddr,
                                uint8_t ** pSignature
                                );

phStatus_t phalMfdfEv2_Sw_SetVCAParams(
                               phalMfdfEv2_Sw_DataParams_t * pDataParams,
                               void * pAlVCADataParams
                               );

#endif /* PHALMFDFEV2_SW_H */
