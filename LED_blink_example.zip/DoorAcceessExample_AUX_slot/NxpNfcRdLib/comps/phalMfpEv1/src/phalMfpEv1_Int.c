/*
*         Copyright (c), NXP Semiconductors Gratkorn / Austria
*
*                     (C)NXP Semiconductors
*       All rights are reserved. Reproduction in whole or in part is
*      prohibited without the written consent of the copyright owner.
*  NXP reserves the right to make changes without notice at any time.
* NXP makes no warranty, expressed, implied or statutory, including but
* not limited to any implied warranty of merchantability or fitness for any
*particular purpose, or that the use will not infringe any third party patent,
* copyright or trademark. NXP must not be liable for any loss or damage
*                          arising from its use.
*/

/** \file
* Generic MIFARE Plus(R) Application Component of Reader Library Framework.
* $Author: NXP99556 $
* $Revision: 1858 $ (v05.07.00)
* $Date: 2016-06-09 17:56:07 +0530 (Thu, 09 Jun 2016) $
*
* History:
*  Kumar GVS: Generated 15. Apr 2013
*
*/

#include <ph_Status.h>
#include <phpalMifare.h>
#include <phalMfpEv1.h>
#include "phalMfpEv1_Int.h"
#include <ph_RefDefs.h>

#ifdef NXPBUILD__PHAL_MFPEV1

phStatus_t phalMfpEv1_Int_ComputeErrorResponse(
    uint16_t wNumBytesReceived,
    uint16_t wStatus,
    uint8_t bLayer4Comm
    )
{
    phStatus_t  PH_MEMLOC_REM status;

    /* Invalid error response */
    if (wNumBytesReceived == 0U)
    {
        return PH_ADD_COMPCODE_FIXED(PH_ERR_PROTOCOL_ERROR, PH_COMP_AL_MFPEV1);
    }

    /* validate received response */
    if (wNumBytesReceived == 1U)
    {
        if (0U != (bLayer4Comm))
        {
            switch (wStatus)
            {
            case PHAL_MFPEV1_RESP_ACK_ISO4:
            case PHAL_MFPEV1_ISO7816_RESP_SUCCESS:
                status = PH_ERR_SUCCESS;
                break;

            case PHAL_MFPEV1_RESP_ERR_AUTH:

                status = PHAL_MFPEV1_ERR_AUTH;
                break;

            case PHAL_MFPEV1_RESP_ERR_CMD_OVERFLOW:

                status = PHAL_MFPEV1_ERR_CMD_OVERFLOW;
                break;

            case PHAL_MFPEV1_RESP_ERR_MAC_PCD:

                status = PHAL_MFPEV1_ERR_MAC_PCD;
                break;

            case PHAL_MFPEV1_RESP_ERR_BNR:

                status = PHAL_MFPEV1_ERR_BNR;
                break;

            case PHAL_MFPEV1_RESP_ERR_CMD_INVALID:

                status = PHAL_MFPEV1_ERR_CMD_INVALID;
                break;

            case PHAL_MFPEV1_RESP_ERR_FORMAT:

                status = PHAL_MFPEV1_ERR_FORMAT;
                break;

            case PHAL_MFPEV1_RESP_ERR_GEN_FAILURE:

                status = PHAL_MFPEV1_ERR_GEN_FAILURE;
                break;

            case PHAL_MFPEV1_RESP_ERR_EXT:
                status = PHAL_MFPEV1_ERR_EXT;
                break;

            case PHAL_MFPEV1_RESP_ERR_TM:

                status = PHAL_MFPEV1_ERR_TM;
                break;

            case PHAL_MFPEV1_RESP_ERR_NOT_SUP:

                status = PHAL_MFPEV1_ERR_NOT_SUP;
                break;

            case PHAL_MFPEV1_ISO7816_RESP_ERR_WRONG_LENGTH:
                status = PHAL_MFPEV1_ISO7816_ERR_WRONG_LENGTH;
                break;

            case PHAL_MFPEV1_ISO7816_RESP_ERR_WRONG_PARAMS:
                status = PHAL_MFPEV1_ISO7816_ERR_WRONG_LENGTH;
                break;

            case PHAL_MFPEV1_ISO7816_RESP_ERR_WRONG_LC:
                status = PHAL_MFPEV1_ISO7816_ERR_WRONG_LC;
                break;

            case PHAL_MFPEV1_ISO7816_RESP_ERR_WRONG_LE:
                status = PHAL_MFPEV1_ISO7816_ERR_WRONG_LE;
                break;

            case PHAL_MFPEV1_ISO7816_RESP_ERR_WRONG_CLA:
                status = PHAL_MFPEV1_ISO7816_ERR_WRONG_CLA;
                break;

            default:

                status = PH_ERR_PROTOCOL_ERROR;
                break;
            }

            return PH_ADD_COMPCODE(status, PH_COMP_AL_MFPEV1);
        }
        else
        {
            switch(wStatus)
            {
            case PHAL_MFPEV1_RESP_ACK_ISO3:
            case PHAL_MFPEV1_RESP_ACK_ISO4:
                status = PH_ERR_SUCCESS;
                break;
                /* Mapping of NAK codes: */
            case PHAL_MFPEV1_RESP_NACK0:
                status =  PHPAL_MIFARE_ERR_NAK0;
                break;
            case PHAL_MFPEV1_RESP_NACK1:
                status =  PHPAL_MIFARE_ERR_NAK1;
                break;
            case PHAL_MFPEV1_RESP_NACK4:
                status =  PHPAL_MIFARE_ERR_NAK4;
                break;
            case PHAL_MFPEV1_RESP_NACK5:
                status =  PHPAL_MIFARE_ERR_NAK5;
                break;
            default:
                status  = PH_ERR_PROTOCOL_ERROR;
                break;
            }

            return PH_ADD_COMPCODE(status, PH_COMP_PAL_MIFARE); /* For compatibility reasons with SW stack we use here PAL MIFARE */
        }

    }

    /* validate received response with wNumBytesReceived > 1 */
    if (wStatus != PHAL_MFPEV1_RESP_ACK_ISO4)
    {
        return PH_ADD_COMPCODE_FIXED(PH_ERR_PROTOCOL_ERROR, PH_COMP_AL_MFPEV1);
    }

    /* proper error response */
    return PH_ERR_SUCCESS;
}

phStatus_t phalMfpEv1_Int_ComputeErrorResponseMfc(
    uint16_t wNumBytesReceived,
    uint8_t bStatus
    )
{
    phStatus_t  PH_MEMLOC_REM status;

    /* Validate received response */
    if (wNumBytesReceived == 1U)
    {
        switch(bStatus)
        {
            case PHAL_MFPEV1_RESP_ACK_ISO3:
                status = PH_ERR_SUCCESS;
                break;

                /* Mapping of NAK codes: */
            case PHAL_MFPEV1_RESP_NACK0:
                status =  PHPAL_MIFARE_ERR_NAK0;
                break;

            case PHAL_MFPEV1_RESP_NACK1:
                status =  PHPAL_MIFARE_ERR_NAK1;
                break;

            case PHAL_MFPEV1_RESP_NACK4:
                status =  PHPAL_MIFARE_ERR_NAK4;
                break;

            case PHAL_MFPEV1_RESP_NACK5:
                status =  PHPAL_MIFARE_ERR_NAK5;
                break;

            default:
                status  = PH_ERR_PROTOCOL_ERROR;
                break;
        }

        return PH_ADD_COMPCODE(status, PH_COMP_PAL_MIFARE);
    }

    /* Proper error response */
    return PH_ERR_SUCCESS;
}

#ifdef NXPBUILD__PHAL_MFPEV1_SW
phStatus_t phalMfpEv1_Int_WritePerso(
                                  phalMfpEv1_Sw_DataParams_t * pDataParams,
                                  uint8_t bLayer4Comm,
                                  uint16_t wBlockNr,
                                  uint8_t bNumBlocks,
                                  uint8_t * pValue
                                  )
{
    phStatus_t  PH_MEMLOC_REM statusTmp;
    uint8_t     PH_MEMLOC_REM aCmd[3];
    uint16_t    PH_MEMLOC_REM wCmdlen = 0;
    uint8_t *   PH_MEMLOC_REM pResponse = NULL;
    uint16_t    PH_MEMLOC_REM wRxLength = 0;

    /* parameter checking */
    if (pValue == NULL)
    {
        return PH_ADD_COMPCODE_FIXED(PH_ERR_INVALID_PARAMETER, PH_COMP_AL_MFPEV1);
    }

    /* command frame */
    aCmd[wCmdlen++] = PHAL_MFPEV1_CMD_WRITEPERSO;
    aCmd[wCmdlen++] = (uint8_t)(wBlockNr & 0xFFU); /* LSB */
    aCmd[wCmdlen++] = (uint8_t)(wBlockNr >> 8U);   /* MSB */

    /* exchange command/response */
    if (0U != (bLayer4Comm))
    {
        /* Check if ISO 7816-4 wapping is required */
        if(0U != (pDataParams->bWrappedMode))
        {
            /* command header */
            PH_CHECK_SUCCESS_FCT(statusTmp, phalMfpEv1_Int_Send7816Apdu(
                pDataParams->pPalMifareDataParams,
                PH_EXCHANGE_BUFFER_FIRST,
                ((wCmdlen - 1 /* Excluding the command code */) + (bNumBlocks * PHAL_MFPEV1_DATA_BLOCK_SIZE)),
                pDataParams->bExtendedLenApdu,
                aCmd,
                wCmdlen,     /* Command code is included as part of length. */
                NULL,
                NULL));

            /* Exchange the command. */
            PH_CHECK_SUCCESS_FCT(statusTmp, phalMfpEv1_Int_Send7816Apdu(
                pDataParams->pPalMifareDataParams,
                PH_EXCHANGE_BUFFER_LAST,
                0x00,       /* Lc is zero because the length is updated in the first call. */
                pDataParams->bExtendedLenApdu,
                pValue,
                (bNumBlocks * PHAL_MFPEV1_DATA_BLOCK_SIZE ),
                &pResponse,
                &wRxLength));
        }
        else
        {
            /* command header */
            PH_CHECK_SUCCESS_FCT(statusTmp, phpalMifare_ExchangeL4(
                pDataParams->pPalMifareDataParams,
                PH_EXCHANGE_BUFFER_FIRST,
                aCmd,
                3,
                &pResponse,
                &wRxLength));

            /* command exchange */
            PH_CHECK_SUCCESS_FCT(statusTmp, phpalMifare_ExchangeL4(
                pDataParams->pPalMifareDataParams,
                PH_EXCHANGE_BUFFER_LAST,
                pValue,
                (bNumBlocks * PHAL_MFPEV1_DATA_BLOCK_SIZE ),
                &pResponse,
                &wRxLength));
        }
    }
    else
    {
        /* command header */
        PH_CHECK_SUCCESS_FCT(statusTmp, phpalMifare_ExchangeL3(
            pDataParams->pPalMifareDataParams,
            PH_EXCHANGE_BUFFER_FIRST,
            aCmd,
            3,
            &pResponse,
            &wRxLength));

        /* command exchange */
        PH_CHECK_SUCCESS_FCT(statusTmp, phpalMifare_ExchangeL3(
            pDataParams->pPalMifareDataParams,
            PH_EXCHANGE_BUFFER_LAST,
            pValue,
            (bNumBlocks * PHAL_MFPEV1_DATA_BLOCK_SIZE ),
            &pResponse,
            &wRxLength));
    }

    /* check response */
    if (wRxLength == 1U)
    {
        PH_CHECK_SUCCESS_FCT(statusTmp, phalMfpEv1_Int_ComputeErrorResponse(wRxLength, pResponse[0], bLayer4Comm));
    }
    else
    {
        return PH_ADD_COMPCODE_FIXED(PH_ERR_PROTOCOL_ERROR, PH_COMP_AL_MFPEV1);
    }

    return PH_ERR_SUCCESS;
}

phStatus_t phalMfpEv1_Int_CommitPerso(
                                   phalMfpEv1_Sw_DataParams_t * pDataParams,
                                   uint8_t bOption,
                                   uint8_t bLayer4Comm
                                   )
{
    phStatus_t  PH_MEMLOC_REM statusTmp;
    uint8_t     PH_MEMLOC_REM aCmd[2];
    uint8_t *   PH_MEMLOC_REM pResponse = NULL;
    uint16_t    PH_MEMLOC_REM wRxLength = 0;
    uint16_t    PH_MEMLOC_REM wCmdlen;

    /*Initialize local variables */
    wRxLength   = 0;
    wCmdlen     = 0;

    /* Check if option is required. */
    if (bOption == 0U)
    {
        /* build command frame */
        aCmd[wCmdlen++] = PHAL_MFPEV1_CMD_COMMITPERSO;
    }else
    {
        /* build command frame */
        aCmd[wCmdlen++] = PHAL_MFPEV1_CMD_COMMITPERSO;
        aCmd[wCmdlen++] = bOption;
    }

    /* exchange command/response */
    if (0U != (bLayer4Comm))
    {
        /* Check if ISO 7816-4 wapping is required */
        if(0U != (pDataParams->bWrappedMode))
        {
            /* Exchange the command. */
            PH_CHECK_SUCCESS_FCT(statusTmp, phalMfpEv1_Int_Send7816Apdu(
                pDataParams->pPalMifareDataParams,
                PH_EXCHANGE_DEFAULT,
                (wCmdlen - 1 /* Excluding the command code */),
                pDataParams->bExtendedLenApdu,
                aCmd,
                wCmdlen,        /* Command code is included as part of length. */
                &pResponse,
                &wRxLength));
        }
        else
        {
            /* command exchange */
            PH_CHECK_SUCCESS_FCT(statusTmp, phpalMifare_ExchangeL4(
                pDataParams->pPalMifareDataParams,
                PH_EXCHANGE_DEFAULT,
                aCmd,
                wCmdlen,
                &pResponse,
                &wRxLength));
        }
    }
    else
    {
        /* command exchange */
        PH_CHECK_SUCCESS_FCT(statusTmp, phpalMifare_ExchangeL3(
            pDataParams->pPalMifareDataParams,
            PH_EXCHANGE_DEFAULT,
            aCmd,
            wCmdlen,
            &pResponse,
            &wRxLength));
    }

    /* check response */
    if (wRxLength == 1U)
    {
        PH_CHECK_SUCCESS_FCT(statusTmp, phalMfpEv1_Int_ComputeErrorResponse(wRxLength, pResponse[0], bLayer4Comm));
    }
    else
    {
        return PH_ADD_COMPCODE_FIXED(PH_ERR_PROTOCOL_ERROR, PH_COMP_AL_MFPEV1);
    }

    return PH_ERR_SUCCESS;
}

phStatus_t phalMfpEv1_Int_ResetAuth(phalMfpEv1_Sw_DataParams_t * pDataParams)
{
    phStatus_t  PH_MEMLOC_REM statusTmp;
    uint8_t     PH_MEMLOC_REM aCmd[1 /* command code */];
    uint8_t *   PH_MEMLOC_REM pResponse = NULL;
    uint16_t    PH_MEMLOC_REM wRxLength = 0;

    /* command code */
    aCmd[0] = PHAL_MFPEV1_CMD_RAUTH;

    /* Check if ISO 7816-4 wapping is required. */
    if(0U != (pDataParams->bWrappedMode))
    {
        /* command exchange */
        PH_CHECK_SUCCESS_FCT(statusTmp, phalMfpEv1_Int_Send7816Apdu(
            pDataParams->pPalMifareDataParams,
            PH_EXCHANGE_DEFAULT,
            0x00, /* Data is not available. Only command is sent */
            pDataParams->bExtendedLenApdu,
            aCmd,
            1,
            &pResponse,
            &wRxLength));
    }
    else
    {
        /* command exchange */
        PH_CHECK_SUCCESS_FCT(statusTmp, phpalMifare_ExchangeL4(
            pDataParams->pPalMifareDataParams,
            PH_EXCHANGE_DEFAULT,
            aCmd,
            1,
            &pResponse,
            &wRxLength));
    }

    /* check response */
    PH_CHECK_SUCCESS_FCT(statusTmp, phalMfpEv1_Int_ComputeErrorResponse(wRxLength, pResponse[0], 1));

    return PH_ERR_SUCCESS;
}
#endif /* NXPBUILD__PHAL_MFPEV1_SW */


phStatus_t phalMfpEv1_Int_MultiBlockRead(
                                      void * pPalMifareDataParams,
                                      uint8_t bBlockNr,
                                      uint8_t bNumBlocks,
                                      uint8_t * pBlocks
                                      )
{
    phStatus_t  PH_MEMLOC_REM statusTmp;
    uint8_t     PH_MEMLOC_REM aCmd[1 /* command code */ + 1 /* wBlockNr */ + 1 /* bNumBlocks */];
    uint8_t *   PH_MEMLOC_REM pResponse = NULL;
    uint16_t    PH_MEMLOC_REM wRxLength = 0;

    /* parameter checking */
    if (pBlocks == NULL)
    {
        return PH_ADD_COMPCODE_FIXED(PH_ERR_INVALID_PARAMETER, PH_COMP_AL_MFPEV1);
    }

    /* command frame */
    aCmd[0] = PHAL_MFPEV1_CMD_MBREAD;
    aCmd[1] = bBlockNr;
    aCmd[2] = bNumBlocks;

    /* command exchange */
    PH_CHECK_SUCCESS_FCT(statusTmp, phpalMifare_ExchangeL3(
        pPalMifareDataParams,
        PH_EXCHANGE_DEFAULT,
        aCmd,
        3,
        &pResponse,
        &wRxLength));

    /* check response */
    if (((wRxLength % PHAL_MFPEV1_DATA_BLOCK_SIZE) == 0U) && (wRxLength <= (uint16_t)(3u * PHAL_MFPEV1_DATA_BLOCK_SIZE)))
    {
        /* pass back read bytes */
        (void)memcpy(pBlocks, pResponse, wRxLength);
    }
    else
    {
        PH_CHECK_SUCCESS_FCT(statusTmp, phalMfpEv1_Int_ComputeErrorResponse(wRxLength, pResponse[0], 0));
    }

    return PH_ERR_SUCCESS;
}

phStatus_t phalMfpEv1_Int_MultiBlockWrite(
                                       void * pPalMifareDataParams,
                                       uint8_t bBlockNr,
                                       uint8_t bNumBlocks,
                                       uint8_t * pBlocks
                                       )
{
    phStatus_t  PH_MEMLOC_REM statusTmp;
    uint8_t     PH_MEMLOC_REM aCmd[1 /* command code */ + 1 /* wBlockNr */ + 1 /* bNumBlocks */];
    uint8_t *   PH_MEMLOC_REM pResponse = NULL;
    uint16_t    PH_MEMLOC_REM wRxLength = 0;

    /* parameter checking */
    if (pBlocks == NULL)
    {
        return PH_ADD_COMPCODE_FIXED(PH_ERR_INVALID_PARAMETER, PH_COMP_AL_MFPEV1);
    }

    /* command frame */
    aCmd[0] = PHAL_MFPEV1_CMD_MBWRITE;
    aCmd[1] = bBlockNr;
    aCmd[2] = bNumBlocks;

    /* command exchange */
    PH_CHECK_SUCCESS_FCT(statusTmp, phpalMifare_ExchangeL3(
        pPalMifareDataParams,
        PH_EXCHANGE_DEFAULT,
        aCmd,
        3,
        &pResponse,
        &wRxLength));

    /* command exchange */
    PH_CHECK_SUCCESS_FCT(statusTmp, phpalMifare_ExchangeL3(
        pPalMifareDataParams,
        PH_EXCHANGE_DEFAULT,
        pBlocks,
        (uint16_t)(bNumBlocks * PHAL_MFPEV1_DATA_BLOCK_SIZE),
        &pResponse,
        &wRxLength));

    return PH_ERR_SUCCESS;
}

phStatus_t phalMfpEv1_Int_CreateValueBlock(
                                        uint8_t * pValue,
                                        uint8_t bAddrData,
                                        uint8_t * pBlock
                                        )
{
    pBlock[0]  = (uint8_t)pValue[0];
    pBlock[1]  = (uint8_t)pValue[1];
    pBlock[2]  = (uint8_t)pValue[2];
    pBlock[3]  = (uint8_t)pValue[3];
    pBlock[4]  = (uint8_t)~(uint8_t)pValue[0];
    pBlock[5]  = (uint8_t)~(uint8_t)pValue[1];
    pBlock[6]  = (uint8_t)~(uint8_t)pValue[2];
    pBlock[7]  = (uint8_t)~(uint8_t)pValue[3];
    pBlock[8]  = (uint8_t)pValue[0];
    pBlock[9]  = (uint8_t)pValue[1];
    pBlock[10] = (uint8_t)pValue[2];
    pBlock[11] = (uint8_t)pValue[3];
    pBlock[12] = (uint8_t)bAddrData;
    pBlock[13] = (uint8_t)~(uint8_t)bAddrData;
    pBlock[14] = (uint8_t)bAddrData;

    pBlock[15] = (uint8_t)~(uint8_t)bAddrData;
    return PH_ERR_SUCCESS;
}

phStatus_t phalMfpEv1_Int_CheckValueBlockFormat(
    uint8_t * pBlock
    )
{
    /* check format of value block */
    if ((pBlock[0] != pBlock[8]) ||
        (pBlock[1] != pBlock[9]) ||
        (pBlock[2] != pBlock[10]) ||
        (pBlock[3] != pBlock[11]) ||
        (pBlock[4] != (pBlock[0] ^ 0xFFU)) ||
        (pBlock[5] != (pBlock[1] ^ 0xFFU)) ||
        (pBlock[6] != (pBlock[2] ^ 0xFFU)) ||
        (pBlock[7] != (pBlock[3] ^ 0xFFU)) ||
        (pBlock[12] != pBlock[14]) ||
        (pBlock[13] != pBlock[15]) ||
        (pBlock[12] != (pBlock[13]^ 0xFFU)))
    {
        return PH_ADD_COMPCODE_FIXED(PH_ERR_PROTOCOL_ERROR, PH_COMP_AL_MFPEV1);
    }
    return PH_ERR_SUCCESS;
}

phStatus_t phalMfpEv1_Int_Send7816Apdu(
                                    void * pPalMifareDataParams,
                                    uint16_t wOptions,
                                    uint16_t wLc,
                                    uint8_t bExtendedLenApdu,
                                    uint8_t * pData,
                                    uint16_t wDataLen,
                                    uint8_t ** ppRxBuffer,
                                    uint16_t * pRxBufLen
                                    )
{
    phStatus_t  PH_MEMLOC_REM wStatus = PH_ERR_SUCCESS;
    uint8_t *   PH_MEMLOC_REM pResponse = NULL;
    uint16_t    PH_MEMLOC_REM wRespLen = 0;
    uint8_t     PH_MEMLOC_REM bLc[3] = {0x00, 0x00, 0x00};
    uint8_t     PH_MEMLOC_REM bLe[3] = {0x00, 0x00, 0x00};
    uint8_t     PH_MEMLOC_REM bLcLen = 0;
    uint8_t     PH_MEMLOC_REM bBackup = 0;
    uint8_t     PH_MEMLOC_REM bISO7816Header[4] = {PHAL_MFPEV1_WRAPPEDAPDU_CLA, 0x00, PHAL_MFPEV1_WRAPPEDAPDU_P1, PHAL_MFPEV1_WRAPPEDAPDU_P2};

    static uint8_t      PH_MEMLOC_REM bLeLen;

    if((wOptions == PH_EXCHANGE_BUFFER_FIRST) || (wOptions == PH_EXCHANGE_DEFAULT))
    {
        bLeLen = 1;

        /* Update the command code to the 7816 header */
        bISO7816Header[1] = pData[0];

        /* Add the ISO 7816 header to layer 4 buffer. */
        PH_CHECK_SUCCESS_FCT(wStatus, phpalMifare_ExchangeL4(
            pPalMifareDataParams,
            PH_EXCHANGE_BUFFER_FIRST,
            &bISO7816Header[0],
            PHAL_MFPEV1_WRAP_HDR_LEN,
            NULL,
            NULL));

        /* Add Lc if available */
        if(0U != (wLc))
        {
            /* Update Lc bytes according to Extended APDU option. */
            if(0U != (bExtendedLenApdu))
            {
                bLc[bLcLen++] = 0x00;
                bLc[bLcLen++] = (uint8_t) ((wLc & 0xFF00U) >> 8U);

                /* Le length is updated to two if Lc is presend and the APDU is extended. */
                bLeLen = 2;
            }

            bLc[bLcLen++] = (uint8_t) (wLc & 0x00FFU);

            /* Add the Lc to layer 4 buffer. */
            PH_CHECK_SUCCESS_FCT(wStatus, phpalMifare_ExchangeL4(
                pPalMifareDataParams,
                PH_EXCHANGE_BUFFER_CONT,
                &bLc[0],
                bLcLen,
                NULL,
                NULL));

            /* Add the data to layer 4 buffer. */
            PH_CHECK_SUCCESS_FCT(wStatus, phpalMifare_ExchangeL4(
                pPalMifareDataParams,
                PH_EXCHANGE_BUFFER_CONT,
                &pData[1], /* Exclude the command code because it is added to INS. */
                (wDataLen - 1u), /* Subtracted - 1 because command code is not available as part of data. */
                NULL,
                NULL));
        }
        else
        {
            /* Update Le count */
            if(0U != (bExtendedLenApdu))
            {
                bLeLen = 3;
            }
        }
    }

    if(wOptions == PH_EXCHANGE_BUFFER_CONT)
    {
        /* Add the data to layer 4 buffer. */
        PH_CHECK_SUCCESS_FCT(wStatus, phpalMifare_ExchangeL4(
            pPalMifareDataParams,
            PH_EXCHANGE_BUFFER_CONT,
            pData,
            wDataLen,
            NULL,
            NULL));
    }

    if((wOptions == PH_EXCHANGE_BUFFER_LAST) || (wOptions == PH_EXCHANGE_DEFAULT))
    {
        if(wOptions == PH_EXCHANGE_BUFFER_LAST)
        {
            /* Add the data to layer 4 buffer. */
            PH_CHECK_SUCCESS_FCT(wStatus, phpalMifare_ExchangeL4(
                pPalMifareDataParams,
                PH_EXCHANGE_BUFFER_CONT,
                pData,
                wDataLen,
                NULL,
                NULL));
        }

        /* Add Le to L4 buffer and exchange the command. */
        PH_CHECK_SUCCESS_FCT(wStatus, phpalMifare_ExchangeL4(
            pPalMifareDataParams,
            PH_EXCHANGE_BUFFER_LAST,
            &bLe[0],
            bLeLen,
            &pResponse,
            &wRespLen));

        /* Check if it not a response additional frame. */
        if(pResponse[wRespLen - 1u] != PHAL_MFPEV1_RESP_ADDITIONAL_FRAME)
        {
            /* Check for success response */
            PH_CHECK_SUCCESS_FCT(wStatus, phalMfpEv1_Int_ComputeErrorResponse(1, pResponse[wRespLen - 1u], PH_ON));
        }

        /* Create memory for updating the response of ISO 14443 format. */
        *ppRxBuffer = pResponse;

        /* This operation is performed to bring back the ISO14443-4 response data format. */

        /* Copy the second byte of response (SW2) to RxBuffer */
        bBackup = pResponse[wRespLen - 1u];

        /* Right shift the response buffer by 1 byte. */
        (void)memmove(&pResponse[1], &pResponse[0], wRespLen - 1u);    /* PRQA S 3200 */

        /* Copy the backup data to first position of response buffer. */
        pResponse[0] = bBackup;

        /* Update the response buffer length excluding SW1. */
        *pRxBufLen = wRespLen - 1u;
    }

    if(wOptions == PH_EXCHANGE_RXCHAINING)
    {
        /* Exchange the command */
        PH_CHECK_SUCCESS_FCT(wStatus, phpalMifare_ExchangeL4(
            pPalMifareDataParams,
            wOptions,
            pData,
            wDataLen,
            &pResponse,
            &wRespLen));

        if(wRespLen != 0U)
        {
            /* Check if it not a response additional frame. */
            if(pResponse[wRespLen - 1u] != PHAL_MFPEV1_RESP_ADDITIONAL_FRAME)
            {
                /* Check for success response */
                PH_CHECK_SUCCESS_FCT(wStatus, phalMfpEv1_Int_ComputeErrorResponse(1, pResponse[wRespLen - 1u], PH_ON));
            }

            /* Create memory for updating the response of ISO 14443 format. */
            *ppRxBuffer = pResponse;

            /* This operation is performed to bring back the ISO14443-4 response data format. */

            /* Copy the second byte of response (SW2) to RxBuffer */
            bBackup = pResponse[wRespLen - 1u];

            /* Right shift the response buffer by 1 byte. */
            (void)memmove(&pResponse[1], &pResponse[0], wRespLen - 1u);    /* PRQA S 3200 */

            /* Copy the backup data to first position of response buffer. */
            pResponse[0] = bBackup;

            /* Update the response buffer length excluding SW1. */
            *pRxBufLen = wRespLen - 1u;
        }
    }

    return wStatus;
}
#endif /* NXPBUILD__PHAL_MFPEV1 */
